package com.eshop.service;

import com.eshop.entity.Order;
import com.eshop.entity.OrderItem;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import com.itextpdf.text.pdf.draw.LineSeparator;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.time.format.DateTimeFormatter;

@Service
@RequiredArgsConstructor
public class InvoiceService {

	public byte[] generateInvoice(Order order) {
		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			Document document = new Document(PageSize.A4, 50, 50, 50, 50);
			PdfWriter.getInstance(document, baos);

			document.open();

			// Fonts
			Font titleFont = new Font(Font.FontFamily.HELVETICA, 24, Font.BOLD, new BaseColor(30, 64, 175));
			Font headerFont = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.WHITE);
			Font normalFont = new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL, BaseColor.DARK_GRAY);
			Font boldFont = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.BLACK);
			Font smallFont = new Font(Font.FontFamily.HELVETICA, 9, Font.NORMAL, new BaseColor(100, 100, 100));

			// Header Section
			PdfPTable headerTable = new PdfPTable(2);
			headerTable.setWidthPercentage(100);
			headerTable.setWidths(new float[] { 1f, 1f });

			// Company Name
			PdfPCell companyCell = new PdfPCell();
			companyCell.setBorder(Rectangle.NO_BORDER);
			companyCell.addElement(new Paragraph("FreshBasket", titleFont));
			Paragraph tagline = new Paragraph("Your Premium Online Grocery Store", smallFont);
			companyCell.addElement(tagline);
			headerTable.addCell(companyCell);

			// Invoice Label
			PdfPCell invoiceLabelCell = new PdfPCell();
			invoiceLabelCell.setBorder(Rectangle.NO_BORDER);
			invoiceLabelCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			Font invoiceFont = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD, new BaseColor(30, 64, 175));
			Paragraph invoiceLabel = new Paragraph("INVOICE", invoiceFont);
			invoiceLabel.setAlignment(Element.ALIGN_RIGHT);
			invoiceLabelCell.addElement(invoiceLabel);

			Paragraph orderNum = new Paragraph("# " + order.getOrderNumber(), boldFont);
			orderNum.setAlignment(Element.ALIGN_RIGHT);
			invoiceLabelCell.addElement(orderNum);

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy");
			Paragraph dateP = new Paragraph("Date: " + order.getCreatedAt().format(formatter), normalFont);
			dateP.setAlignment(Element.ALIGN_RIGHT);
			invoiceLabelCell.addElement(dateP);
			headerTable.addCell(invoiceLabelCell);

			document.add(headerTable);
			document.add(new LineSeparator());
			document.add(Chunk.NEWLINE);

			// Bill To Section
			PdfPTable billToTable = new PdfPTable(2);
			billToTable.setWidthPercentage(100);
			billToTable.setWidths(new float[] { 1f, 1f });

			PdfPCell billToCell = new PdfPCell();
			billToCell.setBorder(Rectangle.NO_BORDER);
			billToCell.addElement(new Paragraph("BILL TO:", boldFont));
			String customerName = order.getUser().getFirstName() + " " + order.getUser().getLastName();
			billToCell.addElement(new Paragraph(customerName, normalFont));
			billToCell.addElement(new Paragraph(order.getUser().getEmail(), normalFont));
			if (order.getShippingAddress() != null) {
				billToCell.addElement(new Paragraph(order.getShippingAddress(), normalFont));
			}
			billToTable.addCell(billToCell);

			PdfPCell statusCell = new PdfPCell();
			statusCell.setBorder(Rectangle.NO_BORDER);
			statusCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			Paragraph statusLabel = new Paragraph("Status: " + order.getStatus().name(), boldFont);
			statusLabel.setAlignment(Element.ALIGN_RIGHT);
			statusCell.addElement(statusLabel);
			if (order.getPaymentMethod() != null) {
				Paragraph paymentP = new Paragraph("Payment: " + order.getPaymentMethod(), normalFont);
				paymentP.setAlignment(Element.ALIGN_RIGHT);
				statusCell.addElement(paymentP);
			}
			billToTable.addCell(statusCell);

			document.add(billToTable);
			document.add(Chunk.NEWLINE);

			// Items Table
			PdfPTable itemsTable = new PdfPTable(5);
			itemsTable.setWidthPercentage(100);
			itemsTable.setWidths(new float[] { 3f, 1f, 1.5f, 1.5f, 1.5f });

			// Table Header
			BaseColor headerBg = new BaseColor(30, 64, 175);
			String[] headers = { "Product", "Qty", "Unit Price", "Total", "" };
			String[] realHeaders = { "Product", "Qty", "Unit Price", "Total" };

			for (String h : realHeaders) {
				PdfPCell cell = new PdfPCell(new Phrase(h, headerFont));
				cell.setBackgroundColor(headerBg);
				cell.setPadding(8);
				cell.setBorder(Rectangle.NO_BORDER);
				itemsTable.addCell(cell);
			}

			// Blank extra column header
			PdfPCell blankHeader = new PdfPCell(new Phrase("", headerFont));
			blankHeader.setBackgroundColor(headerBg);
			blankHeader.setBorder(Rectangle.NO_BORDER);
			blankHeader.setPadding(8);

			// Remove extra column - fix to 4 columns
			itemsTable = new PdfPTable(4);
			itemsTable.setWidthPercentage(100);
			itemsTable.setWidths(new float[] { 4f, 1f, 2f, 2f });

			for (String h : realHeaders) {
				PdfPCell cell = new PdfPCell(new Phrase(h, headerFont));
				cell.setBackgroundColor(headerBg);
				cell.setPadding(8);
				cell.setBorder(Rectangle.NO_BORDER);
				itemsTable.addCell(cell);
			}

			// Items
			boolean alternate = false;
			for (OrderItem item : order.getOrderItems()) {
				BaseColor rowBg = alternate ? new BaseColor(243, 244, 246) : BaseColor.WHITE;

				PdfPCell nameCell = new PdfPCell(new Phrase(item.getProduct().getName(), normalFont));
				nameCell.setBackgroundColor(rowBg);
				nameCell.setPadding(7);
				nameCell.setBorder(Rectangle.BOTTOM);
				nameCell.setBorderColor(new BaseColor(229, 231, 235));
				itemsTable.addCell(nameCell);

				PdfPCell qtyCell = new PdfPCell(new Phrase(String.valueOf(item.getQuantity()), normalFont));
				qtyCell.setBackgroundColor(rowBg);
				qtyCell.setPadding(7);
				qtyCell.setHorizontalAlignment(Element.ALIGN_CENTER);
				qtyCell.setBorder(Rectangle.BOTTOM);
				qtyCell.setBorderColor(new BaseColor(229, 231, 235));
				itemsTable.addCell(qtyCell);

				PdfPCell unitCell = new PdfPCell(new Phrase("$" + item.getUnitPrice(), normalFont));
				unitCell.setBackgroundColor(rowBg);
				unitCell.setPadding(7);
				unitCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
				unitCell.setBorder(Rectangle.BOTTOM);
				unitCell.setBorderColor(new BaseColor(229, 231, 235));
				itemsTable.addCell(unitCell);

				PdfPCell totalCell = new PdfPCell(new Phrase("$" + item.getTotalPrice(), boldFont));
				totalCell.setBackgroundColor(rowBg);
				totalCell.setPadding(7);
				totalCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
				totalCell.setBorder(Rectangle.BOTTOM);
				totalCell.setBorderColor(new BaseColor(229, 231, 235));
				itemsTable.addCell(totalCell);

				alternate = !alternate;
			}

			document.add(itemsTable);
			document.add(Chunk.NEWLINE);

			// Totals Section
			PdfPTable totalsTable = new PdfPTable(2);
			totalsTable.setWidthPercentage(40);
			totalsTable.setHorizontalAlignment(Element.ALIGN_RIGHT);

			addTotalRow(totalsTable, "Subtotal:", "$" + order.getSubtotal(), normalFont, boldFont, false);
			addTotalRow(totalsTable, "Tax (8%):", "$" + order.getTax(), normalFont, boldFont, false);
			addTotalRow(totalsTable, "Shipping:", "$" + order.getShippingCost(), normalFont, boldFont, false);

			Font totalLabelFont = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD, new BaseColor(30, 64, 175));
			Font totalValueFont = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD, new BaseColor(30, 64, 175));
			addTotalRow(totalsTable, "TOTAL:", "$" + order.getTotalAmount(), totalLabelFont, totalValueFont, true);

			document.add(totalsTable);
			document.add(Chunk.NEWLINE);

			// Footer
			document.add(new LineSeparator());
			Paragraph footer = new Paragraph(
					"Thank you for shopping with FreshBasket! For support contact: support@freshbasket.com", smallFont);
			footer.setAlignment(Element.ALIGN_CENTER);
			document.add(footer);

			document.close();
			return baos.toByteArray();

		} catch (Exception e) {
			throw new RuntimeException("Failed to generate invoice: " + e.getMessage(), e);
		}
	}

	private void addTotalRow(PdfPTable table, String label, String value, Font labelFont, Font valueFont,
			boolean highlight) {
		PdfPCell labelCell = new PdfPCell(new Phrase(label, labelFont));
		labelCell.setBorder(Rectangle.NO_BORDER);
		labelCell.setPadding(4);
		if (highlight) {
			labelCell.setBackgroundColor(new BaseColor(239, 246, 255));
			labelCell.setPaddingTop(6);
			labelCell.setPaddingBottom(6);
		}
		table.addCell(labelCell);

		PdfPCell valueCell = new PdfPCell(new Phrase(value, valueFont));
		valueCell.setBorder(Rectangle.NO_BORDER);
		valueCell.setPadding(4);
		valueCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		if (highlight) {
			valueCell.setBackgroundColor(new BaseColor(239, 246, 255));
			valueCell.setPaddingTop(6);
			valueCell.setPaddingBottom(6);
		}
		table.addCell(valueCell);
	}
}
