package com.eshop.service;

import com.eshop.dto.ChatDto;
import com.eshop.dto.OrderDto;
import com.eshop.entity.Order;
import com.eshop.entity.User;
import com.eshop.repository.OrderRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * RAG using Spring AI ChatClient.
 *
 * RAG flow:
 *  1. Retrieve  — query PostgreSQL for the customer's orders / stats (retrieveContext)
 *  2. Augment   — inject retrieved data into the system prompt (buildSystemPrompt)
 *  3. Generate  — call the LLM via Spring AI ChatClient with the augmented prompt
 */
@Service
@Slf4j
public class ChatbotService {

    private final ChatClient chatClient;
    private final OrderRepository orderRepository;
    private final OrderService orderService;

    /**
     * Spring AI auto-configures a ChatClient.Builder bean from
     * spring.ai.openai.* properties — we inject and build here once.
     */
    public ChatbotService(ChatClient.Builder chatClientBuilder,
                          OrderRepository orderRepository,
                          OrderService orderService) {
        this.chatClient      = chatClientBuilder.build();
        this.orderRepository = orderRepository;
        this.orderService    = orderService;
    }

    // ----------------------------------------------------------------
    // Public API
    // ----------------------------------------------------------------

    public ChatDto.ChatResponse processMessage(User user, String message) {
        // Step 1 — Retrieve relevant context from the database (the R in RAG)
        String context = retrieveContext(user, message.toLowerCase());
        log.debug("context:{}",context);
        // Step 2 — Augment: build a system prompt containing the retrieved data
        String systemPrompt = buildSystemPrompt(user, context);
        log.debug("systemPrompt:{}",systemPrompt);
        // Step 3 — Generate: call the LLM through Spring AI ChatClient
        String aiReply = callAI(systemPrompt, message);

        return new ChatDto.ChatResponse(aiReply, "text");
    }

    // ----------------------------------------------------------------
    // Step 1 — Retrieval
    // ----------------------------------------------------------------

    private String retrieveContext(User user, String message) {
        StringBuilder ctx = new StringBuilder();

        ctx.append("=== CUSTOMER CONTEXT ===\n")
           .append("Customer : ").append(user.getFirstName()).append(" ").append(user.getLastName()).append("\n")
           .append("Email    : ").append(user.getEmail()).append("\n\n");
    	log.debug("initial customer ctx:{}", ctx);
        // --- Order statistics (total count, spending by period, top grocery items) ---
        boolean wantsStats = containsAny(message,
                "order", "spent", "total", "purchase", "statistic", "stat",
                "top", "most", "item", "how many", "grocery", "bought");
        if (wantsStats) {
            OrderDto.OrderStatsResponse stats = orderService.getOrderStats(user);
            ctx.append("=== ORDER STATISTICS ===\n")
               .append("Total Orders              : ").append(stats.getTotalOrders()).append("\n")
               .append("Amount Spent (Last 7 days): $").append(stats.getTotalSpentLast7Days()).append("\n")
               .append("Amount Spent (Last Month) : $").append(stats.getTotalSpentLastMonth()).append("\n")
               .append("Amount Spent (Last Quarter): $").append(stats.getTotalSpentLastQuarter()).append("\n")
               .append("Amount Spent (Last Year)  : $").append(stats.getTotalSpentLastYear()).append("\n");

            if (!stats.getTop10Products().isEmpty()) {
                ctx.append("\nTop 10 Most Purchased Grocery Items:\n");
                int rank = 1;
                for (OrderDto.TopProductResponse item : stats.getTop10Products()) {
                    ctx.append(rank++).append(". ")
                       .append(item.getProductName())
                       .append(" — Qty: ").append(item.getTotalQuantity()).append("\n");
                }
            }
        }
		log.debug("wantsStats ctx:{}", wantsStats);
        // --- Recent orders list ---
        boolean wantsOrders = containsAny(message,
                "order", "status", "track", "recent", "latest", "invoice", "history", "delivery");
        if (wantsOrders) {
            List<Order> recent = orderRepository.findByUserAndDateRange(
                    user, LocalDateTime.now().minusMonths(3));
            if (!recent.isEmpty()) {
                DateTimeFormatter fmt = DateTimeFormatter.ofPattern("MMM dd, yyyy");
                ctx.append("\n=== RECENT ORDERS (last 3 months) ===\n");
                recent.stream().limit(10).forEach(o ->
                    ctx.append("Order #").append(o.getOrderNumber())
                       .append(" | Date: ").append(o.getCreatedAt().format(fmt))
                       .append(" | Status: ").append(o.getStatus().name())
                       .append(" | Total: $").append(o.getTotalAmount()).append("\n")
                );
            }
        }
		log.debug("wantsOrders ctx:{}", wantsStats);
        // --- Specific order lookup by order number ---
        if (containsAny(message, "ord-", "order number")) {
            for (String word : message.split("\\s+")) {
                String token = word.replaceAll("[^a-zA-Z0-9-]", "").toUpperCase();
                if (token.startsWith("ORD-")) {
                    try {
                        Order o = orderService.getOrderEntityByNumberAndUser(token, user);
                        ctx.append("\n=== SPECIFIC ORDER DETAILS ===\n")
                           .append("Order Number : ").append(o.getOrderNumber()).append("\n")
                           .append("Status       : ").append(o.getStatus().name()).append("\n")
                           .append("Total        : $").append(o.getTotalAmount()).append("\n")
                           .append("Items:\n");
                        o.getOrderItems().forEach(i ->
                            ctx.append("  - ").append(i.getProduct().getName())
                               .append(" x").append(i.getQuantity())
                               .append(" @ $").append(i.getUnitPrice()).append("\n")
                        );
                    } catch (Exception e) {
                        ctx.append("Order ").append(token).append(" was not found for this account.\n");
                    }
                }
            }
        }

        return ctx.toString();
    }

    // ----------------------------------------------------------------
    // Step 2 — Augment
    // ----------------------------------------------------------------

    private String buildSystemPrompt(User user, String context) {
        return """
                You are FreshBot, a friendly and knowledgeable customer-service assistant for FreshBasket,
                a premium online grocery store delivering farm-fresh produce, dairy, bakery goods,
                meat & seafood, pantry essentials and beverages straight to customers' doors.

                Your capabilities:
                  • Check the status and details of any grocery order
                  • Report total order count and spending (7 days / 1 month / 1 quarter / 1 year)
                  • Show the customer's top 10 most purchased grocery items
                  • Explain how to download a PDF invoice (Orders page → Download Invoice button)
                  • Answer questions about products, categories, freshness and delivery
                  • Help customers find specific grocery items in our store

                Product categories available in FreshBasket:
                  🍎 Fruits & Vegetables  🥛 Dairy & Eggs  🍞 Bakery & Bread
                  🥩 Meat & Seafood       🫙 Pantry & Dry Goods  🥤 Beverages

                Rules:
                  • Only discuss order data that appears in the CUSTOMER CONTEXT section below.
                  • Never invent order numbers, amounts, or product names.
                  • Format all monetary amounts with a $ sign and two decimal places.
                  • Keep replies concise, warm and conversational — like a helpful store assistant.
                  • If specific information is not in the context, politely say you don't have it.
                  • When mentioning freshness or delivery, be positive and encouraging.

                CUSTOMER CONTEXT (live data retrieved from database):
                """
                + context
                + """

                Respond in a warm, friendly grocery-store assistant tone.
                """;
    }

    // ----------------------------------------------------------------
    // Step 3 — Generate via Spring AI ChatClient
    // ----------------------------------------------------------------

    private String callAI(String systemPrompt, String userMessage) {
        try {
            /*
             * Spring AI Prompt wraps multiple Message objects.
             * SystemMessage — sets the model's persona + RAG context
             * UserMessage   — the customer's actual question
             */
            Prompt prompt = new Prompt(List.of(
                    new SystemMessage(systemPrompt),
                    new UserMessage(userMessage)
            ));

            return chatClient
                    .prompt(prompt)
                    .call()
                    .content();

        } catch (Exception e) {
            log.error("Spring AI call failed: {}", e.getMessage());
            return buildFallbackResponse(userMessage);
        }
    }

    // ----------------------------------------------------------------
    // Fallback (when AI is unavailable / no API key configured)
    // ----------------------------------------------------------------

    private String buildFallbackResponse(String message) {
        String m = message.toLowerCase();
        if (m.contains("invoice") || m.contains("download")) {
            return "To download your invoice, go to the **Orders** page, find your order and click **Download Invoice**. A PDF will be saved to your device.";
        }
        if (m.contains("status") || m.contains("track") || m.contains("delivery")) {
            return "Visit the **Orders** page to see the current status of all your grocery orders in real time.";
        }
        if (m.contains("spent") || m.contains("total") || m.contains("amount")) {
            return "Your spending breakdown (7 days / 1 month / quarter / year) is on the **Statistics** tab of the Orders page.";
        }
        if (m.contains("top") || m.contains("most") || m.contains("frequent")) {
            return "Your **Top 10 most purchased grocery items** are listed on the Statistics tab of the Orders page.";
        }
        if (containsAny(m, "hello", "hi", "hey", "help")) {
            return "Hi there! 🛒 I'm FreshBot, your FreshBasket assistant! I can help you with:\n• Order status & delivery tracking\n• Invoice downloads\n• Spending stats\n• Your most purchased grocery items\n\nWhat can I help you with today?";
        }
        return "I'm here to help with your FreshBasket experience! Ask me about your orders, grocery spending, invoices or your favourite items.";
    }

    // ----------------------------------------------------------------
    // Utility
    // ----------------------------------------------------------------

    private boolean containsAny(String text, String... keywords) {
        for (String kw : keywords) {
            if (text.contains(kw)) return true;
        }
        return false;
    }
}
