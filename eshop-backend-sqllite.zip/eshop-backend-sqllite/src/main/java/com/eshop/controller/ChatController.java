package com.eshop.controller;

import com.eshop.dto.ChatDto;
import com.eshop.entity.User;
import com.eshop.service.AuthService;
import com.eshop.service.ChatbotService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/chat")
@RequiredArgsConstructor
public class ChatController {

    private final ChatbotService chatbotService;
    private final AuthService authService;

    @PostMapping("/message")
    public ResponseEntity<ChatDto.ChatResponse> sendMessage(
            @AuthenticationPrincipal UserDetails userDetails,
            @RequestBody ChatDto.ChatRequest request) {
        User user = authService.getCurrentUser(userDetails.getUsername());
        ChatDto.ChatResponse response = chatbotService.processMessage(user, request.getMessage());
        return ResponseEntity.ok(response);
    }
}
