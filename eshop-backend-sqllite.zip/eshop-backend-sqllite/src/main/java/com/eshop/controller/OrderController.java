package com.eshop.controller;

import com.eshop.dto.OrderDto;
import com.eshop.entity.Order;
import com.eshop.entity.User;
import com.eshop.service.AuthService;
import com.eshop.service.InvoiceService;
import com.eshop.service.OrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/orders")
@RequiredArgsConstructor
public class OrderController {

    private final OrderService orderService;
    private final AuthService authService;
    private final InvoiceService invoiceService;

    @PostMapping("/place")
    public ResponseEntity<OrderDto.OrderResponse> placeOrder(
            @AuthenticationPrincipal UserDetails userDetails,
            @RequestBody OrderDto.PlaceOrderRequest request) {
        User user = authService.getCurrentUser(userDetails.getUsername());
        return ResponseEntity.ok(orderService.placeOrder(user, request));
    }

    @GetMapping
    public ResponseEntity<Page<OrderDto.OrderResponse>> getUserOrders(
            @AuthenticationPrincipal UserDetails userDetails,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        User user = authService.getCurrentUser(userDetails.getUsername());
        PageRequest pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        return ResponseEntity.ok(orderService.getUserOrders(user, pageable));
    }

    @GetMapping("/{orderNumber}")
    public ResponseEntity<OrderDto.OrderResponse> getOrder(
            @AuthenticationPrincipal UserDetails userDetails,
            @PathVariable String orderNumber) {
        User user = authService.getCurrentUser(userDetails.getUsername());
        return ResponseEntity.ok(orderService.getOrderByNumber(user, orderNumber));
    }

    @GetMapping("/stats")
    public ResponseEntity<OrderDto.OrderStatsResponse> getOrderStats(
            @AuthenticationPrincipal UserDetails userDetails) {
        User user = authService.getCurrentUser(userDetails.getUsername());
        return ResponseEntity.ok(orderService.getOrderStats(user));
    }

    @GetMapping("/{orderNumber}/invoice")
    public ResponseEntity<byte[]> downloadInvoice(
            @AuthenticationPrincipal UserDetails userDetails,
            @PathVariable String orderNumber) {
        User user = authService.getCurrentUser(userDetails.getUsername());
        Order order = orderService.getOrderEntityByNumberAndUser(orderNumber, user);

        byte[] pdfBytes = invoiceService.generateInvoice(order);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_PDF);
        headers.setContentDispositionFormData("attachment", "invoice-" + orderNumber + ".pdf");
        headers.setContentLength(pdfBytes.length);

        return ResponseEntity.ok().headers(headers).body(pdfBytes);
    }
}
