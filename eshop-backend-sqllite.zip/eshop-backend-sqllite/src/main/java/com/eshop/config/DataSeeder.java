package com.eshop.config;

import com.eshop.entity.Product;
import com.eshop.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class DataSeeder implements CommandLineRunner {

    private final ProductRepository productRepository;

    @Override
    public void run(String... args) {
        if (productRepository.count() == 0) {
            log.info("Seeding 300 grocery products...");
            List<Product> all = new ArrayList<>();
            all.addAll(fruitsAndVegetables());
            all.addAll(dairyAndEggs());
            all.addAll(bakeryAndBread());
            all.addAll(meatAndSeafood());
            all.addAll(pantryAndDryGoods());
            all.addAll(beverages());
            productRepository.saveAll(all);
            log.info("Seeded {} products successfully.", all.size());
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 1. FRUITS & VEGETABLES  (50 products)
    // ─────────────────────────────────────────────────────────────────────────
    private List<Product> fruitsAndVegetables() {
        String cat = "Fruits & Vegetables";
        String img = "https://images.unsplash.com/photo-1610832958506-aa56368176cf?w=400";
        return List.of(
            p("Organic Bananas (1 bunch)", "Fresh organic bananas, naturally ripened. Rich in potassium. Approx. 6–7 per bunch.", "1.49", 300, cat, "https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=400", "FarmFresh", 4.8, 5420),
            p("Gala Apples (1 kg)", "Crisp and sweet Gala apples from local orchards. Great for snacking and baking.", "2.99", 250, cat, "https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=400", "OrchardGold", 4.7, 3210),
            p("Baby Spinach (200 g)", "Tender pre-washed baby spinach leaves. High in iron, folate and vitamins A & K.", "1.99", 200, cat, "https://images.unsplash.com/photo-1576045057995-568f588f82fb?w=400", "GreenLeaf", 4.6, 2100),
            p("Cherry Tomatoes (500 g)", "Sweet and juicy cherry tomatoes. Perfect for salads, pasta and snacking.", "2.49", 180, cat, "https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=400", "SunRipe", 4.7, 1870),
            p("Broccoli (1 head)", "Fresh whole broccoli head approx. 400–500 g. Packed with vitamins C and K.", "1.79", 220, cat, "https://images.unsplash.com/photo-1459411621453-7b03977f4bfc?w=400", "FarmFresh", 4.5, 1540),
            p("Alphonso Mangoes (pack of 6)", "Premium Alphonso mangoes. Intensely sweet saffron-yellow flesh. Seasonal limited stock.", "8.99", 80, cat, "https://images.unsplash.com/photo-1553279768-865429fa0078?w=400", "TropicHarvest", 4.9, 4320),
            p("Red Onions (1 kg)", "Firm red onions with a mild flavour. Great raw in salads or cooked in curries.", "1.29", 400, cat, img, "FarmFresh", 4.5, 2870),
            p("Garlic Bulb (pack of 3)", "Fresh whole garlic bulbs. Aromatic and full-flavoured. Essential kitchen staple.", "1.49", 350, cat, img, "FarmFresh", 4.7, 3400),
            p("Baby Carrots (500 g)", "Tender baby carrots, pre-washed and ready to eat. Great for snacking and cooking.", "1.69", 280, cat, "https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?w=400", "GreenLeaf", 4.6, 2100),
            p("Cucumber (each)", "Long English cucumber. Crisp, fresh and hydrating. Perfect for salads and snacking.", "0.89", 300, cat, img, "SunRipe", 4.5, 1800),
            p("Red Bell Peppers (pack of 3)", "Sweet red bell peppers. Rich in vitamin C. Ideal for stir-fries, salads and stuffing.", "2.99", 200, cat, img, "SunRipe", 4.7, 2200),
            p("Yellow Bell Peppers (pack of 3)", "Mild and sweet yellow peppers. Excellent source of vitamins A and C.", "2.99", 180, cat, img, "SunRipe", 4.6, 1900),
            p("Green Bell Peppers (pack of 3)", "Firm green peppers with a slightly bitter taste. Great for cooking and salads.", "2.49", 200, cat, img, "SunRipe", 4.4, 1600),
            p("Iceberg Lettuce (1 head)", "Crisp iceberg lettuce. Perfect base for salads, burgers and wraps.", "1.29", 250, cat, img, "GreenLeaf", 4.3, 1400),
            p("Romaine Lettuce (2 heads)", "Fresh romaine lettuce hearts. Perfect for Caesar salad. Crisp and tender.", "2.49", 180, cat, img, "GreenLeaf", 4.6, 1700),
            p("Sweet Potato (1 kg)", "Naturally sweet and nutritious sweet potatoes. High in fibre and vitamin A.", "2.29", 300, cat, img, "FarmFresh", 4.7, 2500),
            p("White Potatoes (2 kg)", "Versatile white potatoes ideal for boiling, mashing, roasting and frying.", "2.99", 400, cat, img, "FarmFresh", 4.6, 4100),
            p("Cauliflower (1 head)", "Fresh white cauliflower approx. 600 g. Great for roasting, steaming or rice alternatives.", "2.29", 180, cat, img, "FarmFresh", 4.5, 1600),
            p("Zucchini / Courgette (pack of 2)", "Tender green courgettes. Versatile for grilling, baking and stir-fries.", "1.99", 200, cat, img, "GreenLeaf", 4.5, 1400),
            p("Eggplant / Aubergine (each)", "Large firm aubergine approx. 350 g. Perfect for curries, bakes and grills.", "1.49", 180, cat, img, "FarmFresh", 4.4, 1300),
            p("Celery (1 bunch)", "Fresh crisp celery stalks. Low calorie and great for snacking, soups and salads.", "1.49", 200, cat, img, "GreenLeaf", 4.4, 1200),
            p("Leeks (pack of 2)", "Tender leeks with a mild onion flavour. Great for soups, quiches and sides.", "1.79", 180, cat, img, "FarmFresh", 4.5, 1100),
            p("Spring Onions / Scallions (bunch)", "Fresh spring onions. Add crunch and flavour to salads, stir-fries and garnishes.", "0.99", 250, cat, img, "GreenLeaf", 4.6, 1800),
            p("Fresh Ginger Root (200 g)", "Firm fresh ginger root. Pungent and warming. Essential for Asian cooking and teas.", "1.29", 300, cat, img, "TropicHarvest", 4.7, 2400),
            p("Strawberries (400 g)", "Plump and juicy strawberries. Naturally sweet with a vibrant red colour.", "3.49", 150, cat, "https://images.unsplash.com/photo-1464965911861-746a04b4bca6?w=400", "BerryBest", 4.8, 3600),
            p("Blueberries (250 g)", "Plump wild blueberries packed with antioxidants. Perfect for breakfast bowls and baking.", "3.99", 140, cat, img, "BerryBest", 4.8, 3200),
            p("Raspberries (200 g)", "Fresh raspberries with a sweet-tart flavour. Great for desserts, smoothies and yogurt.", "3.49", 120, cat, img, "BerryBest", 4.7, 2900),
            p("Blackberries (200 g)", "Ripe blackberries with a deep, rich flavour. High in fibre and antioxidants.", "3.29", 110, cat, img, "BerryBest", 4.6, 2100),
            p("Grapes - Red Seedless (500 g)", "Sweet and juicy red seedless grapes. Perfect for snacking and fruit platters.", "3.49", 180, cat, img, "OrchardGold", 4.7, 2700),
            p("Grapes - Green Seedless (500 g)", "Crisp and refreshing green seedless grapes with a subtle sweetness.", "3.49", 180, cat, img, "OrchardGold", 4.6, 2400),
            p("Watermelon (whole, approx. 5 kg)", "Large sweet watermelon. Refreshing and hydrating. Perfect for summer.", "6.99", 60, cat, img, "TropicHarvest", 4.8, 1800),
            p("Cantaloupe / Rockmelon (each)", "Fragrant cantaloupe melon with sweet orange flesh. Rich in vitamins A and C.", "3.99", 80, cat, img, "TropicHarvest", 4.6, 1500),
            p("Pineapple (whole)", "Fresh whole pineapple. Tropical, sweet and tangy. Rich in bromelain enzyme.", "3.49", 90, cat, img, "TropicHarvest", 4.7, 2100),
            p("Kiwi Fruit (pack of 6)", "Tangy and refreshing kiwi fruit with bright green flesh. High in vitamin C.", "3.29", 150, cat, img, "TropicHarvest", 4.6, 1900),
            p("Avocados (pack of 4)", "Ready-to-eat Hass avocados. Creamy and rich. Perfect for guacamole and toast.", "4.99", 160, cat, img, "TropicHarvest", 4.8, 4100),
            p("Lemon (pack of 6)", "Bright juicy lemons. Essential for cooking, baking and drinks.", "2.29", 300, cat, img, "SunRipe", 4.7, 3100),
            p("Lime (pack of 6)", "Fresh limes. Perfect for cocktails, dressings and Asian recipes.", "2.29", 280, cat, img, "SunRipe", 4.6, 2700),
            p("Oranges - Navel (1 kg)", "Sweet navel oranges. Easy to peel with no seeds. Great for eating and juicing.", "2.99", 250, cat, img, "SunRipe", 4.7, 3400),
            p("Grapefruit (pack of 2)", "Large pink grapefruits with a bittersweet flavour. High in vitamin C.", "2.49", 180, cat, img, "SunRipe", 4.5, 1600),
            p("Pomegranate (each)", "Large pomegranate with ruby-red arils. Packed with antioxidants and vitamins.", "2.99", 120, cat, img, "TropicHarvest", 4.7, 2100),
            p("Pears - Williams (pack of 4)", "Juicy Williams pears with a smooth texture and sweet floral flavour.", "3.49", 160, cat, img, "OrchardGold", 4.6, 1800),
            p("Peaches (pack of 4)", "Ripe juicy peaches with fragrant golden-yellow flesh. Great fresh or grilled.", "4.49", 100, cat, img, "OrchardGold", 4.7, 2200),
            p("Plums (pack of 6)", "Dark sweet plums with a rich juicy flesh. Great for eating fresh or making jam.", "3.29", 130, cat, img, "OrchardGold", 4.5, 1700),
            p("Mushrooms - Button (250 g)", "White button mushrooms, pre-sliced. Mild flavour, perfect for frying and soups.", "2.29", 200, cat, img, "GreenLeaf", 4.6, 2500),
            p("Mushrooms - Portobello (pack of 4)", "Large flat portobello mushrooms. Meaty texture, great for grilling and stuffing.", "3.49", 140, cat, img, "GreenLeaf", 4.7, 2000),
            p("Baby Corn (200 g)", "Tender baby corn cobs. Crunchy and sweet. Perfect for stir-fries and salads.", "2.49", 170, cat, img, "TropicHarvest", 4.5, 1400),
            p("Sugar Snap Peas (200 g)", "Crisp sugar snap peas. Sweet and crunchy. Eat raw or lightly stir-fried.", "2.29", 180, cat, img, "GreenLeaf", 4.6, 1600),
            p("Green Beans / French Beans (300 g)", "Tender fine green beans. Quick to cook and delicious steamed or sautéed.", "2.49", 190, cat, img, "GreenLeaf", 4.5, 1800),
            p("Asparagus (bunch)", "Fresh green asparagus spears. Tender tips and great grilled, steamed or roasted.", "3.99", 120, cat, img, "GreenLeaf", 4.7, 2100),
            p("Beetroot (pack of 4)", "Fresh whole beetroot. Earthy and sweet. Great roasted, pickled or in salads.", "2.49", 160, cat, img, "FarmFresh", 4.5, 1500),
            p("Kale (bunch)", "Curly kale leaves packed with iron, calcium and vitamins K and C. Great for salads and smoothies.", "2.29", 180, cat, img, "GreenLeaf", 4.6, 2200)
        );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 2. DAIRY & EGGS  (50 products)
    // ─────────────────────────────────────────────────────────────────────────
    private List<Product> dairyAndEggs() {
        String cat = "Dairy & Eggs";
        String img = "https://images.unsplash.com/photo-1628088062854-d1870b4553da?w=400";
        return List.of(
            p("Whole Milk (1 L)", "Fresh full-cream whole milk from grass-fed cows. Rich in calcium and protein.", "1.29", 400, cat, "https://images.unsplash.com/photo-1563636619-e9143da7973b?w=400", "MeadowFarm", 4.7, 6780),
            p("Semi-Skimmed Milk (1 L)", "Light semi-skimmed milk with 1.8% fat. All the calcium with fewer calories.", "1.19", 380, cat, img, "MeadowFarm", 4.6, 5400),
            p("Skimmed Milk (1 L)", "Fat-free skimmed milk. High in calcium and protein, very low in calories.", "1.09", 300, cat, img, "MeadowFarm", 4.5, 4100),
            p("Whole Milk (2 L)", "Family-size whole milk from grass-fed cows. Fresh and nutritious.", "2.29", 300, cat, img, "MeadowFarm", 4.7, 5200),
            p("Organic Whole Milk (1 L)", "Certified organic whole milk. No pesticides or GMO feed. Rich creamy taste.", "2.49", 200, cat, img, "OrganicVale", 4.8, 3200),
            p("Free-Range Eggs (12 pack)", "Large free-range eggs from pasture-raised hens. Rich golden yolks.", "3.49", 350, cat, "https://images.unsplash.com/photo-1587486913049-53fc88980cfc?w=400", "HappyHen", 4.9, 8910),
            p("Free-Range Eggs (6 pack)", "Half-dozen large free-range eggs. Perfect for smaller households.", "1.99", 400, cat, img, "HappyHen", 4.8, 6700),
            p("Organic Free-Range Eggs (12 pack)", "Certified organic free-range eggs. Hens fed 100% organic grain.", "4.99", 180, cat, img, "OrganicVale", 4.9, 4300),
            p("Greek Yogurt - Natural (500 g)", "Thick strained Greek yogurt, 10% fat. High in protein and probiotics. No added sugar.", "2.79", 200, cat, "https://images.unsplash.com/photo-1488477181946-6428a0291777?w=400", "CreamyVale", 4.8, 3450),
            p("Greek Yogurt - Natural (1 kg)", "Large tub of thick creamy Greek yogurt. Perfect for breakfast, dips and cooking.", "4.99", 150, cat, img, "CreamyVale", 4.8, 2900),
            p("Greek Yogurt - Strawberry (150 g)", "Creamy Greek yogurt with a real strawberry swirl. No artificial flavours.", "1.29", 280, cat, img, "CreamyVale", 4.6, 3100),
            p("Greek Yogurt - Blueberry (150 g)", "Rich Greek yogurt with a real blueberry compote. Great for breakfast or snacking.", "1.29", 260, cat, img, "CreamyVale", 4.6, 2800),
            p("Greek Yogurt - Vanilla (150 g)", "Smooth Greek yogurt with real vanilla bean. Naturally sweet and creamy.", "1.29", 250, cat, img, "CreamyVale", 4.7, 2700),
            p("Probiotic Yogurt Drink (pack of 6, 100 ml)", "Daily probiotic drink to support gut health. Each bottle contains 10 billion cultures.", "3.49", 200, cat, img, "CreamyVale", 4.7, 3800),
            p("Cheddar Cheese Block (400 g)", "Mature cheddar aged 12 months. Sharp, nutty flavour. Great for cooking and snacking.", "4.99", 150, cat, "https://images.unsplash.com/photo-1452195100486-9cc805987862?w=400", "DairyGold", 4.7, 2870),
            p("Mild Cheddar Slices (200 g)", "Pre-sliced mild cheddar. Perfect for sandwiches and burgers.", "2.99", 200, cat, img, "DairyGold", 4.5, 2400),
            p("Mozzarella Ball (125 g)", "Fresh buffalo mozzarella in water. Soft and milky. Perfect for Caprese salad and pizza.", "2.49", 200, cat, img, "ItaliaBella", 4.8, 3100),
            p("Mozzarella Shredded (200 g)", "Pre-shredded mozzarella cheese. Great melt for pizzas, pasta bakes and quesadillas.", "2.99", 220, cat, img, "DairyGold", 4.7, 2800),
            p("Parmesan (100 g)", "Authentic Parmigiano Reggiano, finely grated. Aged 24 months. Rich and nutty.", "3.49", 160, cat, img, "ItaliaBella", 4.9, 2600),
            p("Brie (200 g)", "Creamy French-style brie with a velvety rind. Perfect for cheese boards.", "3.99", 120, cat, img, "DairyGold", 4.7, 1900),
            p("Feta Cheese (200 g)", "Authentic Greek feta in brine. Crumbly, tangy and salty. Perfect for salads.", "3.29", 180, cat, img, "MeadowFarm", 4.7, 2400),
            p("Halloumi (225 g)", "Cypriot halloumi cheese. Holds its shape when grilled or fried. Great with salads.", "3.99", 150, cat, img, "MeadowFarm", 4.8, 3200),
            p("Cream Cheese (200 g)", "Smooth and creamy full-fat cream cheese. Perfect for spreading, baking and dips.", "2.49", 220, cat, img, "DairyGold", 4.6, 2700),
            p("Ricotta (250 g)", "Light and creamy fresh ricotta. Perfect for pasta fillings, cheesecake and pancakes.", "2.79", 170, cat, img, "ItaliaBella", 4.7, 2100),
            p("Cottage Cheese (300 g)", "Low-fat cottage cheese with a mild flavour. High in protein. Great for healthy eating.", "2.29", 190, cat, img, "DairyGold", 4.5, 1900),
            p("Unsalted Butter (250 g)", "Premium unsalted butter churned from fresh cream. Ideal for baking and cooking.", "2.49", 300, cat, "https://images.unsplash.com/photo-1589985270826-4b7bb135bc9d?w=400", "MeadowFarm", 4.6, 2130),
            p("Salted Butter (250 g)", "Creamy salted butter. Perfect for spreading on toast and finishing savoury dishes.", "2.49", 300, cat, img, "MeadowFarm", 4.7, 2400),
            p("Organic Unsalted Butter (250 g)", "Certified organic unsalted butter from grass-fed cows. Rich golden colour.", "3.99", 150, cat, img, "OrganicVale", 4.8, 1600),
            p("Sour Cream (300 ml)", "Thick and tangy sour cream. Perfect for dips, dressings, tacos and baked potatoes.", "1.99", 220, cat, img, "CreamyVale", 4.6, 2100),
            p("Crème Fraîche (200 ml)", "Rich and velvety crème fraîche with 30% fat. Won't split when cooked.", "2.29", 180, cat, img, "CreamyVale", 4.7, 1800),
            p("Double Cream (300 ml)", "Rich double cream with 48% fat. Ideal for whipping, pouring and cooking.", "2.49", 160, cat, img, "MeadowFarm", 4.7, 1900),
            p("Whipping Cream (300 ml)", "Light whipping cream. Doubles in volume when whipped. Great for desserts.", "2.29", 170, cat, img, "MeadowFarm", 4.6, 1700),
            p("Single Cream (300 ml)", "Pouring cream with 18% fat. Perfect for coffee, soups and light sauces.", "1.99", 190, cat, img, "MeadowFarm", 4.5, 1600),
            p("Oat Milk (1 L)", "Creamy oat milk with a naturally sweet flavour. Great for coffee and cereal.", "2.49", 250, cat, img, "PureOat", 4.7, 3400),
            p("Almond Milk - Unsweetened (1 L)", "Creamy unsweetened almond milk. Enriched with calcium and vitamins D & E.", "2.49", 230, cat, img, "NutMilk", 4.6, 2800),
            p("Soy Milk - Unsweetened (1 L)", "Protein-rich unsweetened soy milk. Fortified with calcium and B12.", "2.29", 220, cat, img, "NutMilk", 4.5, 2400),
            p("Coconut Milk Drink (1 L)", "Light and refreshing coconut milk drink. Naturally dairy-free and vegan.", "2.79", 180, cat, img, "TropicHarvest", 4.6, 2100),
            p("Goat Milk (1 L)", "Fresh goat milk. Easier to digest than cow milk. Naturally rich in A2 protein.", "2.99", 120, cat, img, "MeadowFarm", 4.6, 1400),
            p("Condensed Milk (397 g)", "Sweetened condensed milk in a tin. Essential for desserts, fudge and sweet treats.", "2.49", 200, cat, img, "DairyGold", 4.7, 2700),
            p("Evaporated Milk (410 g)", "Unsweetened evaporated milk. Creamier than regular milk. Great for soups and curries.", "1.49", 220, cat, img, "DairyGold", 4.6, 2200),
            p("Lactose-Free Whole Milk (1 L)", "Full-flavoured whole milk with lactose removed. Perfect for lactose intolerant shoppers.", "2.29", 180, cat, img, "MeadowFarm", 4.7, 2500),
            p("Kefir - Natural (500 ml)", "Probiotic-rich fermented kefir milk. Tart and tangy. Excellent for gut health.", "3.49", 130, cat, img, "CreamyVale", 4.8, 1800),
            p("Skyr - Natural (450 g)", "Icelandic-style skyr. Ultra-thick, very high protein, low fat. Great with fruit.", "3.29", 150, cat, img, "CreamyVale", 4.8, 2200),
            p("Quark - Natural (250 g)", "Smooth low-fat quark. High in protein, mild flavour. Great for baking and dips.", "2.29", 160, cat, img, "CreamyVale", 4.6, 1700),
            p("Blue Cheese (150 g)", "Creamy blue-veined cheese with a bold, pungent flavour. Perfect for cheese boards.", "3.49", 100, cat, img, "DairyGold", 4.6, 1400),
            p("Gouda (200 g)", "Mild and creamy Dutch Gouda. Smooth texture, slightly sweet. Great for melting.", "3.29", 140, cat, img, "DairyGold", 4.6, 1600),
            p("Edam (200 g)", "Firm, mild Edam cheese coated in red wax. Low fat, great for slicing.", "3.29", 130, cat, img, "DairyGold", 4.5, 1400),
            p("Swiss Cheese / Emmental (150 g)", "Mild nutty Swiss Emmental with characteristic holes. Perfect for toasties and fondue.", "3.99", 110, cat, img, "DairyGold", 4.6, 1300),
            p("Manchego (150 g)", "Authentic Spanish Manchego made from sheep milk. Firm, buttery and slightly sharp.", "4.99", 90, cat, img, "ItaliaBella", 4.8, 1200),
            p("Truffle Cheese (100 g)", "Semi-soft cheese infused with black truffle. Intensely aromatic and indulgent.", "6.99", 60, cat, img, "DairyGold", 4.9, 980)
        );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 3. BAKERY & BREAD  (50 products)
    // ─────────────────────────────────────────────────────────────────────────
    private List<Product> bakeryAndBread() {
        String cat = "Bakery & Bread";
        String img = "https://images.unsplash.com/photo-1549931319-a545dcf3bc73?w=400";
        return List.of(
            p("Sourdough Loaf (800 g)", "Artisan sourdough with a crunchy crust and chewy crumb. 48-hour ferment, stone-ground flour.", "3.99", 100, cat, "https://images.unsplash.com/photo-1586444248902-2f64eddc13df?w=400", "ArtisanBake", 4.9, 5670),
            p("Whole Wheat Sandwich Bread (600 g)", "Soft whole wheat bread, high in fibre. No artificial preservatives. 20 slices.", "2.29", 200, cat, "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400", "NutriLoaf", 4.5, 3210),
            p("Croissants (pack of 4)", "Flaky all-butter croissants baked fresh every morning. Light, layered and golden.", "3.49", 120, cat, "https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=400", "ArtisanBake", 4.8, 4120),
            p("Blueberry Muffins (pack of 6)", "Soft moist muffins bursting with fresh blueberries. No artificial colours.", "4.49", 90, cat, "https://images.unsplash.com/photo-1607958996333-41aef7caefaa?w=400", "SweetCrust", 4.7, 2890),
            p("White Sandwich Bread (800 g)", "Classic soft white bread with a fluffy crumb. Perfect for sandwiches and toast.", "1.99", 250, cat, img, "NutriLoaf", 4.4, 4200),
            p("Multigrain Bread (750 g)", "Hearty multigrain loaf packed with seeds and grains. Rich in fibre and nutrients.", "3.29", 180, cat, img, "NutriLoaf", 4.7, 2700),
            p("Seeded Batch Loaf (800 g)", "Soft batch loaf topped with sunflower, sesame and poppy seeds. Rich in fibre.", "3.49", 160, cat, img, "ArtisanBake", 4.7, 2400),
            p("Rye Bread (500 g)", "Dense dark rye bread with a rich, earthy flavour. High in fibre and slow-release carbs.", "3.29", 130, cat, img, "ArtisanBake", 4.7, 2200),
            p("Gluten-Free White Bread (400 g)", "Soft gluten-free white bread. Suitable for coeliacs. No compromise on taste.", "4.49", 120, cat, img, "FreeFrom", 4.5, 2100),
            p("Gluten-Free Multigrain Bread (400 g)", "Gluten-free multigrain loaf with seeds. High fibre and nutritious.", "4.99", 100, cat, img, "FreeFrom", 4.5, 1800),
            p("Ciabatta (2 rolls)", "Authentic Italian ciabatta rolls with an open airy crumb and crisp crust.", "2.49", 150, cat, img, "ItaliaBake", 4.7, 2100),
            p("Baguette (each)", "Classic French baguette with a crisp golden crust and light airy inside.", "1.49", 200, cat, img, "ArtisanBake", 4.7, 3100),
            p("Tiger Bread Loaf (800 g)", "Crusty tiger bread with a distinctive crackled crust and soft interior.", "2.99", 150, cat, img, "ArtisanBake", 4.6, 2400),
            p("Focaccia - Rosemary & Sea Salt (300 g)", "Italian-style focaccia drizzled with olive oil and topped with rosemary and sea salt.", "3.49", 100, cat, img, "ItaliaBake", 4.8, 2200),
            p("Naan Bread (pack of 4)", "Soft fluffy naan breads. Perfect for curries, dips and wraps.", "2.29", 180, cat, img, "SpicyBake", 4.6, 2800),
            p("Garlic Naan (pack of 4)", "Soft naan breads infused with garlic butter. Irresistible with any curry.", "2.79", 170, cat, img, "SpicyBake", 4.8, 3200),
            p("Pita Bread (pack of 6)", "Soft white pita breads. Perfect for stuffing or serving with dips.", "2.29", 200, cat, img, "ArtisanBake", 4.5, 2500),
            p("Whole Wheat Pita (pack of 6)", "Whole wheat pita breads high in fibre. Great for healthy wraps and dips.", "2.49", 170, cat, img, "NutriLoaf", 4.5, 2000),
            p("Tortilla Wraps - Large (pack of 8)", "Soft large flour tortillas. Perfect for burritos, wraps and quesadillas.", "2.49", 220, cat, img, "ArtisanBake", 4.6, 3400),
            p("Whole Wheat Tortillas (pack of 8)", "Soft whole wheat tortillas. High in fibre, great for healthy wraps.", "2.79", 190, cat, img, "NutriLoaf", 4.5, 2800),
            p("English Muffins (pack of 6)", "Classic English muffins with nooks and crannies. Perfect toasted with butter.", "2.49", 180, cat, img, "ArtisanBake", 4.6, 2600),
            p("Bagels - Plain (pack of 5)", "Classic New York-style plain bagels. Dense chewy crumb with a shiny crust.", "2.99", 160, cat, img, "ArtisanBake", 4.7, 2900),
            p("Bagels - Sesame Seed (pack of 5)", "Chewy sesame-topped bagels. Perfect with cream cheese and smoked salmon.", "3.29", 140, cat, img, "ArtisanBake", 4.8, 2700),
            p("Bagels - Everything (pack of 5)", "New York everything bagels topped with garlic, onion, sesame and poppy seeds.", "3.49", 130, cat, img, "ArtisanBake", 4.8, 2500),
            p("Pain au Chocolat (pack of 4)", "Flaky butter pastry with a rich dark chocolate centre. Freshly baked daily.", "4.29", 110, cat, img, "ArtisanBake", 4.9, 3600),
            p("Chocolate Chip Cookies (pack of 12)", "Classic crispy-edged, chewy-centre chocolate chip cookies. Made with real butter.", "3.99", 150, cat, img, "SweetCrust", 4.8, 4100),
            p("Oatmeal Raisin Cookies (pack of 12)", "Soft and chewy oatmeal cookies loaded with plump raisins and warming spices.", "3.99", 140, cat, img, "SweetCrust", 4.6, 3200),
            p("Shortbread Fingers (pack of 12)", "Classic Scottish shortbread. Crumbly, buttery and melt-in-the-mouth.", "3.49", 160, cat, img, "SweetCrust", 4.7, 3400),
            p("Cinnamon Rolls (pack of 4)", "Soft fluffy cinnamon rolls with a sticky glaze. Baked fresh each morning.", "4.99", 90, cat, img, "SweetCrust", 4.9, 3800),
            p("Banana Bread Loaf (400 g)", "Moist banana bread made with real ripe bananas, walnuts and a hint of cinnamon.", "4.49", 100, cat, img, "SweetCrust", 4.8, 3100),
            p("Lemon Drizzle Cake (400 g)", "Light and zesty lemon sponge cake with a tangy sugar drizzle.", "4.99", 90, cat, img, "SweetCrust", 4.8, 2900),
            p("Chocolate Fudge Cake (400 g)", "Rich and indulgent chocolate sponge with a thick fudge frosting.", "5.49", 80, cat, img, "SweetCrust", 4.9, 3300),
            p("Carrot Cake (400 g)", "Moist spiced carrot cake with cream cheese frosting and walnut topping.", "5.49", 80, cat, img, "SweetCrust", 4.8, 2800),
            p("Victoria Sponge (400 g)", "Classic Victoria sponge with vanilla buttercream and strawberry jam filling.", "5.29", 80, cat, img, "SweetCrust", 4.8, 3000),
            p("Danish Pastry - Assorted (pack of 4)", "Assorted flaky Danish pastries — apple, custard and cherry. Freshly baked.", "4.49", 90, cat, img, "ArtisanBake", 4.7, 2600),
            p("Almond Croissants (pack of 4)", "Rich and flaky croissants filled and topped with almond frangipane cream.", "4.99", 90, cat, img, "ArtisanBake", 4.9, 2900),
            p("Scones - Plain (pack of 4)", "Traditional plain scones. Light and fluffy. Serve with clotted cream and jam.", "3.29", 130, cat, img, "SweetCrust", 4.7, 2400),
            p("Scones - Fruit (pack of 4)", "Traditional fruit scones packed with plump sultanas. Light and fluffy.", "3.49", 120, cat, img, "SweetCrust", 4.7, 2300),
            p("Brownies (pack of 4)", "Fudgy double-chocolate brownies with a crackling top. Intensely chocolatey.", "4.49", 100, cat, img, "SweetCrust", 4.9, 3500),
            p("Flapjacks (pack of 6)", "Chewy golden syrup oat flapjacks. Naturally filling and great for on-the-go.", "3.49", 140, cat, img, "SweetCrust", 4.6, 2700),
            p("Hot Cross Buns (pack of 6)", "Soft spiced buns with citrus zest and a fondant cross. Lovely toasted.", "3.29", 130, cat, img, "ArtisanBake", 4.7, 2400),
            p("Doughnuts - Glazed (pack of 4)", "Classic ring doughnuts with a sweet sugar glaze. Light and airy inside.", "3.49", 100, cat, img, "SweetCrust", 4.6, 2800),
            p("Doughnuts - Jam Filled (pack of 4)", "Soft filled doughnuts with raspberry jam and dusted with icing sugar.", "3.99", 90, cat, img, "SweetCrust", 4.7, 2600),
            p("Brioche Loaf (400 g)", "Rich, lightly sweetened brioche loaf made with butter and eggs. Great for French toast.", "3.99", 110, cat, img, "ArtisanBake", 4.8, 2900),
            p("Brioche Burger Buns (pack of 4)", "Soft and lightly sweet brioche buns. Perfect for gourmet burgers.", "3.49", 160, cat, img, "ArtisanBake", 4.8, 3100),
            p("Crumpets (pack of 6)", "Classic thick crumpets with a spongy texture and lots of nooks for butter.", "2.49", 180, cat, img, "ArtisanBake", 4.7, 2700),
            p("Waffles - Belgian (pack of 4)", "Crispy Belgian-style waffles. Ready in minutes. Great with fruit and syrup.", "3.49", 150, cat, img, "SweetCrust", 4.6, 2500),
            p("Pitta Chips - Sea Salt (100 g)", "Crunchy baked pitta chips seasoned with sea salt. Great with dips.", "2.49", 180, cat, img, "ArtisanBake", 4.5, 2000),
            p("Bread Rolls - White (pack of 6)", "Classic soft white bread rolls. Perfect for sandwiches and burgers.", "2.29", 220, cat, img, "NutriLoaf", 4.5, 2900),
            p("Bread Rolls - Whole Wheat (pack of 6)", "Soft whole wheat rolls. High in fibre. Great for healthy packed lunches.", "2.49", 190, cat, img, "NutriLoaf", 4.5, 2400),
            p("Flatbreads (pack of 4)", "Thin soft flatbreads. Versatile for wraps, pizza bases and dipping.", "2.29", 200, cat, img, "ArtisanBake", 4.5, 2200)
        );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 4. MEAT & SEAFOOD  (50 products)
    // ─────────────────────────────────────────────────────────────────────────
    private List<Product> meatAndSeafood() {
        String cat = "Meat & Seafood";
        String img = "https://images.unsplash.com/photo-1607623814075-e51df1bdc82f?w=400";
        return List.of(
            p("Chicken Breast Fillets (1 kg)", "Boneless skinless free-range chicken breast. High protein. Perfect for grilling and baking.", "7.99", 150, cat, "https://images.unsplash.com/photo-1604503468506-a8da13d82791?w=400", "FarmFirst", 4.7, 4320),
            p("Chicken Thighs - Boneless (1 kg)", "Juicy boneless skinless chicken thighs. More flavourful than breast. Great for curries.", "5.99", 160, cat, img, "FarmFirst", 4.8, 3800),
            p("Chicken Thighs - Bone-In (1 kg)", "Skin-on bone-in chicken thighs. Perfect for slow-cooking, roasting and BBQ.", "4.99", 170, cat, img, "FarmFirst", 4.7, 3200),
            p("Whole Chicken (approx. 1.5 kg)", "Free-range whole chicken. Great for roasting. Feeds a family of 4.", "9.99", 80, cat, img, "FarmFirst", 4.8, 2700),
            p("Chicken Drumsticks (pack of 8)", "Free-range chicken drumsticks. Juicy and tender. Ideal for BBQ and roasting.", "4.99", 140, cat, img, "FarmFirst", 4.7, 2900),
            p("Chicken Wings (1 kg)", "Meaty free-range chicken wings. Perfect for BBQ, frying and sauces.", "5.49", 130, cat, img, "FarmFirst", 4.8, 3400),
            p("Chicken Mince (500 g)", "Lean minced chicken. Low fat, high protein. Great for burgers and meatballs.", "4.49", 160, cat, img, "FarmFirst", 4.6, 2400),
            p("Salmon Fillets (400 g)", "Fresh Atlantic salmon fillets, skin-on. Rich in omega-3. Sustainably sourced.", "9.99", 80, cat, "https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?w=400", "OceanCatch", 4.8, 3100),
            p("Lean Ground Beef (500 g)", "Premium 5%-fat lean ground beef. No fillers. Ideal for burgers and bolognese.", "6.49", 120, cat, img, "FarmFirst", 4.6, 2870),
            p("Regular Ground Beef (500 g)", "Classic 20%-fat ground beef. More flavourful for burgers, meatloaf and sauces.", "5.49", 140, cat, img, "FarmFirst", 4.6, 2600),
            p("Tiger Prawns - Raw (300 g)", "Shell-on raw tiger prawns. Sweet firm flesh. Great for curries and pasta.", "8.49", 60, cat, img, "OceanCatch", 4.7, 1760),
            p("Beef Ribeye Steak (250 g)", "Premium dry-aged ribeye steak. Marbled, juicy and packed with flavour.", "14.99", 60, cat, img, "FarmFirst", 4.9, 2200),
            p("Beef Sirloin Steak (250 g)", "Tender dry-aged sirloin steak. Lean with a perfect fat strip for flavour.", "12.99", 70, cat, img, "FarmFirst", 4.8, 2000),
            p("Beef Rump Steak (300 g)", "Flavourful rump steak with good texture. Great value for grilling.", "9.99", 80, cat, img, "FarmFirst", 4.7, 1800),
            p("Beef Mince (500 g)", "Classic 20% fat beef mince. Rich flavour for bolognese and shepherd's pie.", "5.99", 150, cat, img, "FarmFirst", 4.6, 3100),
            p("Beef Stewing Steak (500 g)", "Diced beef chuck ideal for slow cooking, stews and casseroles.", "6.99", 120, cat, img, "FarmFirst", 4.7, 2400),
            p("Beef Burgers (pack of 4, 454 g)", "100% beef burgers seasoned with onion and herbs. No fillers or additives.", "5.99", 130, cat, img, "FarmFirst", 4.7, 3000),
            p("Pork Chops (pack of 2, 400 g)", "Thick-cut free-range pork chops. Juicy and flavourful. Great for grilling.", "6.49", 110, cat, img, "FarmFirst", 4.6, 2100),
            p("Pork Mince (500 g)", "Lean pork mince. Perfect for dumplings, meatballs and Thai larb.", "4.99", 140, cat, img, "FarmFirst", 4.6, 2000),
            p("Pork Sausages (pack of 6, 400 g)", "Traditional pork sausages with a high meat content. Great for grilling and frying.", "4.49", 160, cat, img, "FarmFirst", 4.7, 3600),
            p("Cumberland Sausages (pack of 6, 400 g)", "Coarsely ground Cumberland sausages with a peppery spice blend.", "4.99", 140, cat, img, "FarmFirst", 4.8, 3200),
            p("Chipolatas (pack of 12, 340 g)", "Thin pork chipolata sausages. Perfect for a full breakfast or pigs in blankets.", "3.99", 160, cat, img, "FarmFirst", 4.7, 3000),
            p("Back Bacon Rashers (300 g)", "Dry-cured back bacon with minimal fat. Thick-cut and full of flavour.", "4.49", 200, cat, img, "FarmFirst", 4.8, 4200),
            p("Streaky Bacon (200 g)", "Thin-cut dry-cured streaky bacon. Crispy when fried. Great for BLTs and wraps.", "3.99", 190, cat, img, "FarmFirst", 4.7, 3800),
            p("Smoked Salmon (100 g)", "Hand-sliced Scottish smoked salmon. Delicately smoked with oak. Perfect with cream cheese.", "5.99", 100, cat, img, "OceanCatch", 4.9, 3400),
            p("Smoked Salmon (200 g)", "Value pack of oak-smoked Scottish salmon slices. Great for entertaining.", "9.99", 80, cat, img, "OceanCatch", 4.9, 2900),
            p("Cod Fillets (400 g)", "Firm white cod fillets. Sustainably sourced. Perfect for baking, frying and fish pie.", "8.99", 80, cat, img, "OceanCatch", 4.7, 2400),
            p("Haddock Fillets (400 g)", "Flaky white haddock fillets. Mild flavour, great for fish and chips.", "8.49", 80, cat, img, "OceanCatch", 4.7, 2200),
            p("Sea Bass Fillets (300 g)", "Fresh sea bass fillets with a delicate flavour. Great for pan-frying and baking.", "10.99", 60, cat, img, "OceanCatch", 4.8, 1900),
            p("Tuna Steaks (pack of 2, 300 g)", "Fresh yellowfin tuna steaks. Meaty and flavourful. Great for searing and grilling.", "12.99", 50, cat, img, "OceanCatch", 4.8, 1700),
            p("King Prawns - Cooked (300 g)", "Ready-to-eat cooked king prawns. Sweet and succulent. Great for salads and stir-fries.", "7.99", 90, cat, img, "OceanCatch", 4.7, 2400),
            p("Scallops (200 g)", "Plump sweet scallops. Quick to cook and delicious pan-seared with butter.", "12.99", 50, cat, img, "OceanCatch", 4.9, 1600),
            p("Mussels (500 g)", "Fresh rope-grown mussels. Sweet and plump. Ready to steam in white wine or cream.", "4.99", 80, cat, img, "OceanCatch", 4.7, 1900),
            p("Squid Rings (300 g)", "Tender squid rings. Perfect for frying in batter or adding to seafood pasta.", "5.99", 80, cat, img, "OceanCatch", 4.6, 1700),
            p("Lamb Mince (500 g)", "Rich and flavourful lamb mince. Perfect for moussaka, koftas and shepherd's pie.", "7.99", 100, cat, img, "FarmFirst", 4.7, 1800),
            p("Lamb Chops (pack of 4, 500 g)", "Tender free-range lamb chops. Juicy and flavourful. Great for grilling.", "11.99", 70, cat, img, "FarmFirst", 4.8, 1900),
            p("Lamb Shoulder (1 kg)", "Bone-in lamb shoulder. Perfect for slow-roasting until fall-off-the-bone tender.", "14.99", 50, cat, img, "FarmFirst", 4.8, 1500),
            p("Duck Breast (pack of 2, 350 g)", "Free-range duck breast fillets with skin. Rich and flavourful. Score and sear for crispy skin.", "12.99", 50, cat, img, "FarmFirst", 4.8, 1400),
            p("Turkey Mince (500 g)", "Lean turkey mince. High in protein, low in fat. Great for burgers and meatballs.", "5.49", 120, cat, img, "FarmFirst", 4.6, 1900),
            p("Venison Steaks (pack of 2, 300 g)", "Lean, rich venison loin steaks. Sustainably sourced. Quick to pan-sear.", "14.99", 40, cat, img, "FarmFirst", 4.8, 1200),
            p("Chorizo (200 g)", "Spicy Spanish-style pork chorizo. Ready-sliced. Great for tapas, pasta and cooking.", "3.99", 160, cat, img, "FarmFirst", 4.8, 3100),
            p("Pancetta Cubes (150 g)", "Cured Italian pancetta lardons. Intense salty-smoky flavour. Essential for carbonara.", "3.49", 170, cat, img, "ItaliaBake", 4.7, 2600),
            p("Pepperoni (100 g)", "Thin-sliced pepperoni. Spicy and smoky. Perfect for pizza and pasta.", "2.99", 200, cat, img, "FarmFirst", 4.7, 3500),
            p("Salami - Milano (100 g)", "Thinly sliced Italian Milano salami. Mild and aromatic. Great for antipasto.", "3.49", 160, cat, img, "ItaliaBake", 4.7, 2700),
            p("Prosciutto di Parma (80 g)", "Authentic Parma ham thinly sliced. Sweet, silky and melt-in-the-mouth.", "4.99", 120, cat, img, "ItaliaBake", 4.9, 2900),
            p("Cooked Chicken Slices (150 g)", "Thick-cut roasted chicken breast slices. No added water. Great for sandwiches.", "3.29", 200, cat, img, "FarmFirst", 4.6, 3200),
            p("Cooked Ham Slices (150 g)", "Thick-cut honey roast ham slices. Lightly sweet and juicy.", "3.29", 190, cat, img, "FarmFirst", 4.6, 3000),
            p("Sardines in Olive Oil (120 g)", "Sustainably caught whole sardines in extra virgin olive oil. Rich in omega-3.", "2.49", 200, cat, img, "OceanCatch", 4.6, 2100),
            p("Mackerel Fillets in Brine (125 g)", "Smoked mackerel fillets in brine. Ready to eat, high in omega-3 and protein.", "2.29", 200, cat, img, "OceanCatch", 4.6, 2300),
            p("Crab Meat (170 g)", "Premium white crab meat. Ready to eat. Great for sandwiches, salads and pasta.", "5.99", 80, cat, img, "OceanCatch", 4.7, 1500)
        );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 5. PANTRY & DRY GOODS  (50 products)
    // ─────────────────────────────────────────────────────────────────────────
    private List<Product> pantryAndDryGoods() {
        String cat = "Pantry & Dry Goods";
        String img = "https://images.unsplash.com/photo-1542838132-92c53300491e?w=400";
        return List.of(
            p("Basmati Rice (5 kg)", "Premium aged long-grain basmati rice. Fluffy grains with a delicate aroma. From Punjab foothills.", "8.99", 200, cat, "https://images.unsplash.com/photo-1586201375761-83865001e31c?w=400", "RoyalGrain", 4.9, 7650),
            p("Extra Virgin Olive Oil (750 ml)", "Cold-pressed Mediterranean EVOO. Rich fruity flavour, low acidity. Perfect for dressings.", "6.99", 180, cat, "https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=400", "MedGrove", 4.8, 5430),
            p("Penne Rigate (500 g)", "Bronze-die extruded penne from 100% durum wheat semolina. Al dente in 11 minutes.", "1.79", 300, cat, img, "ItaliaBella", 4.7, 4210),
            p("Rolled Oats (1 kg)", "Whole-grain rolled oats. High in beta-glucan fibre. Great for porridge and baking.", "2.99", 250, cat, img, "NutriGrain", 4.8, 3980),
            p("Canned Chickpeas (400 g)", "Tender cooked chickpeas in water. No added salt. Great for curries and hummus.", "0.99", 400, cat, img, "PurePantry", 4.6, 2870),
            p("Jasmine Rice (2 kg)", "Fragrant long-grain jasmine rice. Slightly sticky texture. Perfect for Asian dishes.", "4.99", 200, cat, img, "RoyalGrain", 4.8, 4200),
            p("Arborio Rice (500 g)", "Plump starchy arborio rice. Essential for creamy risotto. Authentic Italian origin.", "3.29", 160, cat, img, "ItaliaBella", 4.7, 2900),
            p("Brown Rice (1 kg)", "Whole-grain brown rice. Nutty flavour and chewy texture. High in fibre and minerals.", "2.99", 220, cat, img, "NutriGrain", 4.6, 2700),
            p("Quinoa (500 g)", "Organic white quinoa. Complete protein with all 9 essential amino acids. Gluten-free.", "4.99", 180, cat, img, "NutriGrain", 4.8, 3500),
            p("Red Lentils (500 g)", "Split red lentils. Quick to cook, no soaking needed. High in protein and iron.", "1.49", 300, cat, img, "PurePantry", 4.7, 3100),
            p("Green Lentils (500 g)", "Whole green lentils. Hold their shape well. Great for salads and dhal.", "1.79", 270, cat, img, "PurePantry", 4.6, 2800),
            p("Black Beans (400 g)", "Canned black beans in water. No added salt. Great for Mexican dishes and salads.", "0.99", 350, cat, img, "PurePantry", 4.6, 2500),
            p("Kidney Beans (400 g)", "Canned red kidney beans. Tender and flavourful. Essential for chilli con carne.", "0.99", 350, cat, img, "PurePantry", 4.6, 2700),
            p("Cannellini Beans (400 g)", "Creamy white cannellini beans. Great for soups, stews and Italian classics.", "1.09", 320, cat, img, "PurePantry", 4.6, 2300),
            p("Spaghetti (500 g)", "Classic bronze-die spaghetti from durum wheat. Al dente in 10 minutes.", "1.79", 300, cat, img, "ItaliaBella", 4.7, 4500),
            p("Fusilli (500 g)", "Spiral-shaped pasta that holds chunky sauces beautifully. Cooks in 11 minutes.", "1.79", 280, cat, img, "ItaliaBella", 4.6, 3800),
            p("Rigatoni (500 g)", "Large ridged pasta tubes. Perfect for chunky meat and vegetable sauces.", "1.79", 270, cat, img, "ItaliaBella", 4.6, 3400),
            p("Tagliatelle (500 g)", "Flat ribbon pasta from durum wheat. Perfect with rich meat and cream sauces.", "2.29", 220, cat, img, "ItaliaBella", 4.7, 3100),
            p("Egg Noodles (400 g)", "Chinese-style egg noodles. Quick to cook. Great for stir-fries and soups.", "2.29", 220, cat, img, "PurePantry", 4.6, 2900),
            p("Rice Noodles (250 g)", "Fine rice vermicelli noodles. Gluten-free. Perfect for pho and pad thai.", "2.49", 200, cat, img, "PurePantry", 4.6, 2700),
            p("Plain Flour (1.5 kg)", "Finely milled plain flour. Versatile for baking, sauces and coatings.", "1.79", 400, cat, img, "NutriGrain", 4.6, 5100),
            p("Self-Raising Flour (1.5 kg)", "Plain flour with raising agents already added. Perfect for cakes and scones.", "1.99", 350, cat, img, "NutriGrain", 4.6, 4200),
            p("Bread Flour (1.5 kg)", "Strong white bread flour with high gluten content. Perfect for hand and machine baking.", "2.29", 300, cat, img, "NutriGrain", 4.7, 3400),
            p("Caster Sugar (1 kg)", "Fine caster sugar that dissolves quickly. Essential for cakes, meringues and desserts.", "1.49", 400, cat, img, "PurePantry", 4.7, 4800),
            p("Icing Sugar (500 g)", "Finely powdered icing sugar. Perfect for frostings, glazes and decorating.", "1.29", 350, cat, img, "PurePantry", 4.6, 3800),
            p("Brown Sugar (500 g)", "Soft light brown sugar with a subtle molasses flavour. Great for baking and sauces.", "1.49", 330, cat, img, "PurePantry", 4.6, 3500),
            p("Honey - Pure Set (454 g)", "Pure set blossom honey. Smooth and spreadable. No added sugars or syrups.", "4.99", 200, cat, img, "PurePantry", 4.8, 4100),
            p("Manuka Honey MGO 250+ (250 g)", "Premium New Zealand Manuka honey with MGO 250+ certification. Highly bioactive.", "19.99", 60, cat, img, "PurePantry", 4.9, 2200),
            p("Maple Syrup (250 ml)", "Pure Canadian Grade A amber maple syrup. Rich caramel notes. No additives.", "5.99", 150, cat, img, "PurePantry", 4.8, 3600),
            p("Tomato Passata (700 g)", "Smooth sieved Italian tomatoes. No additives or salt. Essential pasta sauce base.", "1.49", 350, cat, img, "ItaliaBella", 4.7, 4600),
            p("Chopped Tomatoes (400 g)", "Finely chopped Italian plum tomatoes in tomato juice. Ideal for sauces and soups.", "0.89", 500, cat, img, "ItaliaBella", 4.6, 5800),
            p("Tomato Purée (200 g)", "Concentrated double tomato purée in a tube. Adds depth to sauces and stews.", "1.29", 400, cat, img, "ItaliaBella", 4.6, 4200),
            p("Coconut Milk (400 ml)", "Full-fat Thai coconut milk. Creamy and fragrant. Essential for curries and desserts.", "1.89", 300, cat, img, "TropicHarvest", 4.7, 4800),
            p("Vegetable Stock Cubes (pack of 10)", "Rich flavoured vegetable stock cubes. No artificial flavours. Easy to use.", "1.99", 350, cat, img, "PurePantry", 4.5, 3900),
            p("Chicken Stock Cubes (pack of 10)", "Full-bodied chicken stock cubes. Low salt option. Great for soups and risotto.", "1.99", 340, cat, img, "PurePantry", 4.5, 3700),
            p("Soy Sauce (150 ml)", "Premium Japanese dark soy sauce. Naturally brewed and aged. No added MSG.", "2.49", 280, cat, img, "PurePantry", 4.7, 3800),
            p("Fish Sauce (200 ml)", "Authentic Thai fish sauce. Fermented and aged for a rich umami depth.", "2.99", 230, cat, img, "TropicHarvest", 4.6, 2700),
            p("Apple Cider Vinegar (500 ml)", "Raw unfiltered apple cider vinegar with the mother. Great for dressings and health.", "3.49", 220, cat, img, "PurePantry", 4.7, 3200),
            p("Balsamic Vinegar of Modena (250 ml)", "Aged Italian balsamic vinegar with a rich sweet-sour flavour. Great on salads.", "4.99", 160, cat, img, "ItaliaBella", 4.8, 2900),
            p("Dijon Mustard (200 g)", "Classic smooth French Dijon mustard. Sharp and tangy. Perfect for dressings and marinades.", "2.49", 240, cat, img, "PurePantry", 4.7, 3100),
            p("Peanut Butter - Smooth (340 g)", "All-natural smooth peanut butter. No added sugar, salt or palm oil. 100% peanuts.", "3.99", 230, cat, img, "NutriGrain", 4.8, 4400),
            p("Peanut Butter - Crunchy (340 g)", "All-natural crunchy peanut butter with chunky peanut pieces. No additives.", "3.99", 220, cat, img, "NutriGrain", 4.8, 4100),
            p("Almond Butter (250 g)", "Pure roasted almond butter. No added oil or sugar. Rich in healthy fats and protein.", "6.99", 150, cat, img, "NutriGrain", 4.8, 2900),
            p("Dark Chocolate (100 g)", "70% dark chocolate bar. Single-origin cacao. Intense, rich and slightly bitter.", "2.99", 250, cat, img, "SweetCrust", 4.8, 3800),
            p("Milk Chocolate (100 g)", "Creamy milk chocolate bar with 35% cacao. Smooth and indulgent.", "2.49", 270, cat, img, "SweetCrust", 4.7, 4200),
            p("Cocoa Powder (250 g)", "Unsweetened Dutch-processed cocoa powder. Rich dark colour and intense flavour.", "3.49", 200, cat, img, "PurePantry", 4.7, 3100),
            p("Baking Powder (150 g)", "Aluminium-free baking powder. Reliable rise every time. Essential for baking.", "1.49", 350, cat, img, "PurePantry", 4.7, 3500),
            p("Bicarbonate of Soda (200 g)", "Pure bicarbonate of soda. Multi-use for baking, cleaning and deodorising.", "0.99", 400, cat, img, "PurePantry", 4.6, 3200),
            p("Vanilla Extract (60 ml)", "Pure vanilla extract from Madagascar vanilla beans. Rich, warm and fragrant.", "4.99", 200, cat, img, "PurePantry", 4.8, 3700),
            p("Mixed Nuts (200 g)", "Roasted mixed nuts — cashews, almonds, walnuts and Brazil nuts. Lightly salted.", "5.99", 180, cat, img, "NutriGrain", 4.7, 3400)
        );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 6. BEVERAGES  (50 products)
    // ─────────────────────────────────────────────────────────────────────────
    private List<Product> beverages() {
        String cat = "Beverages";
        String img = "https://images.unsplash.com/photo-1544145945-f90425340c7e?w=400";
        return List.of(
            p("Cold Pressed Orange Juice (1 L)", "100% cold-pressed orange juice. No added sugar or preservatives. Packed with vitamin C.", "4.49", 150, cat, "https://images.unsplash.com/photo-1621506289937-a8e4df240d0b?w=400", "PureSqueeze", 4.8, 4560),
            p("Green Tea (40 bags)", "Premium Japanese sencha green tea. Delicate grassy flavour with natural antioxidants.", "3.99", 200, cat, "https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=400", "ZenLeaf", 4.7, 3210),
            p("Sparkling Water (6 × 500 ml)", "Natural Alpine mineral sparkling water. Zero calories. Crisp and refreshing.", "2.99", 300, cat, "https://images.unsplash.com/photo-1571689936114-b05a5e96be2d?w=400", "AlpineSpring", 4.5, 2100),
            p("Almond Milk - Unsweetened (1 L)", "Creamy almond milk. No added sugar. Fortified with calcium and vitamins D & E.", "2.49", 220, cat, img, "NutMilk", 4.6, 1980),
            p("Still Mineral Water (1.5 L)", "Natural still mineral water from a protected Alpine spring. Pure and clean tasting.", "0.99", 500, cat, img, "AlpineSpring", 4.6, 5200),
            p("Still Mineral Water (6 × 500 ml)", "Six-pack of still mineral water. Great for lunchboxes and on-the-go.", "3.49", 350, cat, img, "AlpineSpring", 4.6, 4100),
            p("Sparkling Water (1.5 L)", "Refreshing carbonated mineral water. No calories, no sweeteners.", "1.29", 400, cat, img, "AlpineSpring", 4.5, 3800),
            p("Coconut Water (500 ml)", "Pure natural coconut water. Isotonic electrolytes, no added sugar.", "2.49", 200, cat, img, "TropicHarvest", 4.7, 3400),
            p("Coconut Water (1 L)", "Large pack of natural coconut water. Naturally refreshing and hydrating.", "3.99", 150, cat, img, "TropicHarvest", 4.7, 2800),
            p("Apple Juice (1 L)", "Freshly pressed cloudy apple juice. No added sugar or concentrates.", "2.99", 230, cat, img, "PureSqueeze", 4.7, 3700),
            p("Apple Juice - Clear (1 L)", "Classic clear apple juice. Gently filtered. Sweet and refreshing.", "2.49", 240, cat, img, "PureSqueeze", 4.6, 3200),
            p("Mango Juice (1 L)", "Tropical mango juice blend. Rich and sweet with no artificial flavours.", "2.99", 190, cat, img, "TropicHarvest", 4.7, 3100),
            p("Pineapple Juice (1 L)", "Fresh-tasting pineapple juice. Naturally sweet and tropical. No added sugar.", "2.99", 180, cat, img, "TropicHarvest", 4.6, 2700),
            p("Cranberry Juice (1 L)", "Unsweetened pure cranberry juice. Tart and refreshing. Great for cocktails.", "3.49", 170, cat, img, "BerryBest", 4.5, 2400),
            p("Tomato Juice (1 L)", "Classic tomato juice. Savoury and rich. Perfect for a Virgin Mary or on its own.", "2.49", 200, cat, img, "PureSqueeze", 4.5, 2200),
            p("Pomegranate Juice (750 ml)", "Pure pomegranate juice. Packed with antioxidants. Intense and tangy.", "5.99", 130, cat, img, "BerryBest", 4.7, 2100),
            p("Grape Juice - Red (1 L)", "Rich red grape juice from pressed Concord grapes. No added sugar.", "3.29", 180, cat, img, "OrchardGold", 4.6, 2500),
            p("Multivitamin Juice (1 L)", "A blend of 7 fruit juices. Fortified with vitamins C, D and zinc.", "3.49", 200, cat, img, "PureSqueeze", 4.6, 2800),
            p("Smoothie - Mango & Passion Fruit (250 ml)", "Thick tropical smoothie blended from fresh mango and passion fruit. No added sugar.", "2.99", 160, cat, img, "PureSqueeze", 4.8, 3100),
            p("Smoothie - Strawberry & Banana (250 ml)", "Thick strawberry and banana smoothie. 100% real fruit. Ideal for breakfast.", "2.99", 160, cat, img, "PureSqueeze", 4.8, 3400),
            p("Smoothie - Green Detox (250 ml)", "Spinach, apple, ginger and cucumber smoothie. Fresh and energising.", "3.49", 140, cat, img, "PureSqueeze", 4.7, 2700),
            p("English Breakfast Tea (80 bags)", "Classic robust English Breakfast blend. Full-bodied and rich. Perfect with milk.", "3.99", 250, cat, img, "ZenLeaf", 4.8, 5400),
            p("Earl Grey Tea (50 bags)", "Aromatic Earl Grey tea with oil of bergamot. Floral and refreshing.", "3.49", 220, cat, img, "ZenLeaf", 4.7, 4200),
            p("Peppermint Tea (25 bags)", "Pure peppermint herbal infusion. Caffeine-free and naturally refreshing.", "2.99", 230, cat, img, "ZenLeaf", 4.7, 3800),
            p("Chamomile Tea (25 bags)", "Gentle chamomile flower herbal tea. Naturally caffeine-free. Great before bed.", "2.99", 220, cat, img, "ZenLeaf", 4.7, 3500),
            p("Rooibos Tea (40 bags)", "South African red bush rooibos. Caffeine-free with a naturally sweet flavour.", "3.49", 190, cat, img, "ZenLeaf", 4.6, 3100),
            p("Ginger & Lemon Tea (20 bags)", "Warming ginger and lemon herbal infusion. Zingy and invigorating.", "2.79", 210, cat, img, "ZenLeaf", 4.7, 3300),
            p("Matcha Powder (80 g)", "Ceremonial grade Japanese matcha. Vivid green and full of antioxidants.", "12.99", 100, cat, img, "ZenLeaf", 4.8, 2900),
            p("Instant Coffee (200 g)", "Smooth and balanced instant coffee. Freeze-dried for maximum freshness.", "5.99", 220, cat, img, "CaffeRoast", 4.5, 4800),
            p("Ground Coffee - Espresso (250 g)", "Finely ground espresso blend. Dark roast with rich chocolate and caramel notes.", "7.99", 180, cat, img, "CaffeRoast", 4.8, 4200),
            p("Ground Coffee - Filter (250 g)", "Medium roast ground coffee for filter and cafetière. Balanced and smooth.", "7.49", 180, cat, img, "CaffeRoast", 4.7, 3800),
            p("Whole Bean Coffee (500 g)", "Premium single-origin whole bean coffee. Roasted in small batches. Grind to order.", "12.99", 120, cat, img, "CaffeRoast", 4.9, 3400),
            p("Coffee Pods - Espresso (pack of 16)", "Nespresso-compatible espresso pods. Intense and full-bodied. Compostable capsules.", "6.99", 160, cat, img, "CaffeRoast", 4.7, 4100),
            p("Oat Milk Barista (1 L)", "Oat milk specifically formulated to steam and froth like dairy. Great for lattes.", "2.99", 200, cat, img, "PureOat", 4.8, 3700),
            p("Kombucha - Original (330 ml)", "Raw fermented kombucha tea. Naturally fizzy with live cultures. Low sugar.", "2.99", 150, cat, img, "ZenLeaf", 4.6, 2800),
            p("Kombucha - Ginger Lemon (330 ml)", "Zingy ginger lemon kombucha. Sparkling, refreshing and rich in probiotics.", "2.99", 140, cat, img, "ZenLeaf", 4.7, 2900),
            p("Kefir Drink - Strawberry (500 ml)", "Probiotic kefir drink with real strawberry. Tangy, light and gut-friendly.", "3.49", 130, cat, img, "CreamyVale", 4.7, 2300),
            p("Ginger Beer (500 ml)", "Fiery naturally brewed ginger beer. Strong ginger kick. Great as a mixer.", "2.49", 180, cat, img, "AlpineSpring", 4.7, 2700),
            p("Elderflower Cordial (500 ml)", "Premium elderflower cordial made with real elderflower. Dilute to taste.", "4.99", 150, cat, img, "BerryBest", 4.8, 2500),
            p("Lemonade (1.5 L)", "Freshly made cloudy lemonade. Real lemons, no artificial flavours.", "2.49", 220, cat, img, "PureSqueeze", 4.6, 3100),
            p("Orange & Mango Squash (1 L)", "Vibrant orange and mango squash. No artificial colours or flavours. Dilute to taste.", "2.29", 230, cat, img, "PureSqueeze", 4.5, 2900),
            p("Blackcurrant Squash (1 L)", "Intense blackcurrant squash. No added sugar version available. Dilute to taste.", "2.29", 240, cat, img, "BerryBest", 4.5, 3000),
            p("Hot Chocolate Powder (300 g)", "Rich drinking chocolate powder made with real cocoa. Just add hot milk.", "4.99", 180, cat, img, "SweetCrust", 4.7, 3200),
            p("Malted Drink Powder (500 g)", "Classic malted milk drink powder. Comforting and nourishing warm bedtime drink.", "4.49", 160, cat, img, "NutriGrain", 4.6, 2700),
            p("Protein Shake - Vanilla (500 ml)", "Ready-to-drink whey protein shake with 25g protein. No artificial sweeteners.", "3.99", 150, cat, img, "NutriGrain", 4.6, 2900),
            p("Protein Shake - Chocolate (500 ml)", "Ready-to-drink chocolate protein shake. 25g protein per bottle. Post-workout essential.", "3.99", 150, cat, img, "NutriGrain", 4.6, 2800),
            p("Cold Brew Coffee (330 ml)", "Smooth cold brew coffee. Slow-steeped for 18 hours. Less bitter than hot coffee.", "3.49", 140, cat, img, "CaffeRoast", 4.8, 2600),
            p("Sparkling Lemon Water (500 ml)", "Naturally flavoured sparkling water with a hint of lemon. Zero sugar, zero calories.", "1.49", 280, cat, img, "AlpineSpring", 4.6, 3200),
            p("Hibiscus & Berry Iced Tea (500 ml)", "Refreshing iced tea with hibiscus and mixed berries. Lightly sweetened.", "2.49", 180, cat, img, "ZenLeaf", 4.7, 2400),
            p("Turmeric Golden Milk (250 ml)", "Warm blend of turmeric, ginger, cinnamon and oat milk. Anti-inflammatory and comforting.", "3.99", 130, cat, img, "ZenLeaf", 4.7, 2100)
        );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Helper
    // ─────────────────────────────────────────────────────────────────────────
    private Product p(String name, String desc, String price, int stock,
                      String category, String imageUrl, String brand,
                      double rating, int reviews) {
        return Product.builder()
                .name(name)
                .description(desc)
                .price(new BigDecimal(price))
                .stockQuantity(stock)
                .category(category)
                .imageUrl(imageUrl)
                .brand(brand)
                .rating(rating)
                .reviewCount(reviews)
                .active(true)
                .build();
    }
}
