package com.eshop.dto;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public class OrderDto {

    @Data
    public static class PlaceOrderRequest {
        private String shippingAddress;
        private String paymentMethod;
        private String notes;
    }

    @Data
    public static class OrderItemResponse {
        private Long productId;
        private String productName;
        private String productImage;
        private Integer quantity;
        private BigDecimal unitPrice;
        private BigDecimal totalPrice;
    }

    @Data
    public static class OrderResponse {
        private Long id;
        private String orderNumber;
        private List<OrderItemResponse> orderItems;
        private BigDecimal subtotal;
        private BigDecimal tax;
        private BigDecimal shippingCost;
        private BigDecimal totalAmount;
        private String status;
        private String shippingAddress;
        private String paymentMethod;
        private String trackingNumber;
        private LocalDateTime createdAt;
        private LocalDateTime updatedAt;
    }

    @Data
    public static class OrderStatsResponse {
        private long totalOrders;
        private BigDecimal totalSpentLast7Days;
        private BigDecimal totalSpentLastMonth;
        private BigDecimal totalSpentLastQuarter;
        private BigDecimal totalSpentLastYear;
        private List<TopProductResponse> top10Products;
    }

    @Data
    public static class TopProductResponse {
        private String productName;
        private Long totalQuantity;

        public TopProductResponse(String productName, Long totalQuantity) {
            this.productName = productName;
            this.totalQuantity = totalQuantity;
        }
    }
}
