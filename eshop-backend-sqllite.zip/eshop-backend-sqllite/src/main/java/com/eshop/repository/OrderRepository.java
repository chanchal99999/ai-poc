package com.eshop.repository;

import com.eshop.entity.Order;
import com.eshop.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {

    Page<Order> findByUserOrderByCreatedAtDesc(User user, Pageable pageable);

    List<Order> findByUserOrderByCreatedAtDesc(User user);

    Optional<Order> findByOrderNumberAndUser(String orderNumber, User user);

    Optional<Order> findByOrderNumber(String orderNumber);

    long countByUser(User user);

    @Query("SELECT SUM(o.totalAmount) FROM Order o WHERE o.user = :user AND o.createdAt >= :startDate AND o.status != 'CANCELLED'")
    BigDecimal sumTotalAmountByUserAndDateRange(@Param("user") User user, @Param("startDate") LocalDateTime startDate);

    @Query("SELECT oi.product.name, SUM(oi.quantity) as totalQty FROM OrderItem oi " +
           "WHERE oi.order.user = :user AND oi.order.status != 'CANCELLED' " +
           "GROUP BY oi.product.id, oi.product.name ORDER BY totalQty DESC")
    List<Object[]> findTopPurchasedItemsByUser(@Param("user") User user, Pageable pageable);

    @Query("SELECT o FROM Order o WHERE o.user = :user AND o.createdAt >= :startDate ORDER BY o.createdAt DESC")
    List<Order> findByUserAndDateRange(@Param("user") User user, @Param("startDate") LocalDateTime startDate);
}
