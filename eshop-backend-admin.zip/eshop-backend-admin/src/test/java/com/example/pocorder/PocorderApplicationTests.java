package com.example.pocorder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PocorderApplicationTests {

	@Test
	void contextLoads() {
	}

}
