package com.eshop.service;

import com.eshop.dto.ChatDto;
import com.eshop.dto.OrderDto;
import com.eshop.entity.Order;
import com.eshop.entity.OrderItem;
import com.eshop.entity.User;
import com.eshop.repository.OrderRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

/**
 * RAG Chatbot — FreshBot.
 *
 * RAG flow:
 *  1. Retrieve  — query PostgreSQL for orders / stats / item statuses / refunds
 *  2. Augment   — inject retrieved data into the system prompt
 *  3. Generate  — call the LLM via Spring AI ChatClient
 */
@Service
@Slf4j
public class ChatbotService {

    private final ChatClient      chatClient;
    private final OrderRepository orderRepository;
    private final OrderService    orderService;

    public ChatbotService(ChatClient.Builder chatClientBuilder,
                          OrderRepository orderRepository,
                          OrderService orderService) {
        this.chatClient      = chatClientBuilder.build();
        this.orderRepository = orderRepository;
        this.orderService    = orderService;
    }

    // ─── Public API ───────────────────────────────────────────────────────────

    @Transactional(readOnly = true)
    public ChatDto.ChatResponse processMessage(User user, String message) {
        String context      = retrieveContext(user, message.toLowerCase());
        String systemPrompt = buildSystemPrompt(context);
        String aiReply      = callAI(systemPrompt, message);
        return new ChatDto.ChatResponse(aiReply, "text");
    }

    // ─── Step 1: Retrieval ────────────────────────────────────────────────────

    private String retrieveContext(User user, String msg) {
        StringBuilder ctx = new StringBuilder();

        ctx.append("=== CUSTOMER CONTEXT ===\n")
           .append("Customer : ").append(user.getFirstName()).append(" ").append(user.getLastName()).append("\n")
           .append("Email    : ").append(user.getEmail()).append("\n\n");

        // ── Intent flags ──────────────────────────────────────────────────────

        boolean wantsLastOrder = containsAny(msg,
                "last order", "latest order", "recent order", "current order",
                "my last order", "my latest order", "my recent order", "my current order",
                "my order", "order status", "status of my", "status of order",
                "check my order", "view my order", "show my order",
                "where is my", "where's my", "track my", "track my order",
                "my delivery", "when will my", "when is my", "is my order",
                "order update", "order progress", "how is my order",
                "what is my order", "what's my order", "what happened to",
                "have i ordered", "did i order", "placed an order",
                "my purchase", "my package");

        // wantsRefund also covers asking about rejected/adjusted items so
        // we always load the full order context with refund amounts
        boolean wantsRefund = containsAny(msg,
                "refund", "money back", "get back", "how much back", "reimburse",
                "reimbursement", "compensation", "overcharged",
                "cancel refund", "return money", "paid back", "refund status", "my refund",
                "what do i get back", "how much will i get",
                // rejected / adjusted keywords always need refund context
                "rejected", "reject", "removed", "unavailable", "out of stock",
                "not available", "missing item", "adjusted", "adjust",
                "partial", "reduced quantity", "short", "less than ordered");

        // Stats only when NOT asking about a specific order or refund
        boolean wantsStats = !wantsLastOrder && !wantsRefund && containsAny(msg,
                "spent", "total", "statistic", "stat",
                "top", "most purchased", "how many orders", "how many", "grocery",
                "bought", "spending", "amount", "money");

        boolean wantsOrderHistory = !wantsLastOrder && !wantsRefund && containsAny(msg,
                "order history", "all orders", "past orders", "previous orders",
                "order list", "my orders", "show orders", "show my orders",
                "list orders", "all my orders");

        // ── Order statistics ──────────────────────────────────────────────────
        if (wantsStats) {
            OrderDto.OrderStatsResponse stats = orderService.getOrderStats(user);
            ctx.append("=== ORDER STATISTICS ===\n")
               .append("Total Orders               : ").append(stats.getTotalOrders()).append("\n")
               .append("Total Spent (All Time)     : $").append(stats.getTotalSpentAllTime()).append("\n")
               .append("Amount Spent (Last 7 days) : $").append(stats.getTotalSpentLast7Days()).append("\n")
               .append("Amount Spent (Last Month)  : $").append(stats.getTotalSpentLastMonth()).append("\n")
               .append("Amount Spent (Last Quarter): $").append(stats.getTotalSpentLastQuarter()).append("\n")
               .append("Amount Spent (Last Year)   : $").append(stats.getTotalSpentLastYear()).append("\n");

            if (!stats.getTop10Products().isEmpty()) {
                ctx.append("\nTop 10 Most Purchased Grocery Items:\n");
                int rank = 1;
                for (OrderDto.TopProductResponse item : stats.getTop10Products()) {
                    ctx.append(rank++).append(". ")
                       .append(item.getProductName())
                       .append(" — Qty: ").append(item.getTotalQuantity()).append("\n");
                }
            }
        }

        // ── Last / current order — full detail + refund if applicable ─────────
        if (wantsLastOrder || wantsRefund) {
            List<Order> latest = orderRepository.findLatestOrderWithItems(user);

            if (latest.isEmpty()) {
                ctx.append("=== LAST ORDER ===\nNo orders found for this account.\n");
            } else {
                Order o = latest.get(0);
                DateTimeFormatter fmt = DateTimeFormatter.ofPattern("MMM dd, yyyy HH:mm");

                ctx.append("=== LAST ORDER (most recent) ===\n")
                   .append("Order Number : ").append(o.getOrderNumber()).append("\n")
                   .append("Status       : ").append(o.getStatus().name()).append("\n")
                   .append("Placed On    : ").append(o.getCreatedAt().format(fmt)).append("\n")
                   .append("Last Updated : ").append(o.getUpdatedAt() != null
                           ? o.getUpdatedAt().format(fmt) : "—").append("\n")
                   .append("Tracking #   : ").append(o.getTrackingNumber() != null
                           ? o.getTrackingNumber() : "Not yet assigned").append("\n")
                   .append("Subtotal     : $").append(o.getSubtotal()).append("\n")
                   .append("Tax          : $").append(o.getTax()).append("\n")
                   .append("Shipping     : $").append(o.getShippingCost()).append("\n")
                   .append("Total        : $").append(o.getTotalAmount()).append("\n")
                   .append("Ship To      : ").append(o.getShippingAddress() != null
                           ? o.getShippingAddress() : "—").append("\n")
                   .append("\nItems (").append(o.getOrderItems().size()).append("):\n");

                o.getOrderItems().forEach(i -> {
                    ctx.append("  ").append(itemStatusEmoji(i.getItemStatus()))
                       .append(" ").append(i.getProduct().getName())
                       .append(" x").append(i.getQuantity())
                       .append(" @ $").append(i.getUnitPrice())
                       .append("  subtotal $").append(i.getTotalPrice())
                       .append("  [").append(i.getItemStatus().name()).append("]");
                    if (i.getItemStatus() == OrderItem.ItemStatus.ADJUSTED
                            && i.getAdjustedQuantity() != null) {
                        ctx.append(" → adjusted to x").append(i.getAdjustedQuantity());
                    }
                    if (i.getStatusReason() != null && !i.getStatusReason().isBlank()) {
                        ctx.append(" — reason: ").append(i.getStatusReason());
                    }
                    ctx.append("\n");
                });

                // Always append refund block if order has rejected/adjusted items
                appendRefundContext(ctx, o);
            }
        }

        // ── Refund-specific: scan recent orders if asking about refunds broadly ─
        if (wantsRefund) {
            // Also scan last 3 months for any orders that have refundable items
            List<Order> recentOrders = orderRepository.findByUserAndDateRange(
                    user, LocalDateTime.now().minusMonths(3));

            List<Order> ordersWithRefunds = recentOrders.stream()
                    .filter(o -> o.getOrderItems().stream().anyMatch(i ->
                            i.getItemStatus() == OrderItem.ItemStatus.REJECTED ||
                            (i.getItemStatus() == OrderItem.ItemStatus.ADJUSTED
                             && i.getAdjustedQuantity() != null
                             && i.getAdjustedQuantity() < i.getQuantity())))
                    .collect(Collectors.toList());

            if (!ordersWithRefunds.isEmpty()) {
                ctx.append("\n=== ALL ORDERS WITH REFUNDS (last 3 months) ===\n");
                ordersWithRefunds.forEach(o -> appendRefundContext(ctx, o));
            } else {
                ctx.append("\n=== REFUND STATUS ===\n")
                   .append("No rejected or adjusted items found in your recent orders.\n")
                   .append("All items were fulfilled as ordered.\n");
            }
        }

        // ── Order history list ────────────────────────────────────────────────
        if (wantsOrderHistory) {
            List<Order> recent = orderRepository.findByUserAndDateRange(
                    user, LocalDateTime.now().minusMonths(3));
            if (!recent.isEmpty()) {
                DateTimeFormatter fmt = DateTimeFormatter.ofPattern("MMM dd, yyyy");
                ctx.append("\n=== RECENT ORDERS (last 3 months) ===\n");
                recent.stream().limit(10).forEach(o ->
                    ctx.append("Order #").append(o.getOrderNumber())
                       .append(" | Date: ").append(o.getCreatedAt().format(fmt))
                       .append(" | Status: ").append(o.getStatus().name())
                       .append(" | Total: $").append(o.getTotalAmount())
                       .append(" | Items: ").append(o.getOrderItems().size()).append("\n")
                );
            }
        }

        // ── Items by status: PICKED ───────────────────────────────────────────
        if (containsAny(msg, "picked", "pick", "picking", "warehouse", "packed")) {
            appendItemsByStatus(ctx, user, OrderItem.ItemStatus.PICKED,
                    "PICKED ITEMS (packed at warehouse, awaiting dispatch)");
        }

        // ── Items by status: DELIVERED ────────────────────────────────────────
        if (containsAny(msg, "delivered", "delivery", "received", "arrived", "got my")) {
            appendItemsByStatus(ctx, user, OrderItem.ItemStatus.DELIVERED,
                    "DELIVERED ITEMS (successfully received by customer)");
        }

        // ── Items by status: REJECTED ─────────────────────────────────────────
        if (containsAny(msg, "rejected", "reject", "removed",
                "cancelled item", "unavailable", "out of stock", "not available", "missing")) {
            appendItemsByStatus(ctx, user, OrderItem.ItemStatus.REJECTED,
                    "REJECTED ITEMS (unavailable / removed from order)");
        }

        // ── Items by status: ADJUSTED ─────────────────────────────────────────
        if (containsAny(msg, "adjusted", "adjust", "changed",
                "partial", "reduced", "substitut", "short", "less than")) {
            appendItemsByStatus(ctx, user, OrderItem.ItemStatus.ADJUSTED,
                    "ADJUSTED ITEMS (quantity changed due to partial availability)");
        }

        // ── All items with statuses ───────────────────────────────────────────
        if (containsAny(msg, "show my items", "all items", "order items",
                "what did i order", "what items", "list my")) {
            appendAllItemsWithStatus(ctx, user);
        }

        // ── Specific order by number ──────────────────────────────────────────
        if (containsAny(msg, "ord-", "order number", "order #")) {
            for (String word : msg.split("\\s+")) {
                String token = word.replaceAll("[^a-zA-Z0-9-]", "").toUpperCase();
                if (token.startsWith("ORD-")) {
                    try {
                        Order o = orderService.getOrderEntityByNumberAndUser(token, user);
                        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("MMM dd, yyyy");
                        ctx.append("\n=== SPECIFIC ORDER: ").append(o.getOrderNumber()).append(" ===\n")
                           .append("Status  : ").append(o.getStatus().name()).append("\n")
                           .append("Total   : $").append(o.getTotalAmount()).append("\n")
                           .append("Date    : ").append(o.getCreatedAt().format(fmt)).append("\n")
                           .append("Items:\n");
                        o.getOrderItems().forEach(i -> {
                            ctx.append("  ").append(itemStatusEmoji(i.getItemStatus()))
                               .append(" ").append(i.getProduct().getName())
                               .append(" x").append(i.getQuantity())
                               .append(" @ $").append(i.getUnitPrice())
                               .append(" [").append(i.getItemStatus().name()).append("]");
                            if (i.getItemStatus() == OrderItem.ItemStatus.ADJUSTED
                                    && i.getAdjustedQuantity() != null) {
                                ctx.append(" → adjusted to x").append(i.getAdjustedQuantity());
                            }
                            if (i.getStatusReason() != null && !i.getStatusReason().isBlank()) {
                                ctx.append(" — reason: ").append(i.getStatusReason());
                            }
                            ctx.append("\n");
                        });
                        // Always append refund block for specific order lookups too
                        appendRefundContext(ctx, o);
                    } catch (Exception e) {
                        ctx.append("Order ").append(token).append(" was not found for this account.\n");
                    }
                }
            }
        }

        return ctx.toString();
    }

    // ─── Refund context helper ────────────────────────────────────────────────
    // Injects a detailed REFUND block for a single order.
    // If no rejected/adjusted items, appends nothing.

    private void appendRefundContext(StringBuilder ctx, Order order) {
        List<OrderItem> rejected = order.getOrderItems().stream()
                .filter(i -> i.getItemStatus() == OrderItem.ItemStatus.REJECTED)
                .collect(Collectors.toList());

        List<OrderItem> adjusted = order.getOrderItems().stream()
                .filter(i -> i.getItemStatus() == OrderItem.ItemStatus.ADJUSTED
                          && i.getAdjustedQuantity() != null
                          && i.getAdjustedQuantity() < i.getQuantity())
                .collect(Collectors.toList());

        if (rejected.isEmpty() && adjusted.isEmpty()) return;

        // ── Per-item refund amounts ───────────────────────────────────────────
        BigDecimal refundSubtotal = BigDecimal.ZERO;

        ctx.append("\n=== REFUND DETAILS for ").append(order.getOrderNumber()).append(" ===\n");

        if (!rejected.isEmpty()) {
            ctx.append("❌ REJECTED ITEMS (full refund per item):\n");
            for (OrderItem i : rejected) {
                BigDecimal itemRefund = i.getTotalPrice().setScale(2, RoundingMode.HALF_UP);
                refundSubtotal = refundSubtotal.add(itemRefund);
                ctx.append("  • ").append(i.getProduct().getName())
                   .append(" x").append(i.getQuantity())
                   .append(" @ $").append(i.getUnitPrice())
                   .append("  → Refund: $").append(itemRefund);
                if (i.getStatusReason() != null && !i.getStatusReason().isBlank()) {
                    ctx.append("  (Reason: ").append(i.getStatusReason()).append(")");
                }
                ctx.append("\n");
            }
        }

        if (!adjusted.isEmpty()) {
            ctx.append("⚠️ ADJUSTED ITEMS (refund for reduced quantity):\n");
            for (OrderItem i : adjusted) {
                int diff = i.getQuantity() - i.getAdjustedQuantity();
                BigDecimal itemRefund = i.getUnitPrice()
                        .multiply(BigDecimal.valueOf(diff))
                        .setScale(2, RoundingMode.HALF_UP);
                refundSubtotal = refundSubtotal.add(itemRefund);
                ctx.append("  • ").append(i.getProduct().getName())
                   .append(" ordered x").append(i.getQuantity())
                   .append(", delivered x").append(i.getAdjustedQuantity())
                   .append(", refund for x").append(diff)
                   .append(" @ $").append(i.getUnitPrice())
                   .append("  → Refund: $").append(itemRefund);
                if (i.getStatusReason() != null && !i.getStatusReason().isBlank()) {
                    ctx.append("  (Reason: ").append(i.getStatusReason()).append(")");
                }
                ctx.append("\n");
            }
        }

        // ── Totals ────────────────────────────────────────────────────────────
        BigDecimal taxRefund = order.getSubtotal().compareTo(BigDecimal.ZERO) > 0
                ? refundSubtotal
                    .divide(order.getSubtotal(), 6, RoundingMode.HALF_UP)
                    .multiply(order.getTax())
                    .setScale(2, RoundingMode.HALF_UP)
                : BigDecimal.ZERO;

        BigDecimal totalRefund = refundSubtotal.add(taxRefund).setScale(2, RoundingMode.HALF_UP);
        BigDecimal netPayable  = order.getTotalAmount().subtract(totalRefund)
                                      .setScale(2, RoundingMode.HALF_UP);

        ctx.append("\nRefund Breakdown:\n")
           .append("  Item Refund  : $").append(refundSubtotal).append("\n")
           .append("  Tax Refund   : $").append(taxRefund)
           .append(" (proportional to items refunded)\n")
           .append("  TOTAL REFUND : $").append(totalRefund).append("\n")
           .append("  Original Order Total : $").append(order.getTotalAmount()).append("\n")
           .append("  Net Amount Charged   : $").append(netPayable).append("\n")
           .append("  Refund Timeline : 5–7 business days to original payment method\n")
           .append("  Support email   : support@freshbasket.com\n");
    }

    // ─── Items-by-status helper ───────────────────────────────────────────────

    private void appendItemsByStatus(StringBuilder ctx, User user,
                                     OrderItem.ItemStatus status, String heading) {
        List<Order> orders = orderRepository.findByUserAndItemStatus(user, status);
        if (orders.isEmpty()) {
            ctx.append("\n=== ").append(heading).append(" ===\n")
               .append("No items with this status found.\n");
            return;
        }
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("MMM dd, yyyy");
        ctx.append("\n=== ").append(heading).append(" ===\n");
        orders.stream().limit(10).forEach(order -> {
            ctx.append("Order #").append(order.getOrderNumber())
               .append(" (").append(order.getCreatedAt().format(fmt)).append("):\n");
            order.getOrderItems().stream()
                .filter(i -> i.getItemStatus() == status)
                .forEach(i -> {
                    ctx.append("  ").append(itemStatusEmoji(status))
                       .append(" ").append(i.getProduct().getName())
                       .append(" x").append(i.getQuantity())
                       .append(" @ $").append(i.getUnitPrice());
                    if (status == OrderItem.ItemStatus.ADJUSTED && i.getAdjustedQuantity() != null) {
                        ctx.append(" → adjusted to x").append(i.getAdjustedQuantity());
                        int diff = i.getQuantity() - i.getAdjustedQuantity();
                        if (diff > 0) {
                            BigDecimal refund = i.getUnitPrice()
                                    .multiply(BigDecimal.valueOf(diff))
                                    .setScale(2, RoundingMode.HALF_UP);
                            ctx.append("  refund: $").append(refund);
                        }
                    }
                    if (status == OrderItem.ItemStatus.REJECTED) {
                        ctx.append("  refund: $").append(
                                i.getTotalPrice().setScale(2, RoundingMode.HALF_UP));
                    }
                    if (i.getStatusReason() != null && !i.getStatusReason().isBlank()) {
                        ctx.append(" — ").append(i.getStatusReason());
                    }
                    ctx.append("\n");
                });
        });
    }

    // ─── All-items-with-status helper ────────────────────────────────────────

    private void appendAllItemsWithStatus(StringBuilder ctx, User user) {
        List<Order> orders = orderRepository.findByUserAndDateRange(
                user, LocalDateTime.now().minusMonths(3));
        if (orders.isEmpty()) {
            ctx.append("\n=== ALL ORDER ITEMS ===\nNo orders in the last 3 months.\n");
            return;
        }
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("MMM dd, yyyy");
        ctx.append("\n=== ALL ORDER ITEMS (last 3 months) ===\n");
        orders.stream().limit(5).forEach(order -> {
            ctx.append("Order #").append(order.getOrderNumber())
               .append(" | ").append(order.getCreatedAt().format(fmt))
               .append(" | ").append(order.getStatus().name()).append(":\n");
            order.getOrderItems().forEach(i -> {
                ctx.append("  ").append(itemStatusEmoji(i.getItemStatus()))
                   .append(" ").append(i.getProduct().getName())
                   .append(" x").append(i.getQuantity())
                   .append(" [").append(i.getItemStatus().name()).append("]");
                if (i.getItemStatus() == OrderItem.ItemStatus.ADJUSTED
                        && i.getAdjustedQuantity() != null) {
                    ctx.append(" → x").append(i.getAdjustedQuantity());
                }
                if (i.getStatusReason() != null && !i.getStatusReason().isBlank()) {
                    ctx.append(" — ").append(i.getStatusReason());
                }
                ctx.append("\n");
            });
        });
    }

    private String itemStatusEmoji(OrderItem.ItemStatus status) {
        if (status == null) return "⏳";
        return switch (status) {
            case PENDING   -> "⏳";
            case PICKED    -> "📦";
            case DELIVERED -> "✅";
            case ADJUSTED  -> "⚠️";
            case REJECTED  -> "❌";
        };
    }

    // ─── Step 2: Augment ─────────────────────────────────────────────────────

    private String buildSystemPrompt(String context) {
        return """
                You are FreshBot, a friendly customer-service assistant for FreshBasket,
                a premium online grocery store.

                Your capabilities:
                  • Show full details of the customer's most recent order
                  • Show item-level statuses: PICKED, DELIVERED, REJECTED, ADJUSTED
                  • Calculate and explain refund amounts for rejected or adjusted items
                  • Tell the customer exactly how much refund they will receive and why
                  • Report spending stats, top purchased items
                  • Explain invoice downloads

                Item status meanings:
                  ⏳ PENDING   — not yet processed
                  📦 PICKED    — packed at warehouse, being prepared for dispatch
                  ✅ DELIVERED — successfully delivered to customer
                  ⚠️ ADJUSTED  — quantity reduced (partial stock); refund issued for the difference
                  ❌ REJECTED  — item unavailable, removed from order; full item refund issued

                Refund rules (always explain these clearly):
                  • REJECTED item  → full refund = quantity × unit price
                  • ADJUSTED item  → partial refund = (original qty − adjusted qty) × unit price
                  • Tax refund     → proportional to item refund amount
                  • Timeline       → 5–7 business days to original payment method
                  • The REFUND DETAILS section in context contains exact calculated amounts — use those numbers

                Conversation rules:
                  • Only use data from the CUSTOMER CONTEXT section — never invent amounts or order numbers
                  • Format all money as $X.XX
                  • When asked about "my order", "order status", "last order" etc. — use the LAST ORDER data only
                  • When asked about refunds — clearly state each rejected/adjusted item, the refund per item,
                    total refund, and net amount charged, using the REFUND DETAILS from context
                  • Be empathetic when informing about rejected items — apologise and reassure about the refund
                  • Always mention they can download the updated invoice from the Orders page

                CUSTOMER CONTEXT (live data from database):
                """
                + context
                + """

                Respond in a warm, friendly, empathetic grocery-store assistant tone.
                """;
    }

    // ─── Step 3: Generate ─────────────────────────────────────────────────────

    private String callAI(String systemPrompt, String userMessage) {
        try {
            Prompt prompt = new Prompt(List.of(
                    new SystemMessage(systemPrompt),
                    new UserMessage(userMessage)
            ));
            return chatClient.prompt(prompt).call().content();
        } catch (Exception e) {
            log.error("Spring AI call failed: {}", e.getMessage());
            return buildFallbackResponse(userMessage);
        }
    }

    // ─── Fallback (when AI unavailable) ──────────────────────────────────────

    private String buildFallbackResponse(String message) {
        String m = message.toLowerCase();
        if (containsAny(m, "refund", "money back", "get back", "reimburse", "credit",
                        "how much back", "charged", "compensation")) {
            return "I can see your order details but I'm unable to calculate your refund right now. "
                 + "Please visit the **Orders** page to download your invoice — it shows a full "
                 + "**Refund Summary** with exact amounts for any rejected or adjusted items. "
                 + "Refunds are processed within **5–7 business days** to your original payment method. "
                 + "For help, contact **support@freshbasket.com**.";
        }
        if (containsAny(m, "rejected", "reject", "removed", "unavailable", "missing")) {
            return "Rejected items were unavailable and removed from your order. "
                 + "A **full refund** for those items will be credited within 5–7 business days. "
                 + "Download your invoice from the **Orders** page for the exact refund breakdown.";
        }
        if (containsAny(m, "adjusted", "adjust", "partial", "reduced", "less than")) {
            return "Adjusted items had their quantity reduced due to partial stock. "
                 + "You'll receive a **partial refund** for the difference within 5–7 business days. "
                 + "Check your invoice on the **Orders** page for exact amounts.";
        }
        if (containsAny(m, "picked"))    return "Picked items are packed at our warehouse and ready for dispatch. Visit the **Orders** page for details.";
        if (containsAny(m, "delivered")) return "Delivered items were successfully received. Check the **Orders** page for a full breakdown.";
        if (containsAny(m, "invoice", "download")) return "Go to the **Orders** page, find your order and click **Download Invoice**. The PDF includes any refund details.";
        if (containsAny(m, "status", "track", "last order", "latest order", "recent order",
                        "current order", "my order", "order update", "check my order",
                        "my purchase", "have i ordered", "show my order")) {
            return "Visit the **Orders** page to see the full status and details of your most recent order.";
        }
        if (containsAny(m, "spent", "total", "amount"))   return "Your spending breakdown is on the **Statistics** tab of the Orders page.";
        if (containsAny(m, "top", "most", "frequent"))    return "Your **Top 10 most purchased grocery items** are on the Statistics tab of the Orders page.";
        if (containsAny(m, "hello", "hi", "hey", "help")) return "Hi! 🛒 I'm FreshBot! I can help with order status, refund details, item statuses, invoices, and spending stats. What can I help you with?";
        return "I'm here to help with your FreshBasket orders! Ask me about order status, refunds, delivery, or invoices.";
    }

    // ─── Utility ──────────────────────────────────────────────────────────────

    private boolean containsAny(String text, String... keywords) {
        for (String kw : keywords) {
            if (text.contains(kw)) return true;
        }
        return false;
    }
}
