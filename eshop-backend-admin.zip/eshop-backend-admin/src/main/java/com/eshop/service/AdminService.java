package com.eshop.service;

import com.eshop.dto.AdminDto;
import com.eshop.entity.Order;
import com.eshop.entity.OrderItem;
import com.eshop.repository.OrderItemRepository;
import com.eshop.repository.OrderRepository;
import com.eshop.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AdminService {

	private final OrderRepository orderRepository;
	private final OrderItemRepository orderItemRepository;
	private final UserRepository userRepository;

	// ── Dashboard stats ────────────────────────────────────────────────────────

	public AdminDto.DashboardStats getDashboardStats() {
		AdminDto.DashboardStats s = new AdminDto.DashboardStats();
		s.setTotalOrders(orderRepository.count());
		s.setPendingOrders(orderRepository.countByStatus(Order.OrderStatus.PENDING));
		s.setProcessingOrders(orderRepository.countByStatus(Order.OrderStatus.CONFIRMED)
				+ orderRepository.countByStatus(Order.OrderStatus.PROCESSING)
				+ orderRepository.countByStatus(Order.OrderStatus.PICKED)
				+ orderRepository.countByStatus(Order.OrderStatus.SHIPPED));
		s.setDeliveredOrders(orderRepository.countByStatus(Order.OrderStatus.DELIVERED));
		s.setCancelledOrders(orderRepository.countByStatus(Order.OrderStatus.CANCELLED));

		BigDecimal today = orderRepository.sumRevenueFrom(LocalDateTime.now().toLocalDate().atStartOfDay());
		BigDecimal month = orderRepository
				.sumRevenueFrom(LocalDateTime.now().withDayOfMonth(1).toLocalDate().atStartOfDay());
		BigDecimal all = orderRepository.sumAllRevenue();

		s.setRevenueToday(today != null ? today : BigDecimal.ZERO);
		s.setRevenueThisMonth(month != null ? month : BigDecimal.ZERO);
		s.setRevenueAllTime(all != null ? all : BigDecimal.ZERO);
		s.setTotalCustomers(userRepository.count() - 1); // exclude admin
		return s;
	}

	// ── List all orders (paginated, optional status/search filter) ─────────────

	public Page<AdminDto.OrderSummary> getAllOrders(int page, int size, String status, String search) {
		PageRequest pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());

		Page<Order> orders;
		if (search != null && !search.isBlank()) {
			orders = orderRepository.searchOrdersAdmin(search.trim(), pageable);
		} else if (status != null && !status.isBlank() && !status.equals("ALL")) {
			orders = orderRepository.findAllByStatusAdmin(Order.OrderStatus.valueOf(status), pageable);
		} else {
			orders = orderRepository.findAllOrdersAdmin(pageable);
		}
		return orders.map(this::toOrderSummary);
	}

	// ── Get full order detail ──────────────────────────────────────────────────

	public AdminDto.OrderDetail getOrderDetail(Long orderId) {
		Order order = orderRepository.findById(orderId)
				.orElseThrow(() -> new RuntimeException("Order not found: " + orderId));
		return toOrderDetail(order);
	}

	// ── Update order status ────────────────────────────────────────────────────

	@Transactional
	public AdminDto.OrderDetail updateOrderStatus(Long orderId, AdminDto.UpdateOrderStatusRequest req) {
		Order order = orderRepository.findById(orderId).orElseThrow(() -> new RuntimeException("Order not found"));
		order.setStatus(Order.OrderStatus.valueOf(req.getStatus()));
		if (req.getTrackingNumber() != null && !req.getTrackingNumber().isBlank()) {
			order.setTrackingNumber(req.getTrackingNumber());
		}
		// When order is DELIVERED, mark all non-rejected/adjusted items as DELIVERED
		if (order.getStatus() == Order.OrderStatus.DELIVERED) {
			order.getOrderItems().forEach(item -> {
				if (item.getItemStatus() == OrderItem.ItemStatus.PENDING
						|| item.getItemStatus() == OrderItem.ItemStatus.PICKED) {
					item.setItemStatus(OrderItem.ItemStatus.DELIVERED);
				}
			});
		}
		// When order is PICKED/SHIPPED, mark pending items as PICKED
		if (order.getStatus() == Order.OrderStatus.PICKED || order.getStatus() == Order.OrderStatus.SHIPPED) {
			order.getOrderItems().forEach(item -> {
				if (item.getItemStatus() == OrderItem.ItemStatus.PENDING) {
					item.setItemStatus(OrderItem.ItemStatus.PICKED);
				}
			});
		}
		return toOrderDetail(orderRepository.save(order));
	}

	// ── Update single item status (adjust / reject / pick / deliver) ───────────

	@Transactional
	public AdminDto.OrderDetail updateItemStatus(Long orderId, Long itemId, AdminDto.UpdateItemStatusRequest req) {
		orderRepository.findById(orderId).orElseThrow(() -> new RuntimeException("Order not found"));
		OrderItem item = orderItemRepository.findByIdAndOrderId(itemId, orderId)
				.orElseThrow(() -> new RuntimeException("Item not found in this order"));

		OrderItem.ItemStatus newStatus = OrderItem.ItemStatus.valueOf(req.getItemStatus());
		item.setItemStatus(newStatus);

		if (req.getStatusReason() != null)
			item.setStatusReason(req.getStatusReason());

		if (newStatus == OrderItem.ItemStatus.ADJUSTED) {
			if (req.getAdjustedQuantity() == null || req.getAdjustedQuantity() < 1) {
				throw new RuntimeException("adjustedQuantity is required for ADJUSTED status");
			}
			item.setAdjustedQuantity(req.getAdjustedQuantity());
		}

		orderItemRepository.save(item);
		return toOrderDetail(orderRepository.findById(orderId).get());
	}

	// ── Bulk update all items in an order to a given status ───────────────────

	@Transactional
	public AdminDto.OrderDetail bulkUpdateItems(Long orderId, AdminDto.UpdateItemStatusRequest req) {
		Order order = orderRepository.findById(orderId).orElseThrow(() -> new RuntimeException("Order not found"));
		OrderItem.ItemStatus newStatus = OrderItem.ItemStatus.valueOf(req.getItemStatus());
		order.getOrderItems().forEach(item -> {
			item.setItemStatus(newStatus);
			if (req.getStatusReason() != null)
				item.setStatusReason(req.getStatusReason());
		});
		return toOrderDetail(orderRepository.save(order));
	}

	// ── Mappers ────────────────────────────────────────────────────────────────

	private AdminDto.OrderSummary toOrderSummary(Order o) {
		AdminDto.OrderSummary s = new AdminDto.OrderSummary();
		s.setId(o.getId());
		s.setOrderNumber(o.getOrderNumber());
		s.setCustomerName(o.getUser().getFirstName() + " " + o.getUser().getLastName());
		s.setCustomerEmail(o.getUser().getEmail());
		s.setTotalAmount(o.getTotalAmount());
		s.setStatus(o.getStatus().name());
		s.setItemCount(o.getOrderItems().size());
		s.setCreatedAt(o.getCreatedAt());
		s.setUpdatedAt(o.getUpdatedAt());
		return s;
	}

	private AdminDto.OrderDetail toOrderDetail(Order o) {
		AdminDto.OrderDetail d = new AdminDto.OrderDetail();
		d.setId(o.getId());
		d.setOrderNumber(o.getOrderNumber());
		d.setCustomerName(o.getUser().getFirstName() + " " + o.getUser().getLastName());
		d.setCustomerEmail(o.getUser().getEmail());
		d.setCustomerPhone(o.getUser().getPhone());
		d.setShippingAddress(o.getShippingAddress());
		d.setPaymentMethod(o.getPaymentMethod());
		d.setTrackingNumber(o.getTrackingNumber());
		d.setNotes(o.getNotes());
		d.setSubtotal(o.getSubtotal());
		d.setTax(o.getTax());
		d.setShippingCost(o.getShippingCost());
		d.setTotalAmount(o.getTotalAmount());
		d.setStatus(o.getStatus().name());
		d.setCreatedAt(o.getCreatedAt());
		d.setUpdatedAt(o.getUpdatedAt());

		List<AdminDto.OrderItemDetail> items = o.getOrderItems().stream().map(i -> {
			AdminDto.OrderItemDetail id2 = new AdminDto.OrderItemDetail();
			id2.setItemId(i.getId());
			id2.setProductId(i.getProduct().getId());
			id2.setProductName(i.getProduct().getName());
			id2.setProductImage(i.getProduct().getImageUrl());
			id2.setQuantity(i.getQuantity());
			id2.setUnitPrice(i.getUnitPrice());
			id2.setTotalPrice(i.getTotalPrice());
			id2.setItemStatus(i.getItemStatus() != null ? i.getItemStatus().name() : "PENDING");
			id2.setAdjustedQuantity(i.getAdjustedQuantity());
			id2.setStatusReason(i.getStatusReason());
			return id2;
		}).collect(Collectors.toList());
		d.setItems(items);
		return d;
	}
}
