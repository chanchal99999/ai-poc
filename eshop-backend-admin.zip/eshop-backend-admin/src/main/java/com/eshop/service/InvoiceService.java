package com.eshop.service;

import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.eshop.entity.Order;
import com.eshop.entity.OrderItem;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.draw.LineSeparator;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class InvoiceService {

	// ── Colour palette ──────────────────────────────────────────────────────────
	private static final BaseColor BRAND_BLUE = new BaseColor(30, 64, 175);
	private static final BaseColor BRAND_LIGHT = new BaseColor(239, 246, 255);
	private static final BaseColor RED_BG = new BaseColor(254, 226, 226);
	private static final BaseColor RED_TEXT = new BaseColor(153, 27, 27);
	private static final BaseColor AMBER_BG = new BaseColor(254, 243, 199);
	private static final BaseColor AMBER_TEXT = new BaseColor(146, 64, 14);
	private static final BaseColor GREEN_BG = new BaseColor(209, 250, 229);
	private static final BaseColor GREEN_TEXT = new BaseColor(6, 95, 70);
	private static final BaseColor ROW_ALT = new BaseColor(243, 244, 246);
	private static final BaseColor BORDER_COLOR = new BaseColor(229, 231, 235);
	private static final BaseColor GRAY_TEXT = new BaseColor(100, 100, 100);

	public byte[] generateInvoice(Order order) {
		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			Document doc = new Document(PageSize.A4, 50, 50, 50, 50);
			PdfWriter.getInstance(doc, baos);
			doc.open();

			// ── Fonts ─────────────────────────────────────────────────────────
			Font fTitle = new Font(Font.FontFamily.HELVETICA, 24, Font.BOLD, BRAND_BLUE);
			Font fInvoice = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD, BRAND_BLUE);
			Font fHeader = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.WHITE);
			Font fNormal = new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL, BaseColor.DARK_GRAY);
			Font fBold = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.BLACK);
			Font fSmall = new Font(Font.FontFamily.HELVETICA, 9, Font.NORMAL, GRAY_TEXT);
			Font fTotalLbl = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD, BRAND_BLUE);
			Font fRed = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, RED_TEXT);
			Font fAmber = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, AMBER_TEXT);
			Font fGreen = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, GREEN_TEXT);
			Font fRefund = new Font(Font.FontFamily.HELVETICA, 11, Font.BOLD, RED_TEXT);

			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MMM dd, yyyy");

			// ── Classify items ────────────────────────────────────────────────
			List<OrderItem> allItems = order.getOrderItems();
			List<OrderItem> rejectedItems = allItems.stream()
					.filter(i -> i.getItemStatus() == OrderItem.ItemStatus.REJECTED).collect(Collectors.toList());
			List<OrderItem> adjustedItems = allItems.stream()
					.filter(i -> i.getItemStatus() == OrderItem.ItemStatus.ADJUSTED && i.getAdjustedQuantity() != null)
					.collect(Collectors.toList());
			boolean hasRefunds = !rejectedItems.isEmpty() || !adjustedItems.isEmpty();

			// ── Refund maths ──────────────────────────────────────────────────
			// Rejected → refund full item totalPrice
			// Adjusted → refund (originalQty - adjustedQty) * unitPrice
			BigDecimal refundSubtotal = BigDecimal.ZERO;
			for (OrderItem i : rejectedItems) {
				refundSubtotal = refundSubtotal.add(i.getTotalPrice());
			}
			for (OrderItem i : adjustedItems) {
				int diff = i.getQuantity() - i.getAdjustedQuantity();
				if (diff > 0) {
					refundSubtotal = refundSubtotal.add(i.getUnitPrice().multiply(BigDecimal.valueOf(diff)));
				}
			}
			// Proportional tax refund (refundSubtotal / subtotal * tax)
			BigDecimal taxRefund = order.getSubtotal().compareTo(BigDecimal.ZERO) > 0
					? refundSubtotal.divide(order.getSubtotal(), 6, RoundingMode.HALF_UP).multiply(order.getTax())
							.setScale(2, RoundingMode.HALF_UP)
					: BigDecimal.ZERO;
			BigDecimal totalRefund = refundSubtotal.add(taxRefund).setScale(2, RoundingMode.HALF_UP);
			BigDecimal netPayable = order.getTotalAmount().subtract(totalRefund).setScale(2, RoundingMode.HALF_UP);

			// ════════════════════════════════════════════════════════════════════
			// SECTION 1 — HEADER
			// ════════════════════════════════════════════════════════════════════
			PdfPTable headerTable = new PdfPTable(2);
			headerTable.setWidthPercentage(100);
			headerTable.setWidths(new float[] { 1f, 1f });

			PdfPCell companyCell = new PdfPCell();
			companyCell.setBorder(Rectangle.NO_BORDER);
			companyCell.addElement(new Paragraph("FreshBasket", fTitle));
			companyCell.addElement(new Paragraph("Your Premium Online Grocery Store", fSmall));
			headerTable.addCell(companyCell);

			PdfPCell invoiceInfoCell = new PdfPCell();
			invoiceInfoCell.setBorder(Rectangle.NO_BORDER);
			invoiceInfoCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			Paragraph invLabel = new Paragraph(hasRefunds ? "INVOICE / REFUND NOTE" : "INVOICE", fInvoice);
			invLabel.setAlignment(Element.ALIGN_RIGHT);
			invoiceInfoCell.addElement(invLabel);
			Paragraph invNum = new Paragraph("# " + order.getOrderNumber(), fBold);
			invNum.setAlignment(Element.ALIGN_RIGHT);
			invoiceInfoCell.addElement(invNum);
			Paragraph invDate = new Paragraph("Date: " + order.getCreatedAt().format(dtf), fNormal);
			invDate.setAlignment(Element.ALIGN_RIGHT);
			invoiceInfoCell.addElement(invDate);
			headerTable.addCell(invoiceInfoCell);

			doc.add(headerTable);
			doc.add(new LineSeparator());
			doc.add(Chunk.NEWLINE);

			// ════════════════════════════════════════════════════════════════════
			// SECTION 2 — BILL TO / ORDER META
			// ════════════════════════════════════════════════════════════════════
			PdfPTable billTable = new PdfPTable(2);
			billTable.setWidthPercentage(100);
			billTable.setWidths(new float[] { 1f, 1f });

			PdfPCell billToCell = new PdfPCell();
			billToCell.setBorder(Rectangle.NO_BORDER);
			billToCell.addElement(new Paragraph("BILL TO:", fBold));
			String cname = order.getUser().getFirstName() + " " + order.getUser().getLastName();
			billToCell.addElement(new Paragraph(cname, fNormal));
			billToCell.addElement(new Paragraph(order.getUser().getEmail(), fNormal));
			if (order.getShippingAddress() != null)
				billToCell.addElement(new Paragraph(order.getShippingAddress(), fNormal));
			billTable.addCell(billToCell);

			PdfPCell metaCell = new PdfPCell();
			metaCell.setBorder(Rectangle.NO_BORDER);
			metaCell.setHorizontalAlignment(Element.ALIGN_RIGHT);

			// Status badge text
			String statusDisplay = order.getStatus().name();
			Paragraph statusP = new Paragraph("Status: " + statusDisplay, fBold);
			statusP.setAlignment(Element.ALIGN_RIGHT);
			metaCell.addElement(statusP);

			if (order.getPaymentMethod() != null) {
				Paragraph payP = new Paragraph("Payment: " + order.getPaymentMethod(), fNormal);
				payP.setAlignment(Element.ALIGN_RIGHT);
				metaCell.addElement(payP);
			}
			if (order.getTrackingNumber() != null) {
				Paragraph trackP = new Paragraph("Tracking: " + order.getTrackingNumber(), fNormal);
				trackP.setAlignment(Element.ALIGN_RIGHT);
				metaCell.addElement(trackP);
			}
			billTable.addCell(metaCell);

			doc.add(billTable);
			doc.add(Chunk.NEWLINE);

			// ════════════════════════════════════════════════════════════════════
			// SECTION 3 — ITEMS TABLE (5 cols: Product | Qty | Unit Price | Total | Status)
			// ════════════════════════════════════════════════════════════════════
			PdfPTable itemsTable = new PdfPTable(5);
			itemsTable.setWidthPercentage(100);
			itemsTable.setWidths(new float[] { 3.5f, 1f, 1.5f, 1.5f, 1.8f });

			// Column headers
			for (String h : new String[] { "Product", "Qty", "Unit Price", "Total", "Status" }) {
				PdfPCell c = new PdfPCell(new Phrase(h, fHeader));
				c.setBackgroundColor(BRAND_BLUE);
				c.setPadding(8);
				c.setBorder(Rectangle.NO_BORDER);
				if (h.equals("Unit Price") || h.equals("Total"))
					c.setHorizontalAlignment(Element.ALIGN_RIGHT);
				else if (h.equals("Qty") || h.equals("Status"))
					c.setHorizontalAlignment(Element.ALIGN_CENTER);
				itemsTable.addCell(c);
			}

			// Item rows
			boolean alt = false;
			for (OrderItem item : allItems) {
				OrderItem.ItemStatus ist = item.getItemStatus();
				boolean isRejected = ist == OrderItem.ItemStatus.REJECTED;
				boolean isAdjusted = ist == OrderItem.ItemStatus.ADJUSTED && item.getAdjustedQuantity() != null;

				// Row background: rejected=red tint, adjusted=amber tint, else normal
				BaseColor rowBg = isRejected ? RED_BG : isAdjusted ? AMBER_BG : (alt ? ROW_ALT : BaseColor.WHITE);

				// Product name (+ reason if rejected/adjusted)
				Paragraph productPara = new Paragraph(item.getProduct().getName(),
						isRejected ? fRed : isAdjusted ? fAmber : fNormal);
				if ((isRejected || isAdjusted) && item.getStatusReason() != null && !item.getStatusReason().isBlank()) {
					productPara.add(Chunk.NEWLINE);
					productPara.add(new Chunk("  Reason: " + item.getStatusReason(), fSmall));
				}
				PdfPCell nameCell = styledCell(productPara, rowBg, Element.ALIGN_LEFT);
				itemsTable.addCell(nameCell);

				// Qty (show original → adjusted when ADJUSTED)
				String qtyText = isAdjusted ? item.getQuantity() + "→" + item.getAdjustedQuantity()
						: String.valueOf(item.getQuantity());
				Font qtyFont = isRejected ? fRed : isAdjusted ? fAmber : fNormal;
				PdfPCell qtyCell = styledCell(new Phrase(qtyText, qtyFont), rowBg, Element.ALIGN_CENTER);
				itemsTable.addCell(qtyCell);

				// Unit price (strikethrough-style for rejected via red font)
				PdfPCell unitCell = styledCell(new Phrase("$" + item.getUnitPrice(), isRejected ? fRed : fNormal),
						rowBg, Element.ALIGN_RIGHT);
				itemsTable.addCell(unitCell);

				// Line total
				PdfPCell totalCell = styledCell(
						new Phrase("$" + item.getTotalPrice(), isRejected ? fRed : isAdjusted ? fAmber : fBold), rowBg,
						Element.ALIGN_RIGHT);
				itemsTable.addCell(totalCell);

				// Status badge cell
				String statusStr;
				Font statusFont;
				BaseColor badgeBg;
				if (isRejected) {
					statusStr = "REJECTED";
					statusFont = fRed;
					badgeBg = RED_BG;
				} else if (isAdjusted) {
					statusStr = "ADJUSTED";
					statusFont = fAmber;
					badgeBg = AMBER_BG;
				} else if (ist == OrderItem.ItemStatus.DELIVERED) {
					statusStr = "DELIVERED";
					statusFont = fGreen;
					badgeBg = GREEN_BG;
				} else if (ist == OrderItem.ItemStatus.PICKED) {
					statusStr = "PICKED";
					statusFont = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, new BaseColor(14, 165, 233));
					badgeBg = new BaseColor(224, 242, 254);
				} else {
					statusStr = ist != null ? ist.name() : "PENDING";
					statusFont = fNormal;
					badgeBg = rowBg;
				}
				PdfPCell statusBadge = new PdfPCell(new Phrase(statusStr, statusFont));
				statusBadge.setBackgroundColor(badgeBg);
				statusBadge.setPadding(7);
				statusBadge.setBorder(Rectangle.BOTTOM);
				statusBadge.setBorderColor(BORDER_COLOR);
				statusBadge.setHorizontalAlignment(Element.ALIGN_CENTER);
				statusBadge.setVerticalAlignment(Element.ALIGN_MIDDLE);
				itemsTable.addCell(statusBadge);

				alt = !alt;
			}

			doc.add(itemsTable);
			doc.add(Chunk.NEWLINE);

			// ════════════════════════════════════════════════════════════════════
			// SECTION 4 — REFUND DETAIL (only when there are refundable items)
			// ════════════════════════════════════════════════════════════════════
			if (hasRefunds) {
				// Section heading
				Paragraph refundHeading = new Paragraph("REFUND SUMMARY", fBold);
				refundHeading.setSpacingBefore(4);
				doc.add(refundHeading);
				doc.add(new LineSeparator());
				doc.add(Chunk.NEWLINE);

				PdfPTable refundTable = new PdfPTable(4);
				refundTable.setWidthPercentage(100);
				refundTable.setWidths(new float[] { 3.5f, 1.5f, 1.5f, 1.8f });

				// Refund table headers
				for (String h : new String[] { "Item", "Reason", "Qty Refunded", "Refund Amount" }) {
					PdfPCell c = new PdfPCell(new Phrase(h, fHeader));
					c.setBackgroundColor(RED_TEXT);
					c.setPadding(8);
					c.setBorder(Rectangle.NO_BORDER);
					if (h.equals("Refund Amount"))
						c.setHorizontalAlignment(Element.ALIGN_RIGHT);
					else if (h.equals("Qty Refunded"))
						c.setHorizontalAlignment(Element.ALIGN_CENTER);
					refundTable.addCell(c);
				}

				boolean rAlt = false;
				// Rejected rows
				for (OrderItem i : rejectedItems) {
					BaseColor bg = rAlt ? new BaseColor(255, 240, 240) : RED_BG;
					refundTable.addCell(styledCell(new Phrase(i.getProduct().getName(), fRed), bg, Element.ALIGN_LEFT));
					String reason = i.getStatusReason() != null && !i.getStatusReason().isBlank() ? i.getStatusReason()
							: "Item unavailable";
					refundTable.addCell(styledCell(new Phrase(reason, fSmall), bg, Element.ALIGN_LEFT));
					refundTable.addCell(styledCell(new Phrase("×" + i.getQuantity(), fRed), bg, Element.ALIGN_CENTER));
					refundTable.addCell(
							styledCell(new Phrase("$" + i.getTotalPrice().setScale(2, RoundingMode.HALF_UP), fRed), bg,
									Element.ALIGN_RIGHT));
					rAlt = !rAlt;
				}
				// Adjusted rows
				for (OrderItem i : adjustedItems) {
					int diff = i.getQuantity() - i.getAdjustedQuantity();
					if (diff <= 0)
						continue;
					BigDecimal rowRefund = i.getUnitPrice().multiply(BigDecimal.valueOf(diff)).setScale(2,
							RoundingMode.HALF_UP);
					BaseColor bg = rAlt ? new BaseColor(255, 251, 235) : AMBER_BG;
					refundTable
							.addCell(styledCell(new Phrase(i.getProduct().getName(), fAmber), bg, Element.ALIGN_LEFT));
					String reason = i.getStatusReason() != null && !i.getStatusReason().isBlank() ? i.getStatusReason()
							: "Partial stock";
					refundTable.addCell(styledCell(new Phrase(reason, fSmall), bg, Element.ALIGN_LEFT));
					refundTable
							.addCell(
									styledCell(
											new Phrase("×" + diff + " (" + i.getQuantity() + "→"
													+ i.getAdjustedQuantity() + ")", fAmber),
											bg, Element.ALIGN_CENTER));
					refundTable.addCell(styledCell(new Phrase("$" + rowRefund, fAmber), bg, Element.ALIGN_RIGHT));
					rAlt = !rAlt;
				}

				doc.add(refundTable);
				doc.add(Chunk.NEWLINE);
			}

			// ════════════════════════════════════════════════════════════════════
			// SECTION 5 — TOTALS
			// ════════════════════════════════════════════════════════════════════
			PdfPTable totalsTable = new PdfPTable(2);
			totalsTable.setWidthPercentage(42);
			totalsTable.setHorizontalAlignment(Element.ALIGN_RIGHT);

			addTotalRow(totalsTable, "Subtotal:", "$" + order.getSubtotal(), fNormal, fBold, false, null);
			addTotalRow(totalsTable, "Tax (8%):", "$" + order.getTax(), fNormal, fBold, false, null);
			addTotalRow(totalsTable, "Shipping:", "$" + order.getShippingCost(), fNormal, fBold, false, null);

			if (hasRefunds) {
				// Separator line between original amounts and refunds
				addTotalRow(totalsTable, "Original Total:",
						"$" + order.getTotalAmount().setScale(2, RoundingMode.HALF_UP), fBold, fBold, false, null);

				addTotalRow(totalsTable, "Item Refund:", "-$" + refundSubtotal.setScale(2, RoundingMode.HALF_UP),
						fNormal, fRed, false, RED_BG);
				addTotalRow(totalsTable, "Tax Refund:", "-$" + taxRefund, fNormal, fRed, false, RED_BG);
				addTotalRow(totalsTable, "Total Refund:", "-$" + totalRefund, fRefund, fRefund, false, RED_BG);

				// Net payable row
				addTotalRow(totalsTable, "NET PAYABLE:", "$" + netPayable, fTotalLbl, fTotalLbl, true, BRAND_LIGHT);
			} else {
				addTotalRow(totalsTable, "TOTAL:", "$" + order.getTotalAmount(), fTotalLbl, fTotalLbl, true,
						BRAND_LIGHT);
			}

			doc.add(totalsTable);
			doc.add(Chunk.NEWLINE);

			// ════════════════════════════════════════════════════════════════════
			// SECTION 6 — REFUND NOTE (only when hasRefunds)
			// ════════════════════════════════════════════════════════════════════
			if (hasRefunds) {
				doc.add(Chunk.NEWLINE);
				PdfPTable noteTable = new PdfPTable(1);
				noteTable.setWidthPercentage(100);
				String noteText = "REFUND NOTICE: A refund of $" + totalRefund
						+ " will be credited back to your original payment method "
						+ "within 5–7 business days. If you have questions, please contact "
						+ "support@freshbasket.com quoting your order number " + order.getOrderNumber() + ".";
				PdfPCell noteCell = new PdfPCell(
						new Phrase(noteText, new Font(Font.FontFamily.HELVETICA, 9, Font.ITALIC, RED_TEXT)));
				noteCell.setBackgroundColor(RED_BG);
				noteCell.setPadding(10);
				noteCell.setBorder(Rectangle.BOX);
				noteCell.setBorderColor(RED_TEXT);
				noteTable.addCell(noteCell);
				doc.add(noteTable);
				doc.add(Chunk.NEWLINE);
			}

			// ── Footer ────────────────────────────────────────────────────────
			doc.add(new LineSeparator());
			Paragraph footer = new Paragraph("Thank you for shopping with FreshBasket!  |  support@freshbasket.com",
					fSmall);
			footer.setAlignment(Element.ALIGN_CENTER);
			doc.add(footer);

			doc.close();
			return baos.toByteArray();

		} catch (Exception e) {
			throw new RuntimeException("Failed to generate invoice: " + e.getMessage(), e);
		}
	}

	// ── Helpers ─────────────────────────────────────────────────────────────────

	private PdfPCell styledCell(Phrase phrase, BaseColor bg, int align) {
		PdfPCell c = new PdfPCell(phrase);
		c.setBackgroundColor(bg);
		c.setPadding(7);
		c.setBorder(Rectangle.BOTTOM);
		c.setBorderColor(BORDER_COLOR);
		c.setHorizontalAlignment(align);
		c.setVerticalAlignment(Element.ALIGN_MIDDLE);
		return c;
	}

	private void addTotalRow(PdfPTable table, String label, String value, Font labelFont, Font valueFont,
			boolean highlight, BaseColor bgOverride) {
		BaseColor bg = bgOverride != null ? bgOverride : highlight ? BRAND_LIGHT : BaseColor.WHITE;

		PdfPCell lc = new PdfPCell(new Phrase(label, labelFont));
		lc.setBorder(Rectangle.NO_BORDER);
		lc.setPadding(highlight ? 6 : 4);
		lc.setBackgroundColor(bg);
		table.addCell(lc);

		PdfPCell vc = new PdfPCell(new Phrase(value, valueFont));
		vc.setBorder(Rectangle.NO_BORDER);
		vc.setPadding(highlight ? 6 : 4);
		vc.setHorizontalAlignment(Element.ALIGN_RIGHT);
		vc.setBackgroundColor(bg);
		table.addCell(vc);
	}
}
