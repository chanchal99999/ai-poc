package com.eshop.service;

import com.eshop.dto.OrderDto;
import com.eshop.entity.*;
import com.eshop.repository.OrderRepository;
import com.eshop.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;
    private final ProductRepository productRepository;
    private final CartService cartService;

    @Transactional
    public OrderDto.OrderResponse placeOrder(User user, OrderDto.PlaceOrderRequest request) {
        List<CartItem> cartItems = cartService.getCartItems(user);

        if (cartItems.isEmpty()) {
            throw new RuntimeException("Cart is empty");
        }

        // Calculate totals
        BigDecimal subtotal = BigDecimal.ZERO;
        List<OrderItem> orderItems = new ArrayList<>();

        Order order = Order.builder()
                .orderNumber(generateOrderNumber())
                .user(user)
                .status(Order.OrderStatus.PENDING)
                .shippingAddress(request.getShippingAddress())
                .paymentMethod(request.getPaymentMethod())
                .notes(request.getNotes())
                .subtotal(BigDecimal.ZERO)
                .tax(BigDecimal.ZERO)
                .shippingCost(BigDecimal.valueOf(5.99))
                .totalAmount(BigDecimal.ZERO)
                .build();

        for (CartItem cartItem : cartItems) {
            Product product = cartItem.getProduct();

            if (product.getStockQuantity() < cartItem.getQuantity()) {
                throw new RuntimeException("Insufficient stock for: " + product.getName());
            }

            BigDecimal itemTotal = product.getPrice().multiply(BigDecimal.valueOf(cartItem.getQuantity()));
            subtotal = subtotal.add(itemTotal);

            OrderItem orderItem = OrderItem.builder()
                    .order(order)
                    .product(product)
                    .quantity(cartItem.getQuantity())
                    .unitPrice(product.getPrice())
                    .totalPrice(itemTotal)
                    .build();

            orderItems.add(orderItem);

            // Update stock
            product.setStockQuantity(product.getStockQuantity() - cartItem.getQuantity());
            productRepository.save(product);
        }

        BigDecimal tax = subtotal.multiply(BigDecimal.valueOf(0.08));
        BigDecimal total = subtotal.add(tax).add(order.getShippingCost());

        order.setSubtotal(subtotal);
        order.setTax(tax);
        order.setTotalAmount(total);
        order.setOrderItems(orderItems);

        Order savedOrder = orderRepository.save(order);

        // Clear the cart
        cartService.clearCart(user);

        return toOrderResponse(savedOrder);
    }

    public Page<OrderDto.OrderResponse> getUserOrders(User user, Pageable pageable) {
        return orderRepository.findByUserOrderByCreatedAtDesc(user, pageable).map(this::toOrderResponse);
    }

    public OrderDto.OrderResponse getOrderByNumber(User user, String orderNumber) {
        Order order = orderRepository.findByOrderNumberAndUser(orderNumber, user)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        return toOrderResponse(order);
    }

    public OrderDto.OrderStatsResponse getOrderStats(User user) {
        long totalOrders = orderRepository.countByUser(user);

        LocalDateTime now = LocalDateTime.now();
        BigDecimal spentAllTime = orderRepository.sumTotalAmountAllTimeByUser(user);
        BigDecimal spent7Days   = orderRepository.sumTotalAmountByUserAndDateRange(user, now.minusDays(7));
        BigDecimal spentMonth   = orderRepository.sumTotalAmountByUserAndDateRange(user, now.minusMonths(1));
        BigDecimal spentQuarter = orderRepository.sumTotalAmountByUserAndDateRange(user, now.minusMonths(3));
        BigDecimal spentYear    = orderRepository.sumTotalAmountByUserAndDateRange(user, now.minusYears(1));

        List<Object[]> top10Raw = orderRepository.findTopPurchasedItemsByUser(user, PageRequest.of(0, 10));
        List<OrderDto.TopProductResponse> top10 = top10Raw.stream()
                .map(row -> new OrderDto.TopProductResponse((String) row[0], (Long) row[1]))
                .collect(Collectors.toList());

        OrderDto.OrderStatsResponse stats = new OrderDto.OrderStatsResponse();
        stats.setTotalOrders(totalOrders);
        stats.setTotalSpentAllTime(spentAllTime != null ? spentAllTime : BigDecimal.ZERO);
        stats.setTotalSpentLast7Days(spent7Days != null ? spent7Days : BigDecimal.ZERO);
        stats.setTotalSpentLastMonth(spentMonth != null ? spentMonth : BigDecimal.ZERO);
        stats.setTotalSpentLastQuarter(spentQuarter != null ? spentQuarter : BigDecimal.ZERO);
        stats.setTotalSpentLastYear(spentYear != null ? spentYear : BigDecimal.ZERO);
        stats.setTop10Products(top10);

        return stats;
    }

    public Order getOrderEntityByNumber(String orderNumber) {
        return orderRepository.findByOrderNumber(orderNumber)
                .orElseThrow(() -> new RuntimeException("Order not found: " + orderNumber));
    }

    public Order getOrderEntityByNumberAndUser(String orderNumber, User user) {
        return orderRepository.findByOrderNumberAndUser(orderNumber, user)
                .orElseThrow(() -> new RuntimeException("Order not found"));
    }

    private String generateOrderNumber() {
        return "ORD-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }

    private OrderDto.OrderResponse toOrderResponse(Order order) {
        OrderDto.OrderResponse response = new OrderDto.OrderResponse();
        response.setId(order.getId());
        response.setOrderNumber(order.getOrderNumber());
        response.setSubtotal(order.getSubtotal());
        response.setTax(order.getTax());
        response.setShippingCost(order.getShippingCost());
        response.setTotalAmount(order.getTotalAmount());
        response.setStatus(order.getStatus().name());
        response.setShippingAddress(order.getShippingAddress());
        response.setPaymentMethod(order.getPaymentMethod());
        response.setTrackingNumber(order.getTrackingNumber());
        response.setCreatedAt(order.getCreatedAt());
        response.setUpdatedAt(order.getUpdatedAt());

        List<OrderDto.OrderItemResponse> items = order.getOrderItems().stream().map(item -> {
            OrderDto.OrderItemResponse ir = new OrderDto.OrderItemResponse();
            ir.setProductId(item.getProduct().getId());
            ir.setProductName(item.getProduct().getName());
            ir.setProductImage(item.getProduct().getImageUrl());
            ir.setQuantity(item.getQuantity());
            ir.setUnitPrice(item.getUnitPrice());
            ir.setTotalPrice(item.getTotalPrice());
            ir.setItemStatus(item.getItemStatus() != null ? item.getItemStatus().name() : "PENDING");
            ir.setAdjustedQuantity(item.getAdjustedQuantity());
            ir.setStatusReason(item.getStatusReason());
            return ir;
        }).collect(Collectors.toList());

        response.setOrderItems(items);
        return response;
    }
}
