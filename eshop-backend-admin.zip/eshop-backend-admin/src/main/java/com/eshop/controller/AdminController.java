package com.eshop.controller;

import com.eshop.dto.AdminDto;
import com.eshop.service.AdminService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    private final AdminService adminService;

    /** GET /api/admin/dashboard */
    @GetMapping("/dashboard")
    public ResponseEntity<AdminDto.DashboardStats> getDashboard() {
        return ResponseEntity.ok(adminService.getDashboardStats());
    }

    /** GET /api/admin/orders?page=0&size=20&status=PENDING&search=john */
    @GetMapping("/orders")
    public ResponseEntity<Page<AdminDto.OrderSummary>> getAllOrders(
            @RequestParam(defaultValue = "0")   int page,
            @RequestParam(defaultValue = "20")  int size,
            @RequestParam(required = false)     String status,
            @RequestParam(required = false)     String search) {
        return ResponseEntity.ok(adminService.getAllOrders(page, size, status, search));
    }

    /** GET /api/admin/orders/{id} */
    @GetMapping("/orders/{id}")
    public ResponseEntity<AdminDto.OrderDetail> getOrderDetail(@PathVariable Long id) {
        return ResponseEntity.ok(adminService.getOrderDetail(id));
    }

    /** PATCH /api/admin/orders/{id}/status  — change order status */
    @PatchMapping("/orders/{id}/status")
    public ResponseEntity<AdminDto.OrderDetail> updateOrderStatus(
            @PathVariable Long id,
            @RequestBody AdminDto.UpdateOrderStatusRequest req) {
        return ResponseEntity.ok(adminService.updateOrderStatus(id, req));
    }

    /** PATCH /api/admin/orders/{orderId}/items/{itemId}  — adjust/reject/pick/deliver one item */
    @PatchMapping("/orders/{orderId}/items/{itemId}")
    public ResponseEntity<AdminDto.OrderDetail> updateItemStatus(
            @PathVariable Long orderId,
            @PathVariable Long itemId,
            @RequestBody AdminDto.UpdateItemStatusRequest req) {
        return ResponseEntity.ok(adminService.updateItemStatus(orderId, itemId, req));
    }

    /** PATCH /api/admin/orders/{orderId}/items/bulk  — bulk update all items */
    @PatchMapping("/orders/{orderId}/items/bulk")
    public ResponseEntity<AdminDto.OrderDetail> bulkUpdateItems(
            @PathVariable Long orderId,
            @RequestBody AdminDto.UpdateItemStatusRequest req) {
        return ResponseEntity.ok(adminService.bulkUpdateItems(orderId, req));
    }
}
