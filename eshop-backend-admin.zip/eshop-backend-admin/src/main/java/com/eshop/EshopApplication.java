package com.eshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * FreshBasket — Main Spring Boot Application Entry Point
 *
 * @SpringBootApplication
 *   Combines @Configuration + @EnableAutoConfiguration + @ComponentScan.
 *   Auto-detects all beans, Spring AI config, JPA, Security, Web MVC, etc.
 *
 * @EnableTransactionManagement
 *   Activates annotation-driven transaction management so @Transactional
 *   works on CartService, OrderService, etc. (auto-config enables it too,
 *   but explicit declaration makes the intent clear and prevents surprises
 *   if auto-config is ever customised).
 *
 * @EnableJpaRepositories
 *   Explicitly tells Spring Data JPA where to scan for repository interfaces.
 *   Avoids any ambiguity when multiple datasources or packages are present.
 *
 * @EnableScheduling
 *   Enables Spring's @Scheduled task execution — required for any scheduled
 *   jobs (e.g. nightly stock reconciliation, order status sync, cache refresh).
 *
 * @EnableAsync
 *   Enables @Async method execution. Useful for sending notification emails,
 *   generating invoices in the background, or async AI calls without blocking
 *   the request thread.
 */
@SpringBootApplication
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = "com.eshop.repository")
@EnableScheduling
@EnableAsync
public class EshopApplication {

    public static void main(String[] args) {
        SpringApplication.run(EshopApplication.class, args);
    }
}
