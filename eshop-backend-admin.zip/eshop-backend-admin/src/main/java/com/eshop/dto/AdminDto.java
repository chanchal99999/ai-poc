package com.eshop.dto;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public class AdminDto {

    @Data
    public static class OrderSummary {
        private Long id;
        private String orderNumber;
        private String customerName;
        private String customerEmail;
        private BigDecimal totalAmount;
        private String status;
        private int itemCount;
        private LocalDateTime createdAt;
        private LocalDateTime updatedAt;
    }

    @Data
    public static class OrderDetail {
        private Long id;
        private String orderNumber;
        private String customerName;
        private String customerEmail;
        private String customerPhone;
        private String shippingAddress;
        private String paymentMethod;
        private String trackingNumber;
        private String notes;
        private BigDecimal subtotal;
        private BigDecimal tax;
        private BigDecimal shippingCost;
        private BigDecimal totalAmount;
        private String status;
        private LocalDateTime createdAt;
        private LocalDateTime updatedAt;
        private List<OrderItemDetail> items;
    }

    @Data
    public static class OrderItemDetail {
        private Long itemId;
        private Long productId;
        private String productName;
        private String productImage;
        private Integer quantity;
        private BigDecimal unitPrice;
        private BigDecimal totalPrice;
        private String itemStatus;
        private Integer adjustedQuantity;
        private String statusReason;
    }

    /** PATCH /api/admin/orders/{id}/status */
    @Data
    public static class UpdateOrderStatusRequest {
        private String status;          // e.g. CONFIRMED, PROCESSING, PICKED, SHIPPED, DELIVERED, CANCELLED
        private String trackingNumber;  // optional
    }

    /** PATCH /api/admin/orders/{orderId}/items/{itemId} */
    @Data
    public static class UpdateItemStatusRequest {
        private String itemStatus;        // PICKED | DELIVERED | ADJUSTED | REJECTED
        private Integer adjustedQuantity; // required when ADJUSTED
        private String statusReason;      // optional note
    }

    @Data
    public static class DashboardStats {
        private long totalOrders;
        private long pendingOrders;
        private long processingOrders;
        private long deliveredOrders;
        private long cancelledOrders;
        private BigDecimal revenueToday;
        private BigDecimal revenueThisMonth;
        private BigDecimal revenueAllTime;
        private long totalCustomers;
    }
}
