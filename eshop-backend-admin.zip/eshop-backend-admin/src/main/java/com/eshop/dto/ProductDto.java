package com.eshop.dto;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class ProductDto {
    private Long id;
    private String name;
    private String description;
    private BigDecimal price;
    private Integer stockQuantity;
    private String category;
    private String imageUrl;
    private String brand;
    private Double rating;
    private Integer reviewCount;
    private Boolean active;
    private LocalDateTime createdAt;
}
