package com.eshop.dto;

import lombok.Data;
import java.math.BigDecimal;
import java.util.List;

public class CartDto {

    @Data
    public static class CartItemRequest {
        private Long productId;
        private Integer quantity;
    }

    @Data
    public static class CartItemResponse {
        private Long id;
        private Long productId;
        private String productName;
        private String productImage;
        private BigDecimal unitPrice;
        private Integer quantity;
        private BigDecimal totalPrice;
        private Integer stockQuantity;
    }

    @Data
    public static class CartResponse {
        private List<CartItemResponse> items;
        private BigDecimal subtotal;
        private int totalItems;
    }
}
