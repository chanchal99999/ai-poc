package com.eshop.dto;

import lombok.Data;

@Data
public class ChatDto {

    @Data
    public static class ChatRequest {
        private String message;
        private String sessionId;
    }

    @Data
    public static class ChatResponse {
        private String message;
        private String sessionId;
        private String type; // text, order_status, invoice_ready, stats

        public ChatResponse(String message, String type) {
            this.message = message;
            this.type = type;
        }
    }
}
