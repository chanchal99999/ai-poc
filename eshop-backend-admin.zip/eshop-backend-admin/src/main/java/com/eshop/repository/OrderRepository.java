package com.eshop.repository;

import com.eshop.entity.Order;
import com.eshop.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {

    Page<Order> findByUserOrderByCreatedAtDesc(User user, Pageable pageable);
    List<Order> findByUserOrderByCreatedAtDesc(User user);
    Optional<Order> findByOrderNumberAndUser(String orderNumber, User user);
    Optional<Order> findByOrderNumber(String orderNumber);
    long countByUser(User user);

    /** Fetch the most-recent orders for a user with items and products eagerly loaded */
    @Query("SELECT DISTINCT o FROM Order o LEFT JOIN FETCH o.orderItems oi LEFT JOIN FETCH oi.product " +
           "WHERE o.user = :user ORDER BY o.createdAt DESC")
    List<Order> findLatestOrderWithItems(@Param("user") User user);

    // ── Customer spending ──────────────────────────────────────────────────────
    @Query("SELECT SUM(o.totalAmount) FROM Order o WHERE o.user = :user AND o.status != 'CANCELLED'")
    BigDecimal sumTotalAmountAllTimeByUser(@Param("user") User user);

    @Query("SELECT SUM(o.totalAmount) FROM Order o WHERE o.user = :user AND o.createdAt >= :startDate AND o.status != 'CANCELLED'")
    BigDecimal sumTotalAmountByUserAndDateRange(@Param("user") User user, @Param("startDate") LocalDateTime startDate);

    @Query("SELECT oi.product.name, SUM(oi.quantity) as totalQty FROM OrderItem oi " +
           "WHERE oi.order.user = :user AND oi.order.status != 'CANCELLED' " +
           "GROUP BY oi.product.id, oi.product.name ORDER BY totalQty DESC")
    List<Object[]> findTopPurchasedItemsByUser(@Param("user") User user, Pageable pageable);

    @Query("SELECT DISTINCT o FROM Order o LEFT JOIN FETCH o.orderItems oi LEFT JOIN FETCH oi.product " +
           "WHERE o.user = :user AND o.createdAt >= :startDate ORDER BY o.createdAt DESC")
    List<Order> findByUserAndDateRange(@Param("user") User user, @Param("startDate") LocalDateTime startDate);

    @Query("SELECT DISTINCT o FROM Order o LEFT JOIN FETCH o.orderItems oi LEFT JOIN FETCH oi.product " +
           "WHERE o.user = :user AND oi.itemStatus = :itemStatus ORDER BY o.createdAt DESC")
    List<Order> findByUserAndItemStatus(@Param("user") User user, @Param("itemStatus") com.eshop.entity.OrderItem.ItemStatus itemStatus);

    // ── Admin queries ──────────────────────────────────────────────────────────
    @Query("SELECT o FROM Order o ORDER BY o.createdAt DESC")
    Page<Order> findAllOrdersAdmin(Pageable pageable);

    @Query("SELECT o FROM Order o WHERE o.status = :status ORDER BY o.createdAt DESC")
    Page<Order> findAllByStatusAdmin(@Param("status") Order.OrderStatus status, Pageable pageable);

    @Query("SELECT o FROM Order o WHERE " +
           "LOWER(o.user.firstName) LIKE LOWER(CONCAT('%',:q,'%')) OR " +
           "LOWER(o.user.lastName)  LIKE LOWER(CONCAT('%',:q,'%')) OR " +
           "LOWER(o.user.email)     LIKE LOWER(CONCAT('%',:q,'%')) OR " +
           "LOWER(o.orderNumber)    LIKE LOWER(CONCAT('%',:q,'%')) " +
           "ORDER BY o.createdAt DESC")
    Page<Order> searchOrdersAdmin(@Param("q") String query, Pageable pageable);

    long countByStatus(Order.OrderStatus status);

    @Query("SELECT SUM(o.totalAmount) FROM Order o WHERE o.status != 'CANCELLED'")
    BigDecimal sumAllRevenue();

    @Query("SELECT SUM(o.totalAmount) FROM Order o WHERE o.createdAt >= :startDate AND o.status != 'CANCELLED'")
    BigDecimal sumRevenueFrom(@Param("startDate") LocalDateTime startDate);

    @Query("SELECT COUNT(DISTINCT o.user) FROM Order o")
    long countDistinctCustomers();
}
