package com.eshop.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

@Entity
@Table(name = "order_items")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class OrderItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "order_id", nullable = false)
    private Order order;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "product_id", nullable = false)
    private Product product;

    @Column(nullable = false)
    private Integer quantity;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal unitPrice;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal totalPrice;

    /** Per-item fulfillment status — set by warehouse / delivery staff */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private ItemStatus itemStatus = ItemStatus.PENDING;

    /** Adjusted quantity actually delivered (null = full quantity as ordered) */
    private Integer adjustedQuantity;

    /** Reason when item is REJECTED or ADJUSTED */
    private String statusReason;

    public enum ItemStatus {
        PENDING,    // not yet processed
        PICKED,     // picked from warehouse shelf
        DELIVERED,  // successfully delivered to customer
        ADJUSTED,   // quantity reduced (e.g. partial stock available)
        REJECTED    // item unavailable / substitution refused
    }
}
