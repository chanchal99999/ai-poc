package com.eshop.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * MVC-level CORS configuration.
 *
 * Spring Security's CORS filter handles requests that go through the
 * security filter chain. This WebMvcConfigurer handles CORS at the
 * dispatcher servlet level for any requests that bypass the security
 * filter chain (e.g. error responses, actuator endpoints, etc.).
 *
 * Both configs must be consistent — having only one can still cause 403s
 * on certain request paths in Spring Boot 3.x.
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOrigins(
                        "http://localhost:3000",
                        "http://localhost:80",
                        "http://localhost"
                )
                .allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .exposedHeaders("Authorization")
                .allowCredentials(true)
                .maxAge(3600);
    }
}
