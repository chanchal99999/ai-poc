package com.eshop.security;

import com.eshop.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

/**
 * Isolated UserDetailsService implementation.
 *
 * Kept in its own class so that SecurityConfig can inject it directly
 * without touching AuthService — this is the key step that breaks the
 * circular dependency:
 *
 *   OLD (circular):
 *     SecurityConfig → JwtAuthenticationFilter → UserDetailsService (AuthService)
 *                                                      ↑
 *     AuthService → AuthenticationManager ← SecurityConfig
 *
 *   NEW (no cycle):
 *     SecurityConfig → JwtAuthenticationFilter → UserDetailsServiceImpl → UserRepository
 *     AuthService    → UserRepository  (no longer implements UserDetailsService)
 */
@Service
@RequiredArgsConstructor
public class UserDetailsServiceImpl implements UserDetailsService {

    private final UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found: " + email));
    }
}
