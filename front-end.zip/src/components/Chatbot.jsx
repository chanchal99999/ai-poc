import { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Mic, MicOff, Volume2, VolumeX } from 'lucide-react';
import { chatApi } from '../services/api';

// ─── Constants ────────────────────────────────────────────────────────────────

const QUICK_ACTIONS = [
  'Show my order items',
  'Which items were picked?',
  'Which items were delivered?',
  'Any rejected or adjusted items?',
  'How many orders have I placed?',
  'Amount spent this month',
];

const formatTime = (date) =>
  date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

const WELCOME_MESSAGE = {
  id: 'welcome',
  role: 'bot',
  text: `🛒 Hi! I'm **FreshBot**, your FreshBasket assistant!\n\nI can help you with:\n• 📦 Items **picked** at our warehouse\n• ✅ Items **delivered** to you\n• ❌ **Rejected** items (unavailable)\n• ⚠️ **Adjusted** items (quantity changed)\n• Order status & spending stats\n• Invoice downloads\n\nYou can **type** or use the 🎤 **microphone** to talk to me!`,
  time: new Date(),
};

// ─── Speech output helper ─────────────────────────────────────────────────────

const speak = (text, onStart, onEnd) => {
  if (!window.speechSynthesis) return;
  window.speechSynthesis.cancel();

  const clean = text
    .replace(/\*\*(.*?)\*\*/g, '$1')
    .replace(/•/g, '')
    .replace(/\n/g, ' ');

  const utterance   = new SpeechSynthesisUtterance(clean);
  utterance.lang    = 'en-US';
  utterance.rate    = 1.0;
  utterance.pitch   = 1.1;
  utterance.volume  = 1.0;

  const voices    = window.speechSynthesis.getVoices();
  const preferred =
    voices.find((v) => v.lang.startsWith('en') && v.name.toLowerCase().includes('female')) ||
    voices.find((v) => v.lang.startsWith('en')) ||
    voices[0];
  if (preferred) utterance.voice = preferred;

  utterance.onstart = onStart;
  utterance.onend   = onEnd;
  utterance.onerror = onEnd;
  window.speechSynthesis.speak(utterance);
};

// ─── Component ────────────────────────────────────────────────────────────────

export default function Chatbot() {
  const [open, setOpen]                   = useState(false);
  const [messages, setMessages]           = useState([WELCOME_MESSAGE]);
  const [input, setInput]                 = useState('');
  const [loading, setLoading]             = useState(false);

  // Voice input
  const [isListening, setIsListening]     = useState(false);
  const [voiceSupported]                  = useState(
    !!(window.SpeechRecognition || window.webkitSpeechRecognition)
  );
  const [transcript, setTranscript]       = useState('');
  const recognitionRef                    = useRef(null);

  // Audio output
  const [audioEnabled, setAudioEnabled]   = useState(true);
  const [isSpeaking, setIsSpeaking]       = useState(false);
  const [speakingMsgId, setSpeakingMsgId] = useState(null);

  const messagesEndRef = useRef(null);
  const textareaRef    = useRef(null);

  // KEY FIX: refs that always hold the latest values so stale closures
  // inside recognition.onresult never see old state
  const loadingRef      = useRef(loading);
  const audioEnabledRef = useRef(audioEnabled);
  const inputRef        = useRef(input);

  useEffect(() => { loadingRef.current      = loading;      }, [loading]);
  useEffect(() => { audioEnabledRef.current = audioEnabled; }, [audioEnabled]);
  useEffect(() => { inputRef.current        = input;        }, [input]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  useEffect(() => {
    if (window.speechSynthesis) {
      window.speechSynthesis.getVoices();
      window.speechSynthesis.onvoiceschanged = () => window.speechSynthesis.getVoices();
    }
    return () => {
      window.speechSynthesis?.cancel();
      recognitionRef.current?.abort();
    };
  }, []);

  // ── Core send ─────────────────────────────────────────────────────────────────
  //
  //  wasVoice = true  → mic input  → auto-plays bot response
  //  wasVoice = false → text input → silent (no auto-play)
  //
  //  Uses refs for loading & audioEnabled so it's safe to call from
  //  recognition.onresult without stale-closure issues.

  const sendMessage = async (text, wasVoice = false) => {
    const msgText = (text || inputRef.current || '').trim();
    if (!msgText || loadingRef.current) return;

    const userMsg = { id: Date.now(), role: 'user', text: msgText, time: new Date() };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setTranscript('');
    setLoading(true);
    loadingRef.current = true;

    try {
      const { data } = await chatApi.sendMessage({ message: msgText });
      const botMsg = { id: Date.now() + 1, role: 'bot', text: data.message, time: new Date() };
      setMessages((prev) => [...prev, botMsg]);

      // ✅ Auto-play ONLY for voice input. Text input is always silent.
      if (wasVoice && audioEnabledRef.current) {
        setSpeakingMsgId(botMsg.id);
        speak(
          data.message,
          () => setIsSpeaking(true),
          () => { setIsSpeaking(false); setSpeakingMsgId(null); }
        );
      }
    } catch {
      setMessages((prev) => [...prev, {
        id: Date.now() + 1,
        role: 'bot',
        text: "I'm having trouble connecting right now. Please try again or check your orders page directly.",
        time: new Date(),
      }]);
    } finally {
      setLoading(false);
      loadingRef.current = false;
    }
  };

  // ── Voice input ───────────────────────────────────────────────────────────────

  const startListening = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition || isListening) return;

    window.speechSynthesis?.cancel();
    setIsSpeaking(false);

    const recognition           = new SpeechRecognition();
    recognitionRef.current      = recognition;
    recognition.lang            = 'en-US';
    recognition.interimResults  = true;
    recognition.continuous      = false;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => setIsListening(true);

    recognition.onresult = (event) => {
      let interim = '';
      let final   = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const t = event.results[i][0].transcript;
        if (event.results[i].isFinal) final += t;
        else interim += t;
      }
      if (interim) setTranscript(interim);
      if (final) {
        setTranscript('');
        // Call sendMessage directly (not via closure) with wasVoice=true
        sendMessage(final, true);
      }
    };

    recognition.onend   = () => { setIsListening(false); recognitionRef.current = null; };
    recognition.onerror = () => { setIsListening(false); recognitionRef.current = null; };

    recognition.start();
  };

  const stopListening   = () => { recognitionRef.current?.stop(); setIsListening(false); };
  const toggleListening = () => (isListening ? stopListening() : startListening());

  // ── Replay a bot message on demand ───────────────────────────────────────────

  const replayAudio = (msg) => {
    if (isSpeaking && speakingMsgId === msg.id) {
      window.speechSynthesis?.cancel();
      setIsSpeaking(false);
      setSpeakingMsgId(null);
      return;
    }
    setSpeakingMsgId(msg.id);
    speak(
      msg.text,
      () => setIsSpeaking(true),
      () => { setIsSpeaking(false); setSpeakingMsgId(null); }
    );
  };

  // ── Global mute / unmute ──────────────────────────────────────────────────────

  const toggleAudio = () => {
    if (isSpeaking) {
      window.speechSynthesis?.cancel();
      setIsSpeaking(false);
      setSpeakingMsgId(null);
    }
    setAudioEnabled((prev) => !prev);
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input, false); // wasVoice=false → no auto-play
    }
  };

  const renderText = (text) =>
    text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br/>');

  const unreadCount = messages.filter((m) => m.role === 'bot').length - 1;

  // ─────────────────────────────────────────────────────────────────────────────
  return (
    <div className="chatbot-wrapper">
      {open && (
        <div className="chatbot-panel">

          {/* Header */}
          <div className="chatbot-header">
            <div className="bot-avatar">🛒</div>
            <div className="bot-info" style={{ flex: 1 }}>
              <h4>FreshBot</h4>
              <p>
                <span className="online-dot" />
                {isSpeaking
                  ? '🔊 Speaking…'
                  : isListening
                  ? '🎤 Listening…'
                  : 'Your grocery assistant'}
              </p>
            </div>

            {/* Mute / unmute */}
            <button
              onClick={toggleAudio}
              title={audioEnabled ? 'Mute voice replies' : 'Enable voice replies'}
              style={{
                background: 'none', border: 'none', cursor: 'pointer', padding: '4px 8px',
                borderRadius: 6, marginRight: 2, display: 'flex', alignItems: 'center',
                color: audioEnabled ? '#a5f3fc' : 'rgba(255,255,255,0.35)',
                transition: 'color 0.2s',
              }}
            >
              {audioEnabled ? <Volume2 size={17} /> : <VolumeX size={17} />}
            </button>

            <button
              onClick={() => setOpen(false)}
              style={{ background: 'none', border: 'none', color: 'rgba(255,255,255,0.7)', cursor: 'pointer' }}
            >
              <X size={18} />
            </button>
          </div>

          {/* Messages */}
          <div className="chatbot-messages">
            {messages.map((msg) => (
              <div key={msg.id} className={`chat-message ${msg.role}`}>
                <div
                  className="message-bubble"
                  dangerouslySetInnerHTML={{ __html: renderText(msg.text) }}
                />
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 2 }}>
                  <span className="message-time">{formatTime(msg.time)}</span>
                  {msg.role === 'bot' && window.speechSynthesis && (
                    <button
                      onClick={() => replayAudio(msg)}
                      title={isSpeaking && speakingMsgId === msg.id ? 'Stop' : 'Listen'}
                      style={{
                        background: 'none', border: 'none', cursor: 'pointer', padding: 0,
                        color: isSpeaking && speakingMsgId === msg.id
                          ? 'var(--primary)' : 'var(--gray-400)',
                        display: 'flex', alignItems: 'center', transition: 'color 0.2s',
                      }}
                    >
                      <Volume2 size={13} />
                    </button>
                  )}
                </div>
              </div>
            ))}

            {loading && (
              <div className="chat-message bot">
                <div className="message-bubble">
                  <div className="typing-indicator"><span /><span /><span /></div>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Quick actions */}
          {messages.length <= 2 && (
            <div className="quick-actions">
              {QUICK_ACTIONS.map((action) => (
                <button
                  key={action}
                  className="quick-action-btn"
                  onClick={() => sendMessage(action, false)}
                >
                  {action}
                </button>
              ))}
            </div>
          )}

          {/* Live transcript strip */}
          {(isListening || transcript) && (
            <div style={{
              padding: '6px 14px', background: '#eff6ff',
              borderTop: '1px solid #bfdbfe', fontSize: 12, color: '#3b82f6',
              display: 'flex', alignItems: 'center', gap: 6,
            }}>
              <span style={{
                width: 8, height: 8, borderRadius: '50%', background: '#ef4444',
                flexShrink: 0, animation: 'pulse 1s infinite',
              }} />
              {transcript || 'Listening… speak now'}
            </div>
          )}

          {/* Input bar */}
          <div className="chatbot-input">
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={isListening ? 'Listening…' : 'Ask about your orders…'}
              rows={1}
              disabled={isListening}
              style={{ opacity: isListening ? 0.6 : 1, flex: 1 }}
            />

            {voiceSupported && (
              <button
                onClick={toggleListening}
                disabled={loading}
                title={isListening ? 'Stop listening' : 'Speak your message'}
                style={{
                  background: isListening ? '#ef4444' : 'transparent',
                  border: `1.5px solid ${isListening ? '#ef4444' : 'var(--gray-200)'}`,
                  borderRadius: 10, padding: '6px 10px',
                  cursor: loading ? 'not-allowed' : 'pointer',
                  color: isListening ? 'white' : 'var(--gray-500)',
                  display: 'flex', alignItems: 'center',
                  transition: 'all 0.2s',
                  animation: isListening ? 'pulse 1s infinite' : 'none',
                  flexShrink: 0,
                }}
              >
                {isListening ? <MicOff size={16} /> : <Mic size={16} />}
              </button>
            )}

            <button
              className="send-btn"
              onClick={() => sendMessage(input, false)}
              disabled={loading || (!input.trim() && !transcript)}
            >
              <Send size={16} />
            </button>
          </div>

        </div>
      )}

      {/* Floating toggle */}
      <button className="chatbot-toggle" onClick={() => setOpen(!open)}>
        {open ? <X size={22} /> : <MessageCircle size={22} />}
        {!open && unreadCount > 0 && (
          <span style={{
            position: 'absolute', top: -4, right: -4,
            background: 'var(--accent)', color: 'var(--dark)',
            borderRadius: '50%', width: 18, height: 18,
            fontSize: 11, fontWeight: 700,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            {unreadCount}
          </span>
        )}
      </button>
    </div>
  );
}
