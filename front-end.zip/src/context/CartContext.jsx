import { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { cartApi } from '../services/api';
import { useAuth } from './AuthContext';
import toast from 'react-hot-toast';

const CartContext = createContext(null);

export const CartProvider = ({ children }) => {
  const { isAuthenticated } = useAuth();
  const [cart, setCart] = useState({ items: [], subtotal: 0, totalItems: 0 });
  const [loading, setLoading] = useState(false);

  const fetchCart = useCallback(async () => {
    if (!isAuthenticated) return;
    try {
      const { data } = await cartApi.get();
      setCart(data);
    } catch {}
  }, [isAuthenticated]);

  useEffect(() => { fetchCart(); }, [fetchCart]);

  const addToCart = useCallback(async (productId, quantity = 1) => {
    setLoading(true);
    try {
      const { data } = await cartApi.add({ productId, quantity });
      setCart(data);
      toast.success('Added to cart!');
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to add to cart');
    } finally {
      setLoading(false);
    }
  }, []);

  const updateItem = useCallback(async (itemId, quantity) => {
    try {
      const { data } = await cartApi.update(itemId, quantity);
      setCart(data);
    } catch (error) {
      toast.error('Failed to update cart');
    }
  }, []);

  const removeItem = useCallback(async (itemId) => {
    try {
      const { data } = await cartApi.remove(itemId);
      setCart(data);
      toast.success('Item removed');
    } catch {
      toast.error('Failed to remove item');
    }
  }, []);

  const clearCart = useCallback(async () => {
    try {
      await cartApi.clear();
      setCart({ items: [], subtotal: 0, totalItems: 0 });
    } catch {}
  }, []);

  return (
    <CartContext.Provider value={{ cart, addToCart, updateItem, removeItem, clearCart, fetchCart, loading }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used within CartProvider');
  return ctx;
};
