import axios from 'axios';

const api = axios.create({ baseURL: 'http://localhost:8080/api/api' });
api.interceptors.request.use(cfg => {
  const token = localStorage.getItem('token');
  if (token) cfg.headers.Authorization = `Bearer ${token}`;
  return cfg;
});

export const adminApi = {
  getDashboard:      ()                        => api.get('/admin/dashboard'),
  getOrders:         (params)                  => api.get('/admin/orders', { params }),
  getOrderDetail:    (id)                      => api.get(`/admin/orders/${id}`),
  updateOrderStatus: (id, data)                => api.patch(`/admin/orders/${id}/status`, data),
  updateItemStatus:  (orderId, itemId, data)   => api.patch(`/admin/orders/${orderId}/items/${itemId}`, data),
  bulkUpdateItems:   (orderId, data)           => api.patch(`/admin/orders/${orderId}/items/bulk`, data),
};
