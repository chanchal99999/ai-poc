import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, Zap, Shield, Truck, Leaf } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const FEATURES = [
  { icon: <Leaf size={24} />,   title: 'Farm Fresh',      desc: 'Produce sourced directly from local farms and trusted suppliers' },
  { icon: <Truck size={24} />,  title: 'Same-Day Delivery', desc: 'Order before noon and get groceries at your door by evening' },
  { icon: <Shield size={24} />, title: 'Freshness Guarantee', desc: 'Not satisfied? We replace or refund — no questions asked' },
  { icon: <Zap size={24} />,    title: 'Quick Checkout',  desc: 'Save your lists and reorder your weekly staples in seconds' },
];

const CATEGORIES = [
  { name: 'Fruits & Vegetables', emoji: '🍎', color: '#dcfce7' },
  { name: 'Dairy & Eggs',        emoji: '🥛', color: '#fef9c3' },
  { name: 'Bakery & Bread',      emoji: '🍞', color: '#ffedd5' },
  { name: 'Meat & Seafood',      emoji: '🥩', color: '#fee2e2' },
  { name: 'Pantry & Dry Goods',  emoji: '🫙', color: '#e0e7ff' },
  { name: 'Beverages',           emoji: '🥤', color: '#dbeafe' },
];

export default function HomePage() {
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();

  return (
    <div>
      {/* Hero */}
      <section className="hero">
        <div className="hero-content">
          <div className="hero-badge">
            <Leaf size={14} />
            Fresh produce delivered daily
          </div>
          <h1>
            Fresh Groceries,<br />
            Right to Your <span>Door</span>
          </h1>
          <p>
            Shop farm-fresh produce, dairy, bakery goods and more — all with AI-powered assistance and same-day delivery.
          </p>
          <div className="hero-buttons">
            <Link to="/products" className="btn btn-accent btn-lg">
              Shop Now <ArrowRight size={18} />
            </Link>
            {!isAuthenticated && (
              <Link to="/register" className="btn btn-lg"
                style={{ background: 'rgba(255,255,255,0.15)', color: 'white', border: '1.5px solid rgba(255,255,255,0.3)' }}>
                Create Account
              </Link>
            )}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section style={{ padding: '64px 0', background: 'white' }}>
        <div className="container">
          <div style={{ textAlign: 'center', marginBottom: 40 }}>
            <h2 style={{ fontSize: 32, marginBottom: 8 }}>Shop by Category</h2>
            <p style={{ color: 'var(--gray-500)' }}>Everything you need for your weekly shop</p>
          </div>

          <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', justifyContent: 'center' }}>
            {CATEGORIES.map(cat => (
              <button
                key={cat.name}
                onClick={() => navigate(`/products?category=${encodeURIComponent(cat.name)}`)}
                style={{
                  background: cat.color,
                  border: 'none', borderRadius: 16,
                  padding: '24px 28px',
                  cursor: 'pointer',
                  display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
                  minWidth: 120, transition: 'all 0.2s',
                }}
                onMouseEnter={e => e.currentTarget.style.transform = 'translateY(-4px)'}
                onMouseLeave={e => e.currentTarget.style.transform = 'translateY(0)'}
              >
                <span style={{ fontSize: 32 }}>{cat.emoji}</span>
                <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--gray-700)', textAlign: 'center' }}>
                  {cat.name}
                </span>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section style={{ padding: '64px 0', background: 'var(--gray-50)' }}>
        <div className="container">
          <div style={{ textAlign: 'center', marginBottom: 40 }}>
            <h2 style={{ fontSize: 32, marginBottom: 8 }}>Why Choose FreshBasket?</h2>
            <p style={{ color: 'var(--gray-500)' }}>The freshest groceries with the smoothest experience</p>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 24 }}>
            {FEATURES.map(feat => (
              <div key={feat.title} className="card" style={{ padding: 28, textAlign: 'center' }}>
                <div style={{
                  width: 56, height: 56, borderRadius: 14,
                  background: '#dcfce7', color: '#16a34a',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  margin: '0 auto 16px',
                }}>
                  {feat.icon}
                </div>
                <h3 style={{ fontSize: 17, marginBottom: 8, fontFamily: 'DM Sans', fontWeight: 700 }}>{feat.title}</h3>
                <p style={{ fontSize: 14, color: 'var(--gray-500)' }}>{feat.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trust banner */}
      <section style={{ padding: '40px 0', background: '#f0fdf4', borderTop: '1px solid #bbf7d0', borderBottom: '1px solid #bbf7d0' }}>
        <div className="container" style={{ display: 'flex', justifyContent: 'center', gap: 48, flexWrap: 'wrap', textAlign: 'center' }}>
          {[
            { value: '10,000+', label: 'Happy Customers' },
            { value: '500+',    label: 'Products Available' },
            { value: '98%',     label: 'On-Time Deliveries' },
            { value: '4.9★',    label: 'Average Rating' },
          ].map(stat => (
            <div key={stat.label}>
              <div style={{ fontSize: 28, fontWeight: 800, color: '#16a34a', fontFamily: 'Playfair Display, serif' }}>
                {stat.value}
              </div>
              <div style={{ fontSize: 13, color: 'var(--gray-500)', marginTop: 4 }}>{stat.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      {!isAuthenticated && (
        <section style={{ padding: '80px 0', background: 'var(--primary-dark)', textAlign: 'center', color: 'white' }}>
          <div className="container">
            <h2 style={{ fontSize: 36, marginBottom: 12 }}>Start Your Fresh Journey Today</h2>
            <p style={{ color: 'rgba(255,255,255,0.7)', marginBottom: 32, fontSize: 16 }}>
              Join thousands of happy households and get farm-fresh groceries with AI-powered assistance.
            </p>
            <div style={{ display: 'flex', gap: 16, justifyContent: 'center', flexWrap: 'wrap' }}>
              <Link to="/register" className="btn btn-accent btn-lg">Create Free Account</Link>
              <Link to="/login" className="btn btn-lg"
                style={{ background: 'rgba(255,255,255,0.1)', color: 'white', border: '1.5px solid rgba(255,255,255,0.3)' }}>
                Sign In
              </Link>
            </div>
          </div>
        </section>
      )}
    </div>
  );
}
