import { useState, useEffect } from 'react';
import { Download, BarChart2, Package, TrendingUp } from 'lucide-react';
import { orderApi } from '../services/api';
import toast from 'react-hot-toast';

function StatCard({ label, value, primary }) {
  return (
    <div className="stat-card">
      <div className="stat-label">{label}</div>
      <div className={`stat-value ${primary ? 'primary' : ''}`}>{value}</div>
    </div>
  );
}

export default function OrdersPage() {
  const [orders, setOrders] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [statsLoading, setStatsLoading] = useState(true);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [downloading, setDownloading] = useState(null);
  const [activeTab, setActiveTab] = useState('orders');

  useEffect(() => {
    orderApi.getAll({ page, size: 10 }).then(({ data }) => {
      setOrders(data.content);
      setTotalPages(data.totalPages);
      setLoading(false);
    }).catch(() => setLoading(false));

    orderApi.getStats().then(({ data }) => {
      setStats(data);
      setStatsLoading(false);
    }).catch(() => setStatsLoading(false));
  }, [page]);

  const downloadInvoice = async (orderNumber) => {
    setDownloading(orderNumber);
    try {
      await orderApi.downloadInvoice(orderNumber);
      toast.success('Invoice downloaded!');
    } catch {
      toast.error('Failed to download invoice');
    } finally {
      setDownloading(null);
    }
  };

  const fmt = (val) => val != null ? `$${Number(val).toFixed(2)}` : '$0.00';

  return (
    <div className="container" style={{ paddingTop: 32, paddingBottom: 48 }}>
      <div className="page-header">
        <h1>My Orders</h1>
        <p>Track your orders, view invoices, and see your shopping stats</p>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 32, borderBottom: '1px solid var(--gray-200)' }}>
        {[{ id: 'orders', label: 'Orders', icon: <Package size={16} /> },
          { id: 'stats', label: 'Statistics', icon: <BarChart2 size={16} /> }
        ].map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            style={{
              display: 'flex', alignItems: 'center', gap: 6,
              padding: '12px 20px', background: 'none', border: 'none', cursor: 'pointer',
              fontFamily: 'DM Sans', fontWeight: 600, fontSize: 14,
              color: activeTab === tab.id ? 'var(--primary)' : 'var(--gray-500)',
              borderBottom: `2px solid ${activeTab === tab.id ? 'var(--primary)' : 'transparent'}`,
              marginBottom: -1,
            }}>
            {tab.icon} {tab.label}
          </button>
        ))}
      </div>

      {/* Orders Tab */}
      {activeTab === 'orders' && (
        <div>
          {loading ? (
            Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="skeleton" style={{ height: 120, borderRadius: 12, marginBottom: 16 }} />
            ))
          ) : orders.length === 0 ? (
            <div className="empty-state">
              <div className="empty-state-icon">📦</div>
              <h3>No orders yet</h3>
              <p>Start shopping to place your first order!</p>
              <a href="/products" className="btn btn-primary">Browse Products</a>
            </div>
          ) : (
            <>
              {orders.map(order => (
                <div key={order.id} className="order-card">
                  <div className="order-card-header">
                    <div>
                      <div className="order-number">{order.orderNumber}</div>
                      <div style={{ fontSize: 13, color: 'var(--gray-500)', marginTop: 2 }}>
                        {new Date(order.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
                      </div>
                    </div>
                    <span className={`order-status status-${order.status}`}>{order.status}</span>
                  </div>

                  <div className="order-card-body">
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                      {order.orderItems?.slice(0, 3).map((item, i) => (
                        <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, background: 'var(--gray-50)', borderRadius: 8, padding: '6px 10px' }}>
                          <img src={item.productImage || 'https://via.placeholder.com/40?text=?'} alt={item.productName}
                            style={{ width: 32, height: 32, borderRadius: 6, objectFit: 'cover' }} />
                          <div>
                            <div style={{ fontSize: 13, fontWeight: 500, maxWidth: 140, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                              {item.productName}
                            </div>
                            <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                              <span style={{ fontSize: 12, color: 'var(--gray-400)' }}>×{item.quantity}</span>
                              {item.itemStatus && item.itemStatus !== 'PENDING' && (
                                <span style={{
                                  fontSize: 10, fontWeight: 700, padding: '1px 6px', borderRadius: 20,
                                  background: item.itemStatus === 'DELIVERED' ? '#d1fae5'
                                            : item.itemStatus === 'PICKED'    ? '#dbeafe'
                                            : item.itemStatus === 'ADJUSTED'  ? '#fef3c7'
                                            : item.itemStatus === 'REJECTED'  ? '#fee2e2'
                                            : 'var(--gray-100)',
                                  color:      item.itemStatus === 'DELIVERED' ? '#065f46'
                                            : item.itemStatus === 'PICKED'    ? '#1e40af'
                                            : item.itemStatus === 'ADJUSTED'  ? '#92400e'
                                            : item.itemStatus === 'REJECTED'  ? '#991b1b'
                                            : 'var(--gray-600)',
                                }}>
                                  { item.itemStatus === 'DELIVERED' ? '✅ Delivered'
                                  : item.itemStatus === 'PICKED'    ? '📦 Picked'
                                  : item.itemStatus === 'ADJUSTED'  ? '⚠️ Adjusted'
                                  : item.itemStatus === 'REJECTED'  ? '❌ Rejected'
                                  : item.itemStatus }
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                      {order.orderItems?.length > 3 && (
                        <div style={{ display: 'flex', alignItems: 'center', fontSize: 13, color: 'var(--gray-400)', padding: '6px 10px' }}>
                          +{order.orderItems.length - 3} more
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="order-card-footer">
                    <div>
                      <span style={{ fontSize: 13, color: 'var(--gray-500)' }}>{order.orderItems?.length} item(s)</span>
                      <span style={{ fontWeight: 800, fontSize: 18, color: 'var(--primary)', marginLeft: 16 }}>
                        ${Number(order.totalAmount).toFixed(2)}
                      </span>
                    </div>
                    <div style={{ display: 'flex', gap: 8 }}>
                      {order.trackingNumber && (
                        <span style={{ fontSize: 12, color: 'var(--gray-500)', alignSelf: 'center' }}>
                          Tracking: {order.trackingNumber}
                        </span>
                      )}
                      <button
                        className="btn btn-outline btn-sm"
                        onClick={() => downloadInvoice(order.orderNumber)}
                        disabled={downloading === order.orderNumber}
                      >
                        <Download size={14} />
                        {downloading === order.orderNumber ? 'Downloading...' : 'Invoice'}
                      </button>
                    </div>
                  </div>
                </div>
              ))}

              {totalPages > 1 && (
                <div className="pagination">
                  <button className="page-btn" disabled={page === 0} onClick={() => setPage(p => p - 1)}>‹</button>
                  {Array.from({ length: totalPages }).map((_, i) => (
                    <button key={i} className={`page-btn ${page === i ? 'active' : ''}`} onClick={() => setPage(i)}>{i + 1}</button>
                  ))}
                  <button className="page-btn" disabled={page >= totalPages - 1} onClick={() => setPage(p => p + 1)}>›</button>
                </div>
              )}
            </>
          )}
        </div>
      )}

      {/* Stats Tab */}
      {activeTab === 'stats' && (
        <div>
          {statsLoading ? (
            <div className="stats-grid">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="skeleton" style={{ height: 100, borderRadius: 12 }} />
              ))}
            </div>
          ) : (
            <>
              <div className="stats-grid">
                <StatCard label="Total Orders"    value={stats?.totalOrders || 0} primary />
                <StatCard label="Total Spend"     value={fmt(stats?.totalSpentAllTime)} primary />
                <StatCard label="Last 7 Days"     value={fmt(stats?.totalSpentLast7Days)} />
                <StatCard label="Last Month"      value={fmt(stats?.totalSpentLastMonth)} />
                <StatCard label="Last Quarter"    value={fmt(stats?.totalSpentLastQuarter)} />
                <StatCard label="Last Year"       value={fmt(stats?.totalSpentLastYear)} />
              </div>

              {stats?.top10Products?.length > 0 && (
                <div className="card" style={{ padding: 28 }}>
                  <h3 style={{ marginBottom: 20, display: 'flex', alignItems: 'center', gap: 8, fontFamily: 'DM Sans', fontWeight: 700, fontSize: 18 }}>
                    <TrendingUp size={20} color="var(--primary)" />
                    Top 10 Most Purchased Items
                  </h3>
                  {stats.top10Products.map((item, i) => (
                    <div key={i} style={{
                      display: 'flex', alignItems: 'center', gap: 16,
                      padding: '12px 0', borderBottom: i < stats.top10Products.length - 1 ? '1px solid var(--gray-100)' : 'none',
                    }}>
                      <div style={{
                        width: 32, height: 32, borderRadius: '50%',
                        background: i < 3 ? 'var(--primary)' : 'var(--gray-200)',
                        color: i < 3 ? 'white' : 'var(--gray-600)',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        fontWeight: 700, fontSize: 13, flexShrink: 0,
                      }}>
                        {i + 1}
                      </div>
                      <div style={{ flex: 1, fontWeight: 500, color: 'var(--gray-800)' }}>{item.productName}</div>
                      <div style={{
                        background: 'var(--gray-100)', borderRadius: 50,
                        padding: '4px 12px', fontSize: 13, fontWeight: 700, color: 'var(--gray-700)',
                      }}>
                        {item.totalQuantity} units
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {!stats?.top10Products?.length && (
                <div className="empty-state">
                  <div className="empty-state-icon">📊</div>
                  <h3>No purchase data yet</h3>
                  <p>Place some orders to see your statistics</p>
                </div>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
}
