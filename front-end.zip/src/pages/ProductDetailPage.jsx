import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ShoppingCart, ArrowLeft, Package, Truck, Plus, Minus, Check } from 'lucide-react';
import { productApi } from '../services/api';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

export default function ProductDetailPage() {
  const { id }       = useParams();
  const navigate     = useNavigate();
  const { addToCart, updateItem, removeItem, cart, loading: cartLoading } = useCart();
  const { isAuthenticated } = useAuth();

  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [qty, setQty]         = useState(1);       // pre-add picker quantity
  const [adding, setAdding]   = useState(false);   // brief "Added!" flash

  useEffect(() => {
    productApi.getById(id).then(({ data }) => {
      setProduct(data);
      setLoading(false);
    }).catch(() => navigate('/products'));
  }, [id, navigate]);

  // Find this product in the live cart
  const cartItem = cart.items?.find((i) => Number(i.productId) === Number(id));
  const inCart   = !!cartItem;

  const handleAdd = async () => {
    if (!isAuthenticated) { navigate('/login'); return; }
    setAdding(true);
    await addToCart(product.id, qty);
    setTimeout(() => setAdding(false), 1200);
  };

  const handleQtyChange = async (newQty) => {
    if (newQty < 1) await removeItem(cartItem.id);
    else            await updateItem(cartItem.id, newQty);
  };

  if (loading) {
    return (
      <div className="container" style={{ padding: '40px 24px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 48 }}>
          <div className="skeleton" style={{ height: 400, borderRadius: 16 }} />
          <div>
            {[200, 120, 80, 160, 40].map((w, i) => (
              <div key={i} className="skeleton" style={{ height: 24, width: w, marginBottom: 16 }} />
            ))}
          </div>
        </div>
      </div>
    );
  }

  const stars = (r) => '★'.repeat(Math.floor(r)) + '☆'.repeat(5 - Math.floor(r));

  return (
    <div className="container" style={{ padding: '40px 24px' }}>
      <button className="btn btn-ghost btn-sm" onClick={() => navigate(-1)} style={{ marginBottom: 24 }}>
        <ArrowLeft size={16} /> Back
      </button>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 48, alignItems: 'start' }}>

        {/* Image */}
        <div style={{ borderRadius: 20, overflow: 'hidden', background: 'var(--gray-100)', aspectRatio: '4/3' }}>
          <img
            src={product.imageUrl || 'https://via.placeholder.com/600x450?text=No+Image'}
            alt={product.name}
            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
          />
        </div>

        {/* Info */}
        <div>
          <div style={{ fontSize: 12, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 1, color: 'var(--primary-light)', marginBottom: 8 }}>
            {product.category}
          </div>

          <h1 style={{ fontSize: 28, fontWeight: 700, color: 'var(--gray-900)', marginBottom: 8, lineHeight: 1.3 }}>
            {product.name}
          </h1>

          {product.brand && (
            <p style={{ color: 'var(--gray-500)', fontSize: 14, marginBottom: 12 }}>by {product.brand}</p>
          )}

          {product.rating && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
              <span style={{ color: 'var(--accent)', fontSize: 18 }}>{stars(product.rating)}</span>
              <span style={{ fontWeight: 600 }}>{product.rating}</span>
              <span style={{ color: 'var(--gray-400)', fontSize: 14 }}>({product.reviewCount?.toLocaleString()} reviews)</span>
            </div>
          )}

          <div style={{ fontSize: 36, fontWeight: 800, color: 'var(--primary)', marginBottom: 20 }}>
            ${product.price}
          </div>

          <p style={{ color: 'var(--gray-600)', lineHeight: 1.7, marginBottom: 24, fontSize: 15 }}>
            {product.description}
          </p>

          {/* Stock badge */}
          <div style={{
            display: 'flex', alignItems: 'center', gap: 8,
            padding: '12px 16px',
            background: product.stockQuantity > 0 ? '#d1fae5' : '#fee2e2',
            borderRadius: 10, marginBottom: 24, fontSize: 14, fontWeight: 600,
            color: product.stockQuantity > 0 ? '#064e3b' : '#991b1b',
          }}>
            <Package size={16} />
            {product.stockQuantity > 0 ? `${product.stockQuantity} in stock` : 'Out of stock'}
          </div>

          {product.stockQuantity > 0 && (
            <>
              {/* ── NOT in cart yet: qty picker + Add button ── */}
              {!inCart && (
                <div style={{ display: 'flex', gap: 12, alignItems: 'center', marginBottom: 24 }}>
                  {/* Pre-add quantity picker */}
                  <div className="qty-control">
                    <button className="qty-btn" onClick={() => setQty((q) => Math.max(1, q - 1))}>
                      <Minus size={14} />
                    </button>
                    <span className="qty-value">{qty}</span>
                    <button className="qty-btn" onClick={() => setQty((q) => Math.min(product.stockQuantity, q + 1))}>
                      <Plus size={14} />
                    </button>
                  </div>

                  <button
                    className="btn btn-primary btn-lg"
                    disabled={cartLoading || adding}
                    onClick={handleAdd}
                    style={{ flex: 1, justifyContent: 'center' }}
                  >
                    {adding ? <Check size={18} /> : <ShoppingCart size={18} />}
                    {isAuthenticated
                      ? adding ? 'Added!' : 'Add to Cart'
                      : 'Sign In to Buy'}
                  </button>
                </div>
              )}

              {/* ── Already in cart: live cart qty controls ── */}
              {inCart && (
                <div style={{ marginBottom: 24 }}>
                  {/* In-cart label */}
                  <div style={{
                    display: 'flex', alignItems: 'center', gap: 6,
                    fontSize: 13, fontWeight: 600, color: 'var(--success)',
                    marginBottom: 12,
                  }}>
                    <Check size={15} />
                    In your cart
                  </div>

                  {/* Live quantity adjuster */}
                  <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
                    <div className="qty-control" style={{ transform: 'scale(1.15)', transformOrigin: 'left' }}>
                      <button
                        className="qty-btn"
                        onClick={() => handleQtyChange(cartItem.quantity - 1)}
                        title={cartItem.quantity === 1 ? 'Remove from cart' : 'Decrease'}
                      >
                        <Minus size={14} />
                      </button>
                      <span className="qty-value" style={{ minWidth: 36, fontWeight: 800, fontSize: 17 }}>
                        {cartItem.quantity}
                      </span>
                      <button
                        className="qty-btn"
                        onClick={() => handleQtyChange(cartItem.quantity + 1)}
                        disabled={cartItem.quantity >= product.stockQuantity}
                        title="Increase"
                      >
                        <Plus size={14} />
                      </button>
                    </div>

                    <div style={{ fontSize: 13, color: 'var(--gray-500)' }}>
                      Subtotal: <strong style={{ color: 'var(--gray-900)' }}>
                        ${(cartItem.quantity * product.price).toFixed(2)}
                      </strong>
                    </div>
                  </div>

                  {/* Quick cart link */}
                  <button
                    className="btn btn-ghost btn-sm"
                    onClick={() => navigate('/cart')}
                    style={{ marginTop: 12 }}
                  >
                    <ShoppingCart size={14} /> View Cart
                  </button>
                </div>
              )}
            </>
          )}

          {/* Delivery info */}
          <div style={{
            padding: 16, background: 'var(--gray-50)', borderRadius: 12,
            display: 'flex', alignItems: 'center', gap: 12,
            color: 'var(--gray-600)', fontSize: 14,
          }}>
            <Truck size={20} color="var(--primary)" />
            <div>
              <strong style={{ color: 'var(--gray-800)' }}>Free Shipping</strong> on orders over $50.
              Estimated delivery: 3–5 business days.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
