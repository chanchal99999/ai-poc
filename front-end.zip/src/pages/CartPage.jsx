import { useNavigate } from 'react-router-dom';
import { Trash2, ShoppingBag, ArrowRight } from 'lucide-react';
import { useCart } from '../context/CartContext';

export default function CartPage() {
  const { cart, updateItem, removeItem } = useCart();
  const navigate = useNavigate();

  if (!cart.items?.length) {
    return (
      <div className="container">
        <div className="empty-state" style={{ paddingTop: 120 }}>
          <div className="empty-state-icon">🛒</div>
          <h3>Your cart is empty</h3>
          <p>Add some products to get started!</p>
          <button className="btn btn-primary" onClick={() => navigate('/products')}>
            Start Shopping
          </button>
        </div>
      </div>
    );
  }

  const tax = cart.subtotal * 0.08;
  const shipping = cart.subtotal > 50 ? 0 : 5.99;
  const total = cart.subtotal + tax + shipping;

  return (
    <div className="container" style={{ paddingTop: 32, paddingBottom: 48 }}>
      <h1 style={{ marginBottom: 32 }}>Shopping Cart</h1>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: 32, alignItems: 'start' }}>
        {/* Items */}
        <div className="card" style={{ padding: '8px 24px' }}>
          {cart.items.map(item => (
            <div key={item.id} className="cart-item">
              <img
                className="cart-item-image"
                src={item.productImage || 'https://via.placeholder.com/80?text=?'}
                alt={item.productName}
              />
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, color: 'var(--gray-900)', marginBottom: 4 }}>{item.productName}</div>
                <div style={{ fontSize: 13, color: 'var(--gray-500)' }}>${item.unitPrice} each</div>
              </div>

              <div className="qty-control">
                <button className="qty-btn" onClick={() => updateItem(item.id, item.quantity - 1)}>−</button>
                <span className="qty-value">{item.quantity}</span>
                <button className="qty-btn" onClick={() => updateItem(item.id, item.quantity + 1)}
                  disabled={item.quantity >= item.stockQuantity}>+</button>
              </div>

              <div style={{ fontWeight: 700, color: 'var(--gray-900)', minWidth: 70, textAlign: 'right' }}>
                ${item.totalPrice?.toFixed(2)}
              </div>

              <button
                onClick={() => removeItem(item.id)}
                style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--gray-400)', padding: 4 }}
              >
                <Trash2 size={16} />
              </button>
            </div>
          ))}
        </div>

        {/* Summary */}
        <div className="card" style={{ padding: 24, position: 'sticky', top: 100 }}>
          <h3 style={{ marginBottom: 20, fontFamily: 'DM Sans', fontWeight: 700, fontSize: 18 }}>Order Summary</h3>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 16 }}>
            {[
              ['Subtotal', `$${Number(cart.subtotal).toFixed(2)}`],
              ['Tax (8%)', `$${tax.toFixed(2)}`],
              ['Shipping', shipping === 0 ? 'FREE' : `$${shipping.toFixed(2)}`],
            ].map(([label, val]) => (
              <div key={label} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14, color: 'var(--gray-600)' }}>
                <span>{label}</span>
                <span style={{ color: val === 'FREE' ? 'var(--success)' : 'inherit', fontWeight: val === 'FREE' ? 600 : 400 }}>{val}</span>
              </div>
            ))}
          </div>

          <div style={{ borderTop: '2px solid var(--gray-200)', paddingTop: 16, marginBottom: 20,
            display: 'flex', justifyContent: 'space-between', fontWeight: 800, fontSize: 20 }}>
            <span>Total</span>
            <span style={{ color: 'var(--primary)' }}>${total.toFixed(2)}</span>
          </div>

          {shipping > 0 && (
            <div style={{ fontSize: 12, color: 'var(--gray-500)', marginBottom: 16, textAlign: 'center' }}>
              Add ${(50 - cart.subtotal).toFixed(2)} more for free shipping!
            </div>
          )}

          <button className="btn btn-primary" onClick={() => navigate('/checkout')}
            style={{ width: '100%', justifyContent: 'center', padding: 14, fontSize: 15 }}>
            Proceed to Checkout <ArrowRight size={16} />
          </button>

          <button className="btn btn-ghost" onClick={() => navigate('/products')}
            style={{ width: '100%', justifyContent: 'center', marginTop: 8 }}>
            Continue Shopping
          </button>
        </div>
      </div>
    </div>
  );
}
