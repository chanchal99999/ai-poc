import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle, CreditCard, Truck } from 'lucide-react';
import { orderApi } from '../services/api';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

export default function CheckoutPage() {
  const navigate = useNavigate();
  const { cart, fetchCart } = useCart();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(null);
  const [form, setForm] = useState({
    shippingAddress: user?.address || '',
    paymentMethod: 'Credit Card',
    notes: '',
  });

  const tax = (cart.subtotal || 0) * 0.08;
  const shipping = (cart.subtotal || 0) > 50 ? 0 : 5.99;
  const total = (cart.subtotal || 0) + tax + shipping;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!cart.items?.length) {
      toast.error('Your cart is empty');
      return;
    }
    setLoading(true);
    try {
      const { data } = await orderApi.place(form);
      setSuccess(data);
      fetchCart();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to place order');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="container" style={{ paddingTop: 60, paddingBottom: 60, maxWidth: 560, textAlign: 'center' }}>
        <div style={{ fontSize: 80, marginBottom: 16 }}>🎉</div>
        <h2 style={{ color: 'var(--success)', marginBottom: 8 }}>Order Placed!</h2>
        <p style={{ color: 'var(--gray-600)', marginBottom: 8 }}>
          Your order <strong>{success.orderNumber}</strong> has been successfully placed.
        </p>
        <p style={{ color: 'var(--gray-500)', fontSize: 14, marginBottom: 32 }}>
          Total: <strong>${Number(success.totalAmount).toFixed(2)}</strong>
        </p>
        <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
          <button className="btn btn-primary" onClick={() => navigate('/orders')}>View My Orders</button>
          <button className="btn btn-outline" onClick={() => navigate('/products')}>Continue Shopping</button>
        </div>
      </div>
    );
  }

  return (
    <div className="container" style={{ paddingTop: 32, paddingBottom: 48 }}>
      <h1 style={{ marginBottom: 32 }}>Checkout</h1>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 380px', gap: 32, alignItems: 'start' }}>
        <form onSubmit={handleSubmit}>
          <div className="card" style={{ padding: 28, marginBottom: 20 }}>
            <h3 style={{ fontSize: 17, fontFamily: 'DM Sans', fontWeight: 700, marginBottom: 20, display: 'flex', alignItems: 'center', gap: 8 }}>
              <Truck size={18} /> Shipping Information
            </h3>
            <div className="form-group">
              <label className="form-label">Shipping Address *</label>
              <input
                type="text"
                className="form-input"
                placeholder="123 Main Street, City, State, ZIP"
                value={form.shippingAddress}
                onChange={e => setForm({ ...form, shippingAddress: e.target.value })}
                required
              />
            </div>
            <div className="form-group" style={{ marginBottom: 0 }}>
              <label className="form-label">Order Notes (Optional)</label>
              <textarea
                className="form-input"
                rows={3}
                placeholder="Any special instructions..."
                value={form.notes}
                onChange={e => setForm({ ...form, notes: e.target.value })}
                style={{ resize: 'vertical' }}
              />
            </div>
          </div>

          <div className="card" style={{ padding: 28 }}>
            <h3 style={{ fontSize: 17, fontFamily: 'DM Sans', fontWeight: 700, marginBottom: 20, display: 'flex', alignItems: 'center', gap: 8 }}>
              <CreditCard size={18} /> Payment Method
            </h3>
            {['Credit Card', 'Debit Card', 'PayPal', 'Cash on Delivery'].map(method => (
              <label key={method} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 0', cursor: 'pointer', borderBottom: '1px solid var(--gray-100)' }}>
                <input
                  type="radio"
                  name="payment"
                  value={method}
                  checked={form.paymentMethod === method}
                  onChange={() => setForm({ ...form, paymentMethod: method })}
                />
                <span style={{ fontSize: 14, fontWeight: 500 }}>{method}</span>
              </label>
            ))}
          </div>
        </form>

        {/* Order summary */}
        <div className="card" style={{ padding: 24, position: 'sticky', top: 100 }}>
          <h3 style={{ marginBottom: 16, fontFamily: 'DM Sans', fontWeight: 700, fontSize: 18 }}>Order Summary</h3>

          <div style={{ maxHeight: 200, overflowY: 'auto', marginBottom: 16 }}>
            {cart.items?.map(item => (
              <div key={item.id} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, padding: '6px 0', borderBottom: '1px solid var(--gray-100)' }}>
                <span style={{ color: 'var(--gray-700)' }}>{item.productName} ×{item.quantity}</span>
                <span style={{ fontWeight: 600 }}>${item.totalPrice?.toFixed(2)}</span>
              </div>
            ))}
          </div>

          {[
            ['Subtotal', `$${Number(cart.subtotal || 0).toFixed(2)}`],
            ['Tax (8%)', `$${tax.toFixed(2)}`],
            ['Shipping', shipping === 0 ? 'FREE' : `$${shipping.toFixed(2)}`],
          ].map(([label, val]) => (
            <div key={label} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14, color: 'var(--gray-600)', marginBottom: 8 }}>
              <span>{label}</span>
              <span>{val}</span>
            </div>
          ))}

          <div style={{ borderTop: '2px solid var(--gray-200)', paddingTop: 14, marginTop: 8, marginBottom: 20,
            display: 'flex', justifyContent: 'space-between', fontWeight: 800, fontSize: 20 }}>
            <span>Total</span>
            <span style={{ color: 'var(--primary)' }}>${total.toFixed(2)}</span>
          </div>

          <button
            onClick={handleSubmit}
            className="btn btn-primary"
            disabled={loading}
            style={{ width: '100%', justifyContent: 'center', padding: 14, fontSize: 15 }}
          >
            <CheckCircle size={18} />
            {loading ? 'Placing Order...' : 'Place Order'}
          </button>
        </div>
      </div>
    </div>
  );
}
