import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, ShoppingBag, Search, ChevronDown, ChevronUp,
  RefreshCw, CheckCircle, XCircle, AlertTriangle, Package,
  Truck, DollarSign, Users, TrendingUp, Edit3, X, Check,
  ArrowLeft, Filter, Clock
} from 'lucide-react';
import { adminApi } from '../services/adminApi';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

// ── Constants ──────────────────────────────────────────────────────────────────

const ORDER_STATUSES = [
  'ALL','PENDING','CONFIRMED','PROCESSING','PICKED','SHIPPED','DELIVERED','CANCELLED','REFUNDED'
];

const ORDER_STATUS_META = {
  PENDING:    { color: '#f59e0b', bg: '#fef3c7', label: 'Pending',    icon: Clock },
  CONFIRMED:  { color: '#3b82f6', bg: '#dbeafe', label: 'Confirmed',  icon: CheckCircle },
  PROCESSING: { color: '#8b5cf6', bg: '#ede9fe', label: 'Processing', icon: RefreshCw },
  PICKED:     { color: '#0ea5e9', bg: '#e0f2fe', label: 'Picked',     icon: Package },
  SHIPPED:    { color: '#6366f1', bg: '#e0e7ff', label: 'Shipped',    icon: Truck },
  DELIVERED:  { color: '#10b981', bg: '#d1fae5', label: 'Delivered',  icon: CheckCircle },
  CANCELLED:  { color: '#ef4444', bg: '#fee2e2', label: 'Cancelled',  icon: XCircle },
  REFUNDED:   { color: '#6b7280', bg: '#f3f4f6', label: 'Refunded',   icon: RefreshCw },
};

const ITEM_STATUS_META = {
  PENDING:   { color: '#6b7280', bg: '#f3f4f6', emoji: '⏳', label: 'Pending'   },
  PICKED:    { color: '#0ea5e9', bg: '#e0f2fe', emoji: '📦', label: 'Picked'    },
  DELIVERED: { color: '#10b981', bg: '#d1fae5', emoji: '✅', label: 'Delivered' },
  ADJUSTED:  { color: '#f59e0b', bg: '#fef3c7', emoji: '⚠️', label: 'Adjusted'  },
  REJECTED:  { color: '#ef4444', bg: '#fee2e2', emoji: '❌', label: 'Rejected'  },
};

const fmt = (v) => `$${Number(v || 0).toFixed(2)}`;
const fmtDate = (d) => d ? new Date(d).toLocaleDateString('en-US',
  { year:'numeric', month:'short', day:'numeric', hour:'2-digit', minute:'2-digit' }) : '—';

// ── Status Badge ───────────────────────────────────────────────────────────────

function StatusBadge({ status, type = 'order', size = 'sm' }) {
  const meta = type === 'order' ? ORDER_STATUS_META[status] : ITEM_STATUS_META[status];
  if (!meta) return <span>{status}</span>;
  const pad = size === 'sm' ? '3px 10px' : '5px 14px';
  const fs  = size === 'sm' ? 11 : 13;
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      background: meta.bg, color: meta.color,
      padding: pad, borderRadius: 50, fontSize: fs, fontWeight: 700,
    }}>
      {type === 'item' && <span>{meta.emoji}</span>}
      {meta.label}
    </span>
  );
}

// ── Stat Card ─────────────────────────────────────────────────────────────────

function DashCard({ label, value, sub, icon: Icon, accent }) {
  return (
    <div style={{
      background: 'white', borderRadius: 16, padding: '20px 24px',
      border: '1px solid #e5e7eb',
      borderLeft: `4px solid ${accent}`,
      display: 'flex', flexDirection: 'column', gap: 6,
    }}>
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <span style={{ fontSize:12, fontWeight:700, textTransform:'uppercase',
          letterSpacing:'.5px', color:'#6b7280' }}>{label}</span>
        <div style={{ width:36, height:36, borderRadius:10, background:`${accent}18`,
          display:'flex', alignItems:'center', justifyContent:'center' }}>
          <Icon size={18} color={accent} />
        </div>
      </div>
      <div style={{ fontSize:28, fontWeight:800, color:'#111827', fontFamily:"'DM Sans',sans-serif" }}>
        {value}
      </div>
      {sub && <div style={{ fontSize:12, color:'#9ca3af' }}>{sub}</div>}
    </div>
  );
}

// ── Item Status Modal ─────────────────────────────────────────────────────────

function ItemStatusModal({ item, orderId, onClose, onSaved }) {
  const [status,   setStatus]   = useState(item.itemStatus || 'PENDING');
  const [adjQty,   setAdjQty]   = useState(item.adjustedQuantity || '');
  const [reason,   setReason]   = useState(item.statusReason || '');
  const [saving,   setSaving]   = useState(false);

  const save = async () => {
    setSaving(true);
    try {
      const payload = { itemStatus: status, statusReason: reason || null };
      if (status === 'ADJUSTED') payload.adjustedQuantity = Number(adjQty);
      const { data } = await adminApi.updateItemStatus(orderId, item.itemId, payload);
      toast.success('Item updated');
      onSaved(data);
      onClose();
    } catch (e) {
      toast.error(e.response?.data?.message || 'Update failed');
    } finally { setSaving(false); }
  };

  return (
    <div style={{
      position:'fixed', inset:0, background:'rgba(0,0,0,.5)', zIndex:1000,
      display:'flex', alignItems:'center', justifyContent:'center', padding:16
    }}>
      <div style={{
        background:'white', borderRadius:20, padding:28, width:'100%', maxWidth:460,
        boxShadow:'0 25px 50px rgba(0,0,0,.25)'
      }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:20 }}>
          <div>
            <h3 style={{ margin:0, fontSize:18, fontWeight:800, color:'#111827' }}>Update Item</h3>
            <p style={{ margin:'4px 0 0', fontSize:13, color:'#6b7280' }}>{item.productName}</p>
          </div>
          <button onClick={onClose} style={{ background:'none',border:'none',cursor:'pointer',color:'#6b7280' }}>
            <X size={20}/>
          </button>
        </div>

        {/* Current */}
        <div style={{ background:'#f9fafb', borderRadius:10, padding:'10px 14px', marginBottom:20,
          display:'flex', gap:16, fontSize:13 }}>
          <span>Ordered: <strong>×{item.quantity}</strong></span>
          <span>@ <strong>{fmt(item.unitPrice)}</strong></span>
          <span>Current: <StatusBadge status={item.itemStatus} type="item" /></span>
        </div>

        {/* Status selector */}
        <label style={{ display:'block', fontSize:13, fontWeight:600, color:'#374151', marginBottom:6 }}>
          New Status
        </label>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, marginBottom:16 }}>
          {['PICKED','DELIVERED','ADJUSTED','REJECTED'].map(s => {
            const m = ITEM_STATUS_META[s];
            return (
              <button key={s} onClick={() => setStatus(s)} style={{
                padding:'10px 12px', borderRadius:10, cursor:'pointer', fontWeight:700,
                fontSize:13, display:'flex', alignItems:'center', gap:6,
                border: status===s ? `2px solid ${m.color}` : '2px solid #e5e7eb',
                background: status===s ? m.bg : 'white', color: status===s ? m.color : '#374151',
              }}>
                <span>{m.emoji}</span> {m.label}
              </button>
            );
          })}
        </div>

        {/* Adjusted qty */}
        {status === 'ADJUSTED' && (
          <div style={{ marginBottom:16 }}>
            <label style={{ display:'block', fontSize:13, fontWeight:600, color:'#374151', marginBottom:6 }}>
              Adjusted Quantity (max {item.quantity})
            </label>
            <input type="number" min={1} max={item.quantity} value={adjQty}
              onChange={e => setAdjQty(e.target.value)}
              className="form-input" placeholder="Enter adjusted qty"
            />
          </div>
        )}

        {/* Reason */}
        <div style={{ marginBottom:20 }}>
          <label style={{ display:'block', fontSize:13, fontWeight:600, color:'#374151', marginBottom:6 }}>
            Reason / Note {(status==='REJECTED'||status==='ADJUSTED') && <span style={{color:'#ef4444'}}>*</span>}
          </label>
          <input value={reason} onChange={e => setReason(e.target.value)}
            className="form-input" placeholder="e.g. Out of stock, damaged batch…"
          />
        </div>

        <div style={{ display:'flex', gap:10 }}>
          <button onClick={onClose} className="btn btn-ghost" style={{ flex:1, justifyContent:'center' }}>Cancel</button>
          <button onClick={save} disabled={saving} className="btn btn-primary" style={{ flex:2, justifyContent:'center' }}>
            <Check size={16}/> {saving ? 'Saving…' : 'Save Changes'}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Order Status Modal ────────────────────────────────────────────────────────

function OrderStatusModal({ order, onClose, onSaved }) {
  const [status,   setStatus]   = useState(order.status);
  const [tracking, setTracking] = useState(order.trackingNumber || '');
  const [saving,   setSaving]   = useState(false);

  const save = async () => {
    setSaving(true);
    try {
      const { data } = await adminApi.updateOrderStatus(order.id, {
        status, trackingNumber: tracking || null
      });
      toast.success('Order status updated');
      onSaved(data);
      onClose();
    } catch(e) {
      toast.error(e.response?.data?.message || 'Update failed');
    } finally { setSaving(false); }
  };

  return (
    <div style={{
      position:'fixed', inset:0, background:'rgba(0,0,0,.5)', zIndex:1000,
      display:'flex', alignItems:'center', justifyContent:'center', padding:16
    }}>
      <div style={{
        background:'white', borderRadius:20, padding:28, width:'100%', maxWidth:440,
        boxShadow:'0 25px 50px rgba(0,0,0,.25)'
      }}>
        <div style={{ display:'flex', justifyContent:'space-between', marginBottom:20 }}>
          <div>
            <h3 style={{ margin:0, fontSize:18, fontWeight:800, color:'#111827' }}>Update Order Status</h3>
            <p style={{ margin:'4px 0 0', fontSize:13, color:'#6b7280' }}>{order.orderNumber}</p>
          </div>
          <button onClick={onClose} style={{ background:'none',border:'none',cursor:'pointer',color:'#6b7280' }}>
            <X size={20}/>
          </button>
        </div>

        <label style={{ display:'block', fontSize:13, fontWeight:600, color:'#374151', marginBottom:8 }}>
          New Order Status
        </label>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, marginBottom:16 }}>
          {ORDER_STATUSES.filter(s=>s!=='ALL').map(s => {
            const m = ORDER_STATUS_META[s];
            return (
              <button key={s} onClick={() => setStatus(s)} style={{
                padding:'9px 12px', borderRadius:10, cursor:'pointer', fontWeight:600, fontSize:12,
                border: status===s ? `2px solid ${m.color}` : '2px solid #e5e7eb',
                background: status===s ? m.bg : 'white', color: status===s ? m.color : '#374151',
              }}>
                {m.label}
              </button>
            );
          })}
        </div>

        {(status === 'SHIPPED' || status === 'PICKED') && (
          <div style={{ marginBottom:16 }}>
            <label style={{ display:'block', fontSize:13, fontWeight:600, color:'#374151', marginBottom:6 }}>
              Tracking Number
            </label>
            <input value={tracking} onChange={e => setTracking(e.target.value)}
              className="form-input" placeholder="e.g. TRK-1234567890"
            />
          </div>
        )}

        <div style={{ display:'flex', gap:10, marginTop:8 }}>
          <button onClick={onClose} className="btn btn-ghost" style={{ flex:1, justifyContent:'center' }}>Cancel</button>
          <button onClick={save} disabled={saving} className="btn btn-primary" style={{ flex:2, justifyContent:'center' }}>
            <Check size={16}/> {saving ? 'Saving…' : 'Update Status'}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Order Detail Panel ────────────────────────────────────────────────────────

function OrderDetailPanel({ orderId, onClose, onOrderUpdated }) {
  const [order,        setOrder]       = useState(null);
  const [loading,      setLoading]     = useState(true);
  const [editItem,     setEditItem]    = useState(null);
  const [editStatus,   setEditStatus]  = useState(false);
  const [bulkBusy,     setBulkBusy]    = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await adminApi.getOrderDetail(orderId);
      setOrder(data);
    } catch { toast.error('Failed to load order'); }
    finally { setLoading(false); }
  }, [orderId]);

  useEffect(() => { load(); }, [load]);

  const handleBulk = async (itemStatus) => {
    setBulkBusy(true);
    try {
      const { data } = await adminApi.bulkUpdateItems(orderId, { itemStatus });
      setOrder(data);
      onOrderUpdated && onOrderUpdated(data);
      toast.success(`All items marked as ${itemStatus}`);
    } catch(e) { toast.error('Bulk update failed'); }
    finally { setBulkBusy(false); }
  };

  if (loading) return (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height:300 }}>
      <RefreshCw size={24} style={{ animation:'spin 1s linear infinite', color:'var(--primary)' }} />
    </div>
  );
  if (!order) return null;

  const itemCounts = order.items?.reduce((acc,i) => {
    acc[i.itemStatus] = (acc[i.itemStatus]||0)+1; return acc;
  }, {});

  return (
    <div style={{ display:'flex', flexDirection:'column', height:'100%' }}>
      {/* Header */}
      <div style={{ padding:'20px 24px', borderBottom:'1px solid #e5e7eb',
        display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <div>
          <div style={{ display:'flex', alignItems:'center', gap:10 }}>
            <h2 style={{ margin:0, fontSize:20, fontWeight:800, color:'#111827' }}>{order.orderNumber}</h2>
            <StatusBadge status={order.status} type="order" size="md" />
          </div>
          <p style={{ margin:'4px 0 0', fontSize:13, color:'#6b7280' }}>
            {order.customerName} · {order.customerEmail}
          </p>
        </div>
        <div style={{ display:'flex', gap:8 }}>
          <button onClick={() => setEditStatus(true)} className="btn btn-outline btn-sm">
            <Edit3 size={14}/> Change Status
          </button>
          <button onClick={onClose} style={{ background:'none',border:'none',cursor:'pointer',color:'#6b7280' }}>
            <X size={22}/>
          </button>
        </div>
      </div>

      <div style={{ overflow:'auto', flex:1, padding:'20px 24px' }}>

        {/* Meta row */}
        <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12, marginBottom:20 }}>
          {[
            ['Placed',   fmtDate(order.createdAt)],
            ['Payment',  order.paymentMethod || '—'],
            ['Tracking', order.trackingNumber || 'Not assigned'],
          ].map(([k,v]) => (
            <div key={k} style={{ background:'#f9fafb', borderRadius:10, padding:'10px 14px' }}>
              <div style={{ fontSize:11, color:'#9ca3af', fontWeight:700, textTransform:'uppercase', marginBottom:4 }}>{k}</div>
              <div style={{ fontSize:13, fontWeight:600, color:'#374151', wordBreak:'break-all' }}>{v}</div>
            </div>
          ))}
        </div>

        {/* Shipping */}
        {order.shippingAddress && (
          <div style={{ background:'#f9fafb', borderRadius:10, padding:'10px 14px', marginBottom:20, fontSize:13, color:'#374151' }}>
            <span style={{ fontSize:11, color:'#9ca3af', fontWeight:700, textTransform:'uppercase' }}>Ship To: </span>
            {order.shippingAddress}
          </div>
        )}

        {/* Item status summary pills */}
        <div style={{ display:'flex', flexWrap:'wrap', gap:8, marginBottom:16 }}>
          {Object.entries(itemCounts||{}).map(([s,c]) => (
            <span key={s} style={{
              background: ITEM_STATUS_META[s]?.bg||'#f3f4f6',
              color: ITEM_STATUS_META[s]?.color||'#374151',
              padding:'3px 10px', borderRadius:50, fontSize:12, fontWeight:700
            }}>
              {ITEM_STATUS_META[s]?.emoji} {c} {ITEM_STATUS_META[s]?.label||s}
            </span>
          ))}
        </div>

        {/* Bulk actions */}
        <div style={{ display:'flex', gap:8, marginBottom:16, flexWrap:'wrap' }}>
          <span style={{ fontSize:12, color:'#9ca3af', alignSelf:'center', fontWeight:600 }}>Bulk:</span>
          {['PICKED','DELIVERED'].map(s => (
            <button key={s} disabled={bulkBusy} onClick={() => handleBulk(s)}
              style={{
                padding:'5px 12px', fontSize:12, fontWeight:700, borderRadius:8, cursor:'pointer',
                border:`1.5px solid ${ITEM_STATUS_META[s].color}`,
                background: ITEM_STATUS_META[s].bg, color: ITEM_STATUS_META[s].color,
              }}>
              {ITEM_STATUS_META[s].emoji} All {ITEM_STATUS_META[s].label}
            </button>
          ))}
        </div>

        {/* Items table */}
        <div style={{ border:'1px solid #e5e7eb', borderRadius:12, overflow:'hidden' }}>
          <table style={{ width:'100%', borderCollapse:'collapse' }}>
            <thead>
              <tr style={{ background:'#f9fafb', borderBottom:'1px solid #e5e7eb' }}>
                {['Product','Qty','Unit Price','Total','Status',''].map(h => (
                  <th key={h} style={{ padding:'10px 14px', fontSize:11, fontWeight:700,
                    color:'#6b7280', textTransform:'uppercase', letterSpacing:'.5px',
                    textAlign: h==='Total'||h==='Unit Price' ? 'right' : 'left' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {order.items?.map((item, idx) => (
                <tr key={item.itemId}
                  style={{ borderBottom: idx < order.items.length-1 ? '1px solid #f3f4f6' : 'none',
                    background: item.itemStatus==='REJECTED' ? '#fff5f5'
                              : item.itemStatus==='ADJUSTED' ? '#fffbeb' : 'white' }}>
                  <td style={{ padding:'12px 14px' }}>
                    <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                      <img src={item.productImage||'https://via.placeholder.com/40?text=?'}
                        alt={item.productName}
                        style={{ width:36, height:36, borderRadius:8, objectFit:'cover', flexShrink:0 }} />
                      <div>
                        <div style={{ fontSize:13, fontWeight:600, color:'#111827' }}>{item.productName}</div>
                        {item.statusReason && (
                          <div style={{ fontSize:11, color:'#9ca3af', marginTop:2 }}>↳ {item.statusReason}</div>
                        )}
                      </div>
                    </div>
                  </td>
                  <td style={{ padding:'12px 14px', fontSize:13, color:'#374151' }}>
                    ×{item.quantity}
                    {item.itemStatus==='ADJUSTED' && item.adjustedQuantity && (
                      <span style={{ color:'#f59e0b', fontWeight:700, marginLeft:4 }}>
                        → ×{item.adjustedQuantity}
                      </span>
                    )}
                  </td>
                  <td style={{ padding:'12px 14px', fontSize:13, color:'#374151', textAlign:'right' }}>
                    {fmt(item.unitPrice)}
                  </td>
                  <td style={{ padding:'12px 14px', fontSize:13, fontWeight:700, color:'#111827', textAlign:'right' }}>
                    {fmt(item.totalPrice)}
                  </td>
                  <td style={{ padding:'12px 14px' }}>
                    <StatusBadge status={item.itemStatus} type="item" />
                  </td>
                  <td style={{ padding:'12px 14px' }}>
                    <button onClick={() => setEditItem(item)}
                      style={{ background:'none', border:'1.5px solid #e5e7eb', borderRadius:8,
                        padding:'5px 10px', cursor:'pointer', color:'#6b7280', fontSize:12,
                        display:'flex', alignItems:'center', gap:4, fontWeight:600 }}>
                      <Edit3 size={12}/> Edit
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Order totals */}
        <div style={{ marginTop:20, display:'flex', justifyContent:'flex-end' }}>
          <div style={{ minWidth:240, background:'#f9fafb', borderRadius:12, padding:'16px 20px' }}>
            {[
              ['Subtotal',  fmt(order.subtotal)],
              ['Tax (8%)',  fmt(order.tax)],
              ['Shipping',  order.shippingCost > 0 ? fmt(order.shippingCost) : 'FREE'],
            ].map(([k,v]) => (
              <div key={k} style={{ display:'flex', justifyContent:'space-between',
                fontSize:13, color:'#6b7280', marginBottom:8 }}>
                <span>{k}</span><span>{v}</span>
              </div>
            ))}
            <div style={{ borderTop:'2px solid #e5e7eb', paddingTop:12, marginTop:4,
              display:'flex', justifyContent:'space-between', fontWeight:800, fontSize:17 }}>
              <span>Total</span>
              <span style={{ color:'var(--primary)' }}>{fmt(order.totalAmount)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Modals */}
      {editItem && (
        <ItemStatusModal item={editItem} orderId={order.id}
          onClose={() => setEditItem(null)}
          onSaved={updated => { setOrder(updated); onOrderUpdated && onOrderUpdated(updated); }} />
      )}
      {editStatus && (
        <OrderStatusModal order={order}
          onClose={() => setEditStatus(false)}
          onSaved={updated => { setOrder(updated); onOrderUpdated && onOrderUpdated(updated); }} />
      )}
    </div>
  );
}

// ── Main Admin Page ───────────────────────────────────────────────────────────

export default function AdminPage() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [view,        setView]        = useState('dashboard');  // 'dashboard' | 'orders'
  const [stats,       setStats]       = useState(null);
  const [orders,      setOrders]      = useState([]);
  const [totalPages,  setTotalPages]  = useState(0);
  const [totalItems,  setTotalItems]  = useState(0);
  const [page,        setPage]        = useState(0);
  const [filterStatus,setFilterStatus]= useState('ALL');
  const [search,      setSearch]      = useState('');
  const [searchInput, setSearchInput] = useState('');
  const [loading,     setLoading]     = useState(true);
  const [selectedId,  setSelectedId]  = useState(null);

  // Redirect if not admin
  useEffect(() => {
    if (user && user.role !== 'ADMIN') {
      toast.error('Admin access required');
      navigate('/');
    }
  }, [user, navigate]);

  // Load dashboard stats
  useEffect(() => {
    adminApi.getDashboard()
      .then(({ data }) => setStats(data))
      .catch(() => {});
  }, []);

  // Load orders list
  const loadOrders = useCallback(async () => {
    setLoading(true);
    try {
      const params = { page, size: 20 };
      if (filterStatus !== 'ALL') params.status = filterStatus;
      if (search) params.search = search;
      const { data } = await adminApi.getOrders(params);
      setOrders(data.content);
      setTotalPages(data.totalPages);
      setTotalItems(data.totalElements);
    } catch { toast.error('Failed to load orders'); }
    finally { setLoading(false); }
  }, [page, filterStatus, search]);

  useEffect(() => { loadOrders(); }, [loadOrders]);

  const handleSearch = (e) => {
    e.preventDefault();
    setPage(0);
    setSearch(searchInput);
  };

  const handleFilterStatus = (s) => {
    setPage(0);
    setFilterStatus(s);
  };

  // ── Render ─────────────────────────────────────────────────────────────────

  return (
    <div style={{ display:'flex', minHeight:'calc(100vh - 64px)', background:'#f8fafc' }}>

      {/* Sidebar */}
      <aside style={{
        width:220, background:'#111827', flexShrink:0, display:'flex', flexDirection:'column',
        padding:'24px 0',
      }}>
        <div style={{ padding:'0 20px 24px', borderBottom:'1px solid #1f2937' }}>
          <div style={{ fontSize:11, color:'#4b5563', fontWeight:700, textTransform:'uppercase',
            letterSpacing:'.5px', marginBottom:4 }}>FreshBasket</div>
          <div style={{ fontSize:16, fontWeight:800, color:'white' }}>Admin Panel</div>
        </div>

        <nav style={{ padding:'16px 12px', flex:1 }}>
          {[
            { id:'dashboard', label:'Dashboard',   icon:LayoutDashboard },
            { id:'orders',    label:'All Orders',  icon:ShoppingBag },
          ].map(({ id, label, icon: Icon }) => (
            <button key={id} onClick={() => setView(id)} style={{
              width:'100%', display:'flex', alignItems:'center', gap:10,
              padding:'10px 12px', borderRadius:10, border:'none', cursor:'pointer',
              background: view===id ? '#1f2937' : 'none',
              color: view===id ? 'white' : '#6b7280',
              fontWeight: view===id ? 700 : 500, fontSize:14, marginBottom:4,
              textAlign:'left',
            }}>
              <Icon size={17}/> {label}
            </button>
          ))}
        </nav>

        <div style={{ padding:'16px 20px', borderTop:'1px solid #1f2937' }}>
          <button onClick={() => navigate('/')} style={{
            width:'100%', display:'flex', alignItems:'center', gap:8,
            background:'none', border:'none', cursor:'pointer',
            color:'#6b7280', fontSize:13, fontWeight:500,
          }}>
            <ArrowLeft size={15}/> Back to Store
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main style={{ flex:1, overflow:'auto' }}>

        {/* ── Dashboard ──────────────────────────────────────────────────────── */}
        {view === 'dashboard' && (
          <div style={{ padding:'32px 32px 48px' }}>
            <div style={{ marginBottom:28 }}>
              <h1 style={{ margin:0, fontSize:26, fontWeight:800, color:'#111827' }}>Dashboard</h1>
              <p style={{ margin:'4px 0 0', color:'#6b7280', fontSize:14 }}>
                Welcome back, {user?.firstName}. Here's what's happening.
              </p>
            </div>

            {stats ? (
              <>
                {/* Revenue cards */}
                <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:16, marginBottom:16 }}>
                  <DashCard label="Revenue Today"      value={fmt(stats.revenueToday)}    icon={DollarSign} accent="#10b981" />
                  <DashCard label="Revenue This Month" value={fmt(stats.revenueThisMonth)} icon={TrendingUp}  accent="#6366f1" />
                  <DashCard label="All-Time Revenue"   value={fmt(stats.revenueAllTime)}  icon={DollarSign}  accent="#f59e0b" />
                </div>

                {/* Order status cards */}
                <div style={{ display:'grid', gridTemplateColumns:'repeat(5,1fr)', gap:12, marginBottom:32 }}>
                  <DashCard label="Total Orders"     value={stats.totalOrders}      icon={ShoppingBag}   accent="#3b82f6" />
                  <DashCard label="Pending"          value={stats.pendingOrders}    icon={Clock}         accent="#f59e0b" />
                  <DashCard label="In Progress"      value={stats.processingOrders} icon={RefreshCw}     accent="#8b5cf6" />
                  <DashCard label="Delivered"        value={stats.deliveredOrders}  icon={CheckCircle}   accent="#10b981" />
                  <DashCard label="Cancelled"        value={stats.cancelledOrders}  icon={XCircle}       accent="#ef4444" />
                </div>

                <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16 }}>
                  <DashCard label="Total Customers"  value={stats.totalCustomers}   icon={Users}         accent="#0ea5e9"
                    sub="Registered customer accounts" />
                  <div style={{
                    background:'white', borderRadius:16, padding:'20px 24px',
                    border:'1px solid #e5e7eb', borderLeft:'4px solid #10b981',
                    display:'flex', flexDirection:'column', justifyContent:'center',
                  }}>
                    <p style={{ margin:'0 0 12px', fontSize:13, color:'#6b7280', fontWeight:600 }}>Quick Actions</p>
                    <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
                      <button onClick={() => setView('orders')} className="btn btn-primary btn-sm">
                        <ShoppingBag size={14}/> View All Orders
                      </button>
                      <button onClick={() => { setView('orders'); setFilterStatus('PENDING'); }}
                        className="btn btn-outline btn-sm">
                        <Clock size={14}/> Pending Orders
                      </button>
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:16 }}>
                {Array.from({length:8}).map((_,i) => (
                  <div key={i} className="skeleton" style={{ height:100, borderRadius:16 }} />
                ))}
              </div>
            )}
          </div>
        )}

        {/* ── Orders ─────────────────────────────────────────────────────────── */}
        {view === 'orders' && (
          <div style={{ display:'flex', height:'100%' }}>

            {/* Order list */}
            <div style={{
              width: selectedId ? 480 : '100%',
              transition:'width .25s', overflow:'auto',
              borderRight: selectedId ? '1px solid #e5e7eb' : 'none',
            }}>
              <div style={{ padding:'24px 24px 16px', borderBottom:'1px solid #e5e7eb', background:'white', position:'sticky', top:0, zIndex:10 }}>
                <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:14 }}>
                  <div>
                    <h2 style={{ margin:0, fontSize:20, fontWeight:800, color:'#111827' }}>All Orders</h2>
                    <p style={{ margin:'2px 0 0', fontSize:13, color:'#6b7280' }}>{totalItems} orders total</p>
                  </div>
                  <button onClick={loadOrders} style={{ background:'none', border:'none', cursor:'pointer', color:'#6b7280' }}>
                    <RefreshCw size={18} />
                  </button>
                </div>

                {/* Search */}
                <form onSubmit={handleSearch} style={{ display:'flex', gap:8, marginBottom:12 }}>
                  <div style={{ flex:1, position:'relative' }}>
                    <Search size={14} style={{ position:'absolute', left:10, top:'50%', transform:'translateY(-50%)', color:'#9ca3af' }} />
                    <input className="form-input" style={{ paddingLeft:32, fontSize:13 }}
                      placeholder="Search by name, email, order #…"
                      value={searchInput} onChange={e => setSearchInput(e.target.value)} />
                  </div>
                  <button type="submit" className="btn btn-primary btn-sm">Search</button>
                  {search && (
                    <button type="button" className="btn btn-ghost btn-sm"
                      onClick={() => { setSearch(''); setSearchInput(''); setPage(0); }}>
                      <X size={14}/>
                    </button>
                  )}
                </form>

                {/* Status filter chips */}
                <div style={{ display:'flex', gap:6, flexWrap:'wrap' }}>
                  {ORDER_STATUSES.map(s => {
                    const m = s === 'ALL' ? { color:'#374151', bg:'#f3f4f6' } : ORDER_STATUS_META[s];
                    return (
                      <button key={s} onClick={() => handleFilterStatus(s)} style={{
                        padding:'3px 10px', borderRadius:50, fontSize:11, fontWeight:700,
                        cursor:'pointer',
                        border: filterStatus===s ? `1.5px solid ${m.color}` : '1.5px solid #e5e7eb',
                        background: filterStatus===s ? m.bg : 'white',
                        color: filterStatus===s ? m.color : '#6b7280',
                      }}>{s === 'ALL' ? 'All' : ORDER_STATUS_META[s].label}</button>
                    );
                  })}
                </div>
              </div>

              {/* Order rows */}
              <div style={{ padding:'8px 0' }}>
                {loading ? (
                  Array.from({length:6}).map((_,i) => (
                    <div key={i} className="skeleton" style={{ height:72, margin:'6px 16px', borderRadius:12 }} />
                  ))
                ) : orders.length === 0 ? (
                  <div className="empty-state" style={{ padding:'40px 24px' }}>
                    <div className="empty-state-icon">📦</div>
                    <h3>No orders found</h3>
                    <p>Try adjusting your filters</p>
                  </div>
                ) : orders.map(order => {
                  const m = ORDER_STATUS_META[order.status];
                  const isSelected = selectedId === order.id;
                  return (
                    <div key={order.id}
                      onClick={() => setSelectedId(isSelected ? null : order.id)}
                      style={{
                        margin:'4px 12px', padding:'12px 16px', borderRadius:12,
                        cursor:'pointer', border: isSelected ? '2px solid var(--primary)' : '1px solid #e5e7eb',
                        background: isSelected ? '#f0fdf4' : 'white',
                        transition:'all .15s',
                      }}>
                      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:4 }}>
                        <span style={{ fontSize:14, fontWeight:700, color:'#111827' }}>{order.orderNumber}</span>
                        <StatusBadge status={order.status} type="order" />
                      </div>
                      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
                        <div style={{ fontSize:12, color:'#6b7280' }}>
                          {order.customerName} · {order.itemCount} item{order.itemCount !== 1 ? 's' : ''}
                        </div>
                        <div style={{ fontSize:13, fontWeight:700, color:'#111827' }}>
                          {fmt(order.totalAmount)}
                        </div>
                      </div>
                      <div style={{ fontSize:11, color:'#9ca3af', marginTop:2 }}>
                        {fmtDate(order.createdAt)}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="pagination" style={{ padding:'16px 24px' }}>
                  <button className="page-btn" disabled={page===0} onClick={() => setPage(p=>p-1)}>‹</button>
                  {Array.from({length:Math.min(totalPages,7)}).map((_,i) => (
                    <button key={i} className={`page-btn ${page===i?'active':''}`} onClick={() => setPage(i)}>{i+1}</button>
                  ))}
                  <button className="page-btn" disabled={page>=totalPages-1} onClick={() => setPage(p=>p+1)}>›</button>
                </div>
              )}
            </div>

            {/* Order detail slide-in panel */}
            {selectedId && (
              <div style={{ flex:1, overflow:'auto', background:'white' }}>
                <OrderDetailPanel
                  orderId={selectedId}
                  onClose={() => setSelectedId(null)}
                  onOrderUpdated={() => loadOrders()}
                />
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
