import { useState, useEffect, useCallback } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Star, ShoppingCart, Search, Plus, Minus } from 'lucide-react';
import { productApi } from '../services/api';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

// ── Inline quantity control shown on product card once item is in cart ─────────

function QtyControl({ item, stock }) {
  const { updateItem, removeItem } = useCart();
  const [busy, setBusy] = useState(false);

  const change = async (newQty) => {
    setBusy(true);
    try {
      if (newQty < 1) await removeItem(item.id);
      else            await updateItem(item.id, newQty);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div
      className="qty-control"
      onClick={(e) => e.stopPropagation()}
      style={{ display: 'flex', alignItems: 'center', gap: 0 }}
    >
      <button
        className="qty-btn"
        onClick={() => change(item.quantity - 1)}
        disabled={busy}
        title={item.quantity === 1 ? 'Remove from cart' : 'Decrease quantity'}
      >
        <Minus size={12} />
      </button>
      <span className="qty-value" style={{ minWidth: 28, textAlign: 'center', fontWeight: 700 }}>
        {item.quantity}
      </span>
      <button
        className="qty-btn"
        onClick={() => change(item.quantity + 1)}
        disabled={busy || item.quantity >= stock}
        title="Increase quantity"
      >
        <Plus size={12} />
      </button>
    </div>
  );
}

// ── Product card ───────────────────────────────────────────────────────────────

function ProductCard({ product }) {
  const { addToCart, cart, loading: cartLoading } = useCart();
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();

  // Find this product in the cart (if present)
  const cartItem = cart.items?.find((i) => Number(i.productId) === Number(product.id));
  const inCart   = !!cartItem;

  const stars = (rating) => '★'.repeat(Math.floor(rating)) + '☆'.repeat(5 - Math.floor(rating));

  const handleAdd = (e) => {
    e.stopPropagation();
    if (!isAuthenticated) navigate('/login');
    else addToCart(product.id, 1);
  };

  return (
    <div className="card product-card" onClick={() => navigate(`/products/${product.id}`)}>
      <div className="product-card-image">
        <img src={product.imageUrl || 'https://via.placeholder.com/400x300?text=No+Image'} alt={product.name} />
      </div>
      <div className="product-card-body">
        <div className="product-card-category">{product.category}</div>
        <div className="product-card-name">{product.name}</div>
        {product.brand && (
          <div style={{ fontSize: 12, color: 'var(--gray-400)', marginBottom: 6 }}>{product.brand}</div>
        )}
        {product.rating && (
          <div className="product-card-rating">
            <span className="stars">{stars(product.rating)}</span>
            <span>{product.rating}</span>
            <span>({product.reviewCount?.toLocaleString()})</span>
          </div>
        )}
        <div className="product-card-footer">
          <span className="product-price">${product.price}</span>

          {/* Out of stock */}
          {product.stockQuantity === 0 && (
            <button className="btn btn-primary btn-sm" disabled>
              Out of Stock
            </button>
          )}

          {/* In stock — not yet in cart: show Add button */}
          {product.stockQuantity > 0 && !inCart && (
            <button
              className="btn btn-primary btn-sm"
              onClick={handleAdd}
              disabled={cartLoading}
            >
              <ShoppingCart size={14} />
              Add
            </button>
          )}

          {/* In stock — already in cart: show − qty + controls */}
          {product.stockQuantity > 0 && inCart && (
            <QtyControl item={cartItem} stock={product.stockQuantity} />
          )}
        </div>
      </div>
    </div>
  );
}

// ── Page ───────────────────────────────────────────────────────────────────────

export default function ProductsPage() {
  const [products, setProducts]       = useState([]);
  const [categories, setCategories]   = useState([]);
  const [loading, setLoading]         = useState(true);
  const [page, setPage]               = useState(0);
  const [totalPages, setTotalPages]   = useState(0);
  const [searchParams, setSearchParams] = useSearchParams();
  const [localSearch, setLocalSearch] = useState(searchParams.get('search') || '');

  const category = searchParams.get('category') || '';
  const search   = searchParams.get('search') || '';

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await productApi.getAll({
        page, size: 12,
        category: category || undefined,
        search:   search   || undefined,
      });
      setProducts(data.content);
      setTotalPages(data.totalPages);
    } catch (error) {
      console.error('Failed to fetch products', error);
    } finally {
      setLoading(false);
    }
  }, [page, category, search]);

  useEffect(() => { fetchProducts(); }, [fetchProducts]);
  useEffect(() => { productApi.getCategories().then(({ data }) => setCategories(data)); }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    setPage(0);
    const params = {};
    if (localSearch) params.search = localSearch;
    if (category)    params.category = category;
    setSearchParams(params);
  };

  const handleCategory = (cat) => {
    setPage(0);
    setLocalSearch('');
    if (cat === category) setSearchParams({});
    else setSearchParams({ category: cat });
  };

  return (
    <div>
      {/* Search bar */}
      <div style={{ background: 'white', borderBottom: '1px solid var(--gray-200)', padding: '20px 0' }}>
        <div className="container">
          <form onSubmit={handleSearch} style={{ display: 'flex', gap: 12, maxWidth: 500 }}>
            <div style={{ flex: 1, position: 'relative' }}>
              <Search size={16} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--gray-400)' }} />
              <input
                type="text"
                className="form-input"
                style={{ paddingLeft: 38 }}
                placeholder="Search products..."
                value={localSearch}
                onChange={(e) => setLocalSearch(e.target.value)}
              />
            </div>
            <button type="submit" className="btn btn-primary">Search</button>
          </form>
        </div>
      </div>

      {/* Filter bar */}
      <div className="filter-bar">
        <div className="filter-bar-inner">
          <button
            className={`filter-chip ${!category ? 'active' : ''}`}
            onClick={() => { setPage(0); setSearchParams(search ? { search } : {}); }}
          >
            All
          </button>
          {categories.map((cat) => (
            <button
              key={cat}
              className={`filter-chip ${category === cat ? 'active' : ''}`}
              onClick={() => handleCategory(cat)}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div className="container" style={{ paddingBottom: 48 }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 }}>
          <div>
            <h2 style={{ fontSize: 22 }}>
              {search ? `Results for "${search}"` : category || 'All Products'}
            </h2>
            {!loading && (
              <p style={{ color: 'var(--gray-500)', fontSize: 14 }}>{products.length} products found</p>
            )}
          </div>
        </div>

        {/* Grid */}
        {loading ? (
          <div className="products-grid">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="card">
                <div className="skeleton" style={{ height: 200 }} />
                <div style={{ padding: 16 }}>
                  <div className="skeleton" style={{ height: 12, marginBottom: 8 }} />
                  <div className="skeleton" style={{ height: 18, width: '70%', marginBottom: 12 }} />
                  <div className="skeleton" style={{ height: 14, width: '40%' }} />
                </div>
              </div>
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="empty-state">
            <div className="empty-state-icon">🔍</div>
            <h3>No products found</h3>
            <p>Try a different search term or category</p>
            <button className="btn btn-primary" onClick={() => setSearchParams({})}>
              Browse All Products
            </button>
          </div>
        ) : (
          <div className="products-grid">
            {products.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="pagination">
            <button className="page-btn" disabled={page === 0} onClick={() => setPage((p) => p - 1)}>‹</button>
            {Array.from({ length: Math.min(totalPages, 7) }).map((_, i) => (
              <button
                key={i}
                className={`page-btn ${page === i ? 'active' : ''}`}
                onClick={() => setPage(i)}
              >
                {i + 1}
              </button>
            ))}
            <button className="page-btn" disabled={page >= totalPages - 1} onClick={() => setPage((p) => p + 1)}>›</button>
          </div>
        )}
      </div>
    </div>
  );
}
